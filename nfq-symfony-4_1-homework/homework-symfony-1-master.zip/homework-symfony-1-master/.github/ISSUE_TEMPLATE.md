<!-- Please describe your problem/feature request here. -->
 
Details:
- OS: 
- Docker version: 
- Link to paste.bin (or similar) with `docker-compose logs` output: