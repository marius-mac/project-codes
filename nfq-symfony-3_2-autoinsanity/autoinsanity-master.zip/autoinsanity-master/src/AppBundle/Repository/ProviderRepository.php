<?php

namespace AppBundle\Repository;

/**
 * ProviderRepository
 */
class ProviderRepository extends \Doctrine\ORM\EntityRepository
{
}
