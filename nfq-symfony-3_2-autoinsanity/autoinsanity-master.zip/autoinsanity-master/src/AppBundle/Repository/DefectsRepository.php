<?php

namespace AppBundle\Repository;

/**
 * DefectsRepository
 */
class DefectsRepository extends \Doctrine\ORM\EntityRepository
{
}
