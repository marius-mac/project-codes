<?php

namespace AppBundle\Repository;

/**
 * ClimateControlRepository
 */
class ClimateControlRepository extends \Doctrine\ORM\EntityRepository
{
}
