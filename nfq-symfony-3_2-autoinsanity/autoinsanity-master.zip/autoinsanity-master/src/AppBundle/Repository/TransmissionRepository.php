<?php

namespace AppBundle\Repository;

/**
 * TransmissionRepository
 */
class TransmissionRepository extends \Doctrine\ORM\EntityRepository
{
}
