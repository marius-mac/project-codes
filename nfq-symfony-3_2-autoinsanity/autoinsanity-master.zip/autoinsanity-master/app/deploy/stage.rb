server 'deploy.nfqakademija.lt', user: 'autoinsanity', roles: %w{web}
