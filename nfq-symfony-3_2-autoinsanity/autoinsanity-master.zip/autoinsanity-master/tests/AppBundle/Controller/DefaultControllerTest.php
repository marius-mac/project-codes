<?php

namespace Tests\AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DefaultControllerTest //extends WebTestCase
{
    public function testIndex()
    {
        /*$client = static::createClient();
        $crawler = $client->request('GET', '/search');

        $form = $crawler->selectButton('button[type=submit]')->form();
        $form['vehicle[brand]'] = '257';*/



//        $this->assertEquals(200, $client->getResponse()->getStatusCode());
//        $this->assertContains('Detalioji paieška', $crawler->filter('.container h3')->text());
    }
}
