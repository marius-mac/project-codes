---
layout: default
title: priority
published: true
mainMaxWidth: 50rem;
---

* When used in controls, you can use the `priority` argument to define and change the order in which your controls will be presented inside a section.
* When used for sections & panels, `priority` lets you define the order in which sections & panels are presented in the customizer.
