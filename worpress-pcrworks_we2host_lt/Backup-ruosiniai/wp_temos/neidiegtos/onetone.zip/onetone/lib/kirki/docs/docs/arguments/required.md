---
layout: default
title: required
published: false
---

The `required` argument was deprecated on version 2.3.2.

Please use the [`active_callback`](active_callback) argument instead.
