---
layout: default
title: output
published: true
mainMaxWidth: 50rem;
---

Using the `output` argument you can specify if you want Kirki to automatically generate and apply CSS for various elements of your page.

Please refer to the [css module](../modules/css) for more info.

----

Other articles you should read:

* [Automating CSS Output & postMessage scripts with Kirki (Part 1)
](http://aristath.github.io/wordpress/customizer/2017/07/02/customizer-output-part-1.html)
