<?php
$db_con = new PDO('mysql:host=localhost;dbname=php_clicks', 'root', '');
?>