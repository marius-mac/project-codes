--
-- Database: `laravel5example`
--
DROP DATABASE IF EXISTS `laravel5example`;
CREATE DATABASE IF NOT EXISTS `laravel5example` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `laravel5example`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_id_foreign` (`user_id`),
  KEY `comments_post_id_foreign` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `comments`
--

INSERT INTO `comments` (`id`, `created_at`, `updated_at`, `content`, `seen`, `user_id`, `post_id`) VALUES
(1, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum senectus dictum laoreet euismod primis nam sagittis dapibus, feugiat lectus congue ad semper sociosqu consequat cursus. \nIn nam etiam pharetra blandit quis justo elit class senectus ad, sem imperdiet tempus leo arcu dolor integer porta platea, varius congue vehicula fusce inceptos ultricies auctor platea interdum. \nAd neque elit molestie accumsan pulvinar mauris vulputate, congue a quisque ornare curae sociosqu. \nVivamus eros etiam amet platea fames per ullamcorper, elementum conubia nulla praesent integer platea. \nConsequat consectetur luctus eleifend sem id ullamcorper at etiam, nisi habitant donec himenaeos curabitur venenatis tellus. \n</p>\n<p>\nMi dictum eu at dictum lacinia curabitur lacinia, eleifend vulputate maecenas rhoncus malesuada. \nEgestas dolor curae placerat velit a tincidunt sodales bibendum taciti, senectus libero metus ultricies ac consequat blandit convallis, felis dapibus a mollis leo litora primis faucibus. \nAmet donec fames auctor tempor integer ac suspendisse, aliquet sed nullam at congue rhoncus diam porttitor, congue neque pretium integer eros laoreet. \nLectus morbi velit a ornare donec rutrum aliquam malesuada ultricies tempus sem dictumst sodales, pellentesque vivamus cras neque metus integer aliquam auctor mi netus curabitur turpis, lacinia sollicitudin etiam conubia elementum cras suscipit laoreet praesent aenean vehicula fermentum. \n</p>\n<p>\nSit integer imperdiet dolor auctor tortor, aptent libero habitant duis. \n</p>', 0, 2, 1),
(2, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum class gravida convallis urna amet lectus quisque morbi, semper molestie odio mi ad posuere praesent consequat cubilia accumsan, eget mauris velit pharetra mauris diam hac vulputate. \nRutrum phasellus nam quisque malesuada conubia sem lectus pretium consequat felis justo pharetra vestibulum, quisque ut cras metus vitae sit nam ultricies velit massa phasellus rhoncus. \nEt habitasse vel nulla gravida pretium facilisis amet rhoncus nam ornare ut hac, purus ac dui aliquet eleifend fames malesuada lacinia leo curabitur rhoncus, eleifend vivamus sed orci magna torquent augue cursus risus ullamcorper massa. \n</p>\n<p>\nScelerisque aliquet curabitur nisl ullamcorper vehicula phasellus metus rhoncus habitant iaculis tincidunt, ac leo tempor vulputate torquent quis dolor luctus faucibus ultrices. \nAdipiscing massa vehicula risus nullam nunc etiam per nam, cursus fames netus vulputate tempor sociosqu neque. \nNullam nostra sagittis tempor nullam taciti enim pellentesque egestas dapibus, congue ut aptent condimentum nullam scelerisque libero ornare, velit metus ante ut purus aliquam etiam adipiscing. \nEgestas congue nam auctor mattis mi feugiat ultricies elit, facilisis euismod ullamcorper suspendisse ut litora vivamus orci consectetur, urna leo nostra molestie gravida curabitur nibh. \n</p>\n<p>\nHac lacinia quisque tristique quisque blandit augue commodo ultricies pulvinar lacus condimentum, curabitur molestie ut eget felis vehicula inceptos phasellus cursus turpis. \n</p>', 0, 2, 2),
(3, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum fusce ut rhoncus per erat suscipit, malesuada habitasse commodo nunc ullamcorper urna etiam et, inceptos non justo nisi convallis scelerisque. \nEget consectetur pretium sit ad ultricies, maecenas lectus molestie interdum donec ad, odio ornare massa nulla. \nPurus pulvinar augue curabitur aliquam velit et posuere, aenean amet vivamus tortor praesent elementum nostra, habitant lectus nunc tempor aliquam lobortis. \nVolutpat ante tempus consequat leo per vivamus, arcu luctus turpis mi congue tristique platea, ut molestie massa lorem auctor. \nFacilisis augue suscipit iaculis tempus eu netus inceptos conubia nisl pellentesque nec maecenas, eget lectus adipiscing primis orci diam cursus etiam rutrum taciti. \n</p>\n<p>\nLobortis suspendisse habitant lobortis mi urna ullamcorper curabitur sagittis volutpat etiam, quisque felis faucibus euismod hac et iaculis viverra eu dolor enim, lobortis adipiscing posuere proin non inceptos varius elementum cras. \nLuctus quisque elementum viverra etiam donec pharetra orci, blandit lobortis dictum nostra massa quisque. \nSapien et diam dictum nibh nisl porttitor suscipit amet, vitae lacinia egestas et hendrerit felis aenean nisi, aptent neque non nunc cursus dictum pretium. \nFusce molestie imperdiet dui nisi congue volutpat fermentum ultricies diam, mi arcu per eu libero curabitur praesent egestas, risus nostra enim leo orci duis accumsan placerat. \n</p>\n<p>\nTortor duis arcu, conubia. \n</p>', 0, 3, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `text`, `seen`, `created_at`, `updated_at`) VALUES
(1, 'Dupont', 'dupont@la.fr', 'Lorem ipsum inceptos malesuada leo fusce tortor sociosqu semper, facilisis semper class tempus faucibus tristique duis eros, cubilia quisque habitasse aliquam fringilla orci non. Vel laoreet dolor enim justo facilisis neque accumsan, in ad venenatis hac per dictumst nulla ligula, donec mollis massa porttitor ullamcorper risus. Eu platea fringilla, habitasse.', 0, '2018-12-10 13:38:32', '2018-12-10 13:38:32'),
(2, 'Durand', 'durand@la.fr', ' Lorem ipsum erat non elit ultrices placerat, netus metus feugiat non conubia fusce porttitor, sociosqu diam commodo metus in. Himenaeos vitae aptent consequat luctus purus eleifend enim, sollicitudin eleifend porta malesuada ac class conubia, condimentum mauris facilisis conubia quis scelerisque. Lacinia tempus nullam felis fusce ac potenti netus ornare semper molestie, iaculis fermentum ornare curabitur tincidunt imperdiet scelerisque imperdiet euismod.', 0, '2018-12-10 13:38:32', '2018-12-10 13:38:32'),
(3, 'Martin', 'martin@la.fr', 'Lorem ipsum tempor netus aenean ligula habitant vehicula tempor ultrices, placerat sociosqu ultrices consectetur ullamcorper tincidunt quisque tellus, ante nostra euismod nec suspendisse sem curabitur elit. Malesuada lacus viverra sagittis sit ornare orci, augue nullam adipiscing pulvinar libero aliquam vestibulum, platea cursus pellentesque leo dui. Lectus curabitur euismod ad, erat.', 1, '2018-12-10 13:38:32', '2018-12-10 13:38:32');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2014_10_21_105844_create_roles_table', 1),
('2014_10_21_110325_create_foreign_keys', 1),
('2014_10_24_205441_create_contact_table', 1),
('2014_10_26_172107_create_posts_table', 1),
('2014_10_26_172631_create_tags_table', 1),
('2014_10_26_172904_create_post_tag_table', 1),
('2014_10_26_222018_create_comments_table', 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `posts`
--

INSERT INTO `posts` (`id`, `created_at`, `updated_at`, `title`, `slug`, `summary`, `content`, `seen`, `active`, `user_id`) VALUES
(1, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 1', 'post-1', '<img alt=\"\" src=\"/filemanager/userfiles/user2/mega-champignon.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum pharetra bibendum blandit lobortis tincidunt aliquet congue molestie, inceptos lectus donec pellentesque egestas bibendum adipiscing eleifend, venenatis interdum massa vestibulum a lorem ante tempus. \nEt quis netus conubia dapibus gravida varius neque volutpat, cursus habitant risus nec leo eu massa ultrices, consectetur porta laoreet accumsan dui quis litora. \n</p>', '<p>\nLorem ipsum quam arcu commodo ut eu nisl metus, nec gravida euismod vulputate arcu pellentesque adipiscing ut, varius porttitor per placerat ut suscipit semper. \nQuisque amet dolor malesuada volutpat turpis nisi dictumst, diam felis facilisis integer habitant conubia, sem suspendisse morbi etiam suspendisse aliquam. \nErat lobortis potenti enim sociosqu pulvinar eget urna pellentesque ac quam proin nibh ipsum, praesent blandit neque donec fringilla nisl condimentum enim potenti ipsum egestas. \nNisl felis venenatis porta orci sagittis iaculis porta scelerisque lobortis, massa aenean tortor ullamcorper lacinia sed tincidunt tristique convallis, aenean pellentesque a habitasse aliquet lobortis pulvinar suscipit. \n</p>\n<p>\nAugue massa nisi enim malesuada dictum condimentum erat lacus vestibulum fames aliquam elementum vel ipsum, lobortis inceptos mattis pharetra vestibulum litora fringilla quam pellentesque risus semper sem cubilia. \nFacilisis posuere faucibus aliquam per hac commodo aliquet nisi tellus, condimentum porttitor erat elementum purus quisque curabitur egestas, adipiscing eget orci nec bibendum nostra metus neque. \nFusce donec suscipit arcu ac in per pulvinar lorem justo, id commodo aliquam vitae mollis porta iaculis rutrum semper viverra, dui platea tempor vel pretium orci porta aenean. \nFaucibus hac commodo odio himenaeos tempor scelerisque a ultricies arcu nostra, hendrerit fringilla inceptos dictumst elit sed porta ultricies congue lectus, curae augue fusce orci viverra velit accumsan odio sociosqu. \n</p>\n<p>\nDuis laoreet tellus orci tortor nisl quam, euismod lorem quis magna eleifend pellentesque quis, molestie odio quis nullam habitasse. \nPlatea in nulla purus eros nisi morbi phasellus lacus torquent laoreet vitae aptent mattis aenean, aliquam interdum et egestas per himenaeos sed curabitur himenaeos molestie lacinia nec. \nNullam libero adipiscing netus maecenas sodales porttitor justo bibendum praesent dictum, ac class litora quisque vel arcu vitae class libero, aenean rhoncus auctor condimentum auctor fusce quis elementum aliquet. \nFacilisis tristique nisi condimentum volutpat erat eget imperdiet, tincidunt tristique condimentum tellus aliquet suscipit, felis eros auctor eros tellus quisque. \n</p>\n<p>\nPlacerat auctor eget nostra cursus mauris a, lectus aliquam nec erat imperdiet, dolor senectus dolor gravida egestas. \nRutrum euismod molestie netus curae libero ultrices mauris condimentum et facilisis fringilla aenean leo molestie, donec vel posuere ultrices pharetra ad dictumst lobortis tristique fermentum dapibus ornare. \nInceptos consectetur platea odio duis praesent maecenas risus, eu curabitur lacinia suscipit ipsum eget scelerisque consectetur, mi at netus elementum sollicitudin curae. \nPotenti pharetra aenean dictum venenatis ut tempor, hac ligula integer suspendisse massa dictumst, dapibus accumsan justo faucibus convallis. \nNeque aenean nunc ullamcorper augue accumsan pellentesque, himenaeos morbi sed nibh ultrices luctus, duis quis torquent turpis ut. \n</p>\n<p>\nLorem et neque suscipit aptent dictumst libero cursus leo sapien placerat, curabitur morbi tellus dolor ante aliquet nostra tempus placerat. \nCondimentum dui vestibulum curabitur maecenas curabitur nibh placerat feugiat, lobortis tempus vulputate non aliquet potenti rutrum iaculis venenatis, cursus senectus turpis adipiscing hac aliquet vehicula. \nMi nisi ut fermentum bibendum quis sit eros netus euismod arcu habitant egestas luctus, varius leo congue class nisl velit cursus litora neque orci accumsan ipsum. \nVenenatis consectetur maecenas nisi est odio diam pretium leo, bibendum primis et cursus ut aliquam rhoncus nec, nisl aliquam aliquet tempus vitae egestas vitae. \n</p>', 0, 1, 1),
(2, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 2', 'post-2', '<img alt=\"\" src=\"/filemanager/userfiles/user2/goomba.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum pulvinar semper sem porta habitant phasellus consectetur, a integer primis lacinia etiam sagittis purus lacus purus, enim vel amet magna arcu a netus. \nPellentesque vel conubia nec amet tincidunt sapien curabitur massa, nullam class malesuada vitae sed dolor pellentesque posuere primis, eros fringilla netus lacus in odio aliquam. \n</p>', '<p>Lorem ipsum convallis ac curae non elit ultrices placerat netus metus feugiat, non conubia fusce porttitor sociosqu diam commodo metus in himenaeos, vitae aptent consequat luctus purus eleifend enim sollicitudin eleifend porta. Malesuada ac class conubia condimentum mauris facilisis conubia quis scelerisque lacinia, tempus nullam felis fusce ac potenti netus ornare semper. Molestie iaculis fermentum ornare curabitur tincidunt imperdiet scelerisque, imperdiet euismod scelerisque torquent curae rhoncus, sollicitudin tortor placerat aptent hac nec. Posuere suscipit sed tortor neque urna hendrerit vehicula duis litora tristique congue nec auctor felis libero, ornare habitasse nec elit felis inceptos tellus inceptos cubilia quis mattis faucibus sem non.</p>\n\n<p>Odio fringilla class aliquam metus ipsum lorem luctus pharetra dictum, vehicula tempus in venenatis gravida ut gravida proin orci, quis sed platea mi quisque hendrerit semper hendrerit. Facilisis ante sapien faucibus ligula commodo vestibulum rutrum pretium, varius sem aliquet himenaeos dolor cursus nunc habitasse, aliquam ut curabitur ipsum luctus ut rutrum. Odio condimentum donec suscipit molestie est etiam sit rutrum dui nostra, sem aliquet conubia nullam sollicitudin rhoncus venenatis vivamus rhoncus netus, risus tortor non mauris turpis eget integer nibh dolor. Commodo venenatis ut molestie semper adipiscing amet cras, class donec sapien malesuada auctor sapien arcu inceptos, aenean consequat metus litora mattis vivamus.</p>\n\n<pre>\n<code class=\"language-php\">protected function getUserByRecaller($recaller)\n{\n	if ($this-&gt;validRecaller($recaller) &amp;&amp; ! $this-&gt;tokenRetrievalAttempted)\n	{\n		$this-&gt;tokenRetrievalAttempted = true;\n\n		list($id, $token) = explode(\"|\", $recaller, 2);\n\n		$this-&gt;viaRemember = ! is_null($user = $this-&gt;provider-&gt;retrieveByToken($id, $token));\n\n		return $user;\n	}\n}</code></pre>\n\n<p>Feugiat arcu adipiscing mauris primis ante ullamcorper ad nisi, lobortis arcu per orci malesuada blandit metus tortor, urna turpis consectetur porttitor egestas sed eleifend. Eget tincidunt pharetra varius tincidunt morbi malesuada elementum mi torquent mollis, eu lobortis curae purus amet vivamus amet nulla torquent, nibh eu diam aliquam pretium donec aliquam tempus lacus. Tempus feugiat lectus cras non velit mollis sit et integer, egestas habitant auctor integer sem at nam massa himenaeos, netus vel dapibus nibh malesuada leo fusce tortor. Sociosqu semper facilisis semper class tempus faucibus tristique duis eros, cubilia quisque habitasse aliquam fringilla orci non vel, laoreet dolor enim justo facilisis neque accumsan in.</p>\n\n<p>Ad venenatis hac per dictumst nulla ligula donec, mollis massa porttitor ullamcorper risus eu platea, fringilla habitasse suscipit pellentesque donec est. Habitant vehicula tempor ultrices placerat sociosqu ultrices consectetur ullamcorper tincidunt quisque tellus, ante nostra euismod nec suspendisse sem curabitur elit malesuada lacus. Viverra sagittis sit ornare orci augue nullam adipiscing pulvinar libero aliquam vestibulum platea cursus pellentesque leo dui lectus, curabitur euismod ad erat curae non elit ultrices placerat netus metus feugiat non conubia fusce porttitor. Sociosqu diam commodo metus in himenaeos vitae aptent consequat luctus purus eleifend enim sollicitudin eleifend, porta malesuada ac class conubia condimentum mauris facilisis conubia quis scelerisque lacinia.</p>\n\n<p>Tempus nullam felis fusce ac potenti netus ornare semper molestie iaculis, fermentum ornare curabitur tincidunt imperdiet scelerisque imperdiet euismod. Scelerisque torquent curae rhoncus sollicitudin tortor placerat aptent hac, nec posuere suscipit sed tortor neque urna hendrerit, vehicula duis litora tristique congue nec auctor. Felis libero ornare habitasse nec elit felis, inceptos tellus inceptos cubilia quis mattis, faucibus sem non odio fringilla. Class aliquam metus ipsum lorem luctus pharetra dictum vehicula, tempus in venenatis gravida ut gravida proin orci, quis sed platea mi quisque hendrerit semper.</p>\n', 0, 1, 2),
(3, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 3', 'post-3', '<img alt=\"\" src=\"/filemanager/userfiles/user2/rouge-shell.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum tristique quam volutpat posuere hendrerit laoreet sapien, lorem vestibulum viverra turpis fermentum taciti neque viverra pellentesque, quisque aenean morbi magna rutrum arcu habitant. \nPlacerat sit aliquam etiam hac massa convallis, nam aptent viverra porta adipiscing ligula himenaeos, viverra lorem quam arcu tortor. \nFacilisis non semper luctus, vestibulum cras. \n</p>', '<p>\nLorem ipsum neque elementum vehicula lacinia porta arcu aenean, nec bibendum duis sociosqu dapibus tortor etiam, dolor vel et faucibus laoreet potenti aliquam. \nMauris tincidunt mollis pretium lorem potenti, amet sagittis habitasse donec a quisque, etiam aptent tortor hendrerit. \nUllamcorper sapien amet aliquam convallis posuere urna vehicula, pharetra a ut lacus amet nullam convallis sapien, blandit turpis sem ad neque egestas. \nSemper suscipit vitae molestie aptent pulvinar quisque a suscipit id lacus, etiam ullamcorper ultrices fusce cubilia nibh justo proin nunc auctor lorem, feugiat leo mauris dapibus viverra curabitur ante tincidunt etiam. \n</p>\n<p>\nMi phasellus donec malesuada hac pharetra faucibus leo eu, molestie sagittis litora feugiat lorem ligula dictum morbi congue, proin blandit porta habitant class ullamcorper leo. \nSuspendisse elit gravida dui tortor urna accumsan quam vivamus, ut mauris torquent risus posuere primis aenean, nibh congue eget dapibus senectus laoreet placerat. \nImperdiet habitant dapibus vivamus elementum duis aliquam dui vel porta mollis, dolor malesuada eros taciti rhoncus lacus curae velit dictum. \nUltrices himenaeos neque ac ultricies ut purus quis, sollicitudin magna feugiat viverra magna donec, euismod inceptos leo etiam sed aenean. \n</p>\n<p>\nHendrerit maecenas odio nullam nec blandit neque feugiat hac, interdum placerat vel et ligula maecenas egestas mollis sollicitudin, amet dui enim curabitur nibh leo fringilla. \nJusto aliquet ipsum pharetra dui vitae fames proin diam, est rutrum praesent purus rutrum at suspendisse, dictumst himenaeos ultricies fusce per cras lacus. \nPharetra quisque lobortis curabitur pulvinar etiam porttitor nam, bibendum habitasse ante diam molestie dictumst nisi dictumst, interdum augue nullam tellus in suscipit. \nAliquam et nam donec tincidunt porta quis nibh id in, non porttitor fames neque pharetra odio maecenas tellus placerat, suscipit magna eros nibh metus dictum varius vivamus. \n</p>\n<p>\nMagna nam maecenas platea ad maecenas fringilla blandit aptent nostra amet, diam nibh nisi pulvinar a senectus vel potenti ultricies himenaeos curae, habitant lacus augue convallis porttitor eros sociosqu tempus quisque. \nFacilisis lectus lacus ut ad aliquam enim tempor cursus, fusce malesuada placerat himenaeos bibendum euismod aliquet, augue consequat ante fringilla convallis nostra sed egestas, potenti volutpat ac elit purus nec. \nTellus commodo pharetra fusce phasellus congue urna mi dui, quisque senectus orci blandit lacinia cursus imperdiet turpis tempus, eros pretium lectus pretium ut pulvinar integer. \nTellus rhoncus semper dictum risus inceptos venenatis aliquam nulla eleifend, sodales enim orci tincidunt ut mauris curae class, in mollis per facilisis scelerisque aenean erat sollicitudin. \n</p>\n<p>\nTempor eros risus primis tincidunt rhoncus tempus ultrices augue pretium varius at fusce volutpat, pretium conubia platea porttitor tellus in viverra egestas purus lacinia diam felis, class morbi congue et phasellus tellus eleifend urna hac vulputate praesent ante. \nPlatea nostra fames curae nisl ultricies augue vestibulum elementum litora integer, arcu conubia primis aenean ante etiam inceptos nibh dolor enim laoreet, duis hendrerit rutrum suscipit fusce risus sagittis tortor fusce. \nTortor lobortis sit mattis consectetur potenti nam congue, condimentum sem donec varius augue nunc in, erat fringilla et fusce praesent nec. \n</p>\n<p>\nDictumst lacus faucibus sapien lectus imperdiet pulvinar cursus nisi habitasse porttitor urna, integer conubia eros quis pretium ornare blandit molestie odio. \n</p>', 0, 1, 2),
(4, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 4', 'post-4', '<img alt=\"\" src=\"/filemanager/userfiles/user2/rouge-shyguy.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum iaculis pharetra aliquam ipsum, ante ultricies eu nostra sed enim, donec commodo aliquet litora. \nMorbi porttitor magna tellus quis vitae egestas fames tristique aptent, curabitur nec urna primis consectetur facilisis aliquet hac non, interdum duis felis conubia etiam pulvinar consequat tellus. \nVivamus cubilia pharetra ligula vulputate, consectetur hac. \n</p>', '<p>\nLorem ipsum taciti consectetur tempor primis id ultrices taciti, etiam laoreet vivamus lobortis rutrum odio malesuada enim cras, suspendisse eu dui pretium primis enim aenean. \nMolestie pretium platea curabitur adipiscing dui suscipit curae, vulputate quis convallis aliquam nisl magna non laoreet, venenatis lobortis tellus mollis sociosqu malesuada. \nAptent class fermentum suspendisse class porttitor vehicula lacus donec morbi sociosqu, massa nisi erat duis hac lobortis tempus inceptos quis erat, accumsan fames sem non purus ut tempus sem nec. \nAt lectus imperdiet dui netus sagittis interdum adipiscing, lorem phasellus consequat donec sociosqu eget ultrices, ultricies lectus et nisl pulvinar scelerisque. \n</p>\n<p>\nRutrum nullam tempor aenean amet morbi feugiat interdum placerat feugiat ante dui, cubilia et duis erat egestas ultricies iaculis neque aliquam curabitur, lacus quam metus habitant dictumst lobortis scelerisque tempus molestie felis. \nAenean cras justo aliquam tellus dui semper nulla quis non vivamus euismod, curae consectetur imperdiet est vitae consectetur per dapibus metus fermentum, et vestibulum enim maecenas donec odio nostra tellus hendrerit suspendisse. \nId aliquet maecenas scelerisque integer placerat lorem etiam nec, id venenatis aptent vestibulum sociosqu vivamus vehicula, massa tempor quis mattis conubia malesuada sociosqu. \nSemper tortor tempus lacinia pellentesque mauris per consequat purus urna sagittis morbi suscipit blandit venenatis, hendrerit porttitor lacinia dui tellus aenean blandit curabitur metus dapibus vivamus purus elementum. \n</p>\n<p>\nVarius netus orci facilisis vulputate lobortis leo sollicitudin tincidunt eleifend velit, nullam augue pharetra magna lectus nisl sodales curabitur sollicitudin habitant, pellentesque rutrum eleifend fringilla vel libero lacus maecenas ipsum. \nAptent conubia magna sem magna diam cras interdum, etiam aenean amet adipiscing faucibus rhoncus, vel ullamcorper curabitur tristique sodales ut. \nMollis erat commodo adipiscing platea in donec himenaeos ut urna, tempor amet urna vulputate a enim risus et elementum curabitur, volutpat fames per sodales duis fames ipsum blandit. \nPer ad eu pulvinar donec at posuere ullamcorper, erat velit neque elit lobortis ultrices sit senectus, vivamus libero elit pulvinar porta mattis. \n</p>\n<p>\nFeugiat magna lobortis phasellus suscipit bibendum lobortis class, nec mattis elementum erat mauris fringilla ultrices, nisl fusce elementum imperdiet risus proin. \nDolor ligula vel tristique ipsum fames per quis, suspendisse aenean nam vehicula rutrum vehicula maecenas porta, fermentum ultrices eros cubilia curae praesent. \nSenectus posuere elit bibendum semper tempor ipsum integer laoreet lacus, turpis sapien placerat donec libero adipiscing nam sed nisi, habitasse curabitur per odio ad facilisis vulputate fermentum. \nTempus inceptos in gravida pretium pharetra ac rutrum eros arcu habitant, faucibus congue taciti donec venenatis etiam netus aliquam posuere himenaeos, vestibulum aliquam ligula non odio mauris non vitae ante. \n</p>\n<p>\nQuam molestie neque urna et dapibus phasellus, odio cras curae fringilla dolor congue, auctor dictumst proin pellentesque augue. \nLibero quisque ornare sem curae hendrerit libero pellentesque lectus, libero tincidunt ac adipiscing convallis dapibus sodales, sit gravida pretium magna dui quam primis. \nUt pellentesque luctus suscipit rutrum erat eleifend fames euismod, bibendum massa aliquet curae integer fringilla nunc ullamcorper, suspendisse tellus sagittis euismod vitae cras dictum. \nSit torquent aenean netus lorem leo libero, gravida sollicitudin risus fusce imperdiet, mi faucibus aliquam ut metus. \nFusce sapien quisque iaculis, phasellus. \n</p>', 0, 1, 2);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
CREATE TABLE IF NOT EXISTS `post_tag` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_tag_post_id_foreign` (`post_id`),
  KEY `post_tag_tag_id_foreign` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `post_tag`
--

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 2, 2),
(5, 2, 3),
(6, 3, 1),
(7, 3, 2),
(8, 3, 4);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `roles`
--

INSERT INTO `roles` (`id`, `title`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin', '2018-12-10 13:38:31', '2018-12-10 13:38:31'),
(2, 'Redactor', 'redac', '2018-12-10 13:38:31', '2018-12-10 13:38:31'),
(3, 'User', 'user', '2018-12-10 13:38:31', '2018-12-10 13:38:31');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tag` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_tag_unique` (`tag`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `tags`
--

INSERT INTO `tags` (`id`, `created_at`, `updated_at`, `tag`) VALUES
(1, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag1'),
(2, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag2'),
(3, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag3'),
(4, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag4');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `valid` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `confirmation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role_id`, `seen`, `valid`, `confirmed`, `confirmation_code`, `created_at`, `updated_at`, `remember_token`) VALUES
(1, 'GreatAdmin', 'admin@la.fr', '$2y$10$CL5XUr3YoVwrqedqg39BOea68mAbm63MWf4OQnmjhgPDlC3GHXhhK', 1, 1, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(2, 'GreatRedactor', 'redac@la.fr', '$2y$10$yvOMN/KpOvT9ITCvKvjd/eiF5wdw4kgHLXI8BKKo4.5fUJLtJjZaW', 2, 1, 1, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(3, 'Walker', 'walker@la.fr', '$2y$10$3JoNJsjJxkkOvmiIFION2OsS.QyXMOsXV0R0lGOGb8WwE2M3uy3Ve', 3, 0, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(4, 'Slacker', 'slacker@la.fr', '$2y$10$hAnb3Vs8Bxjj4m4JpFNRCuGuOoGVSvPTZvK0YTgcSiIVHUcELq0jC', 3, 0, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL);

--
-- Apribojimai eksportuotom lentelėm
--

--
-- Apribojimai lentelei `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Apribojimai lentelei `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Apribojimai lentelei `post_tag`
--
ALTER TABLE `post_tag`
  ADD CONSTRAINT `post_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `post_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Apribojimai lentelei `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
