--
-- Database: `newdb`
--
DROP DATABASE IF EXISTS `newdb`;
CREATE DATABASE IF NOT EXISTS `newdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `newdb`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'new', '$2y$12$prS16k300EQp4RNwouPSgOrThtl4Yv4mK17xXV5L0Ne9IE8WSFBha');
