--
-- Database: `php_clicks`
--
DROP DATABASE IF EXISTS `php_clicks`;
CREATE DATABASE IF NOT EXISTS `php_clicks` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `php_clicks`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `student`
--

INSERT INTO `student` (`student_id`, `first_name`, `last_name`, `email`, `user_name`, `password`, `date_added`) VALUES
(8, 'test', 'test', 'test@npp.com', 'testtest', '098f6bcd4621d373cade4e832627b4f6', '2019-01-16 17:58:11');
