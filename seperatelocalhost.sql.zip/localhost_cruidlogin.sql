--
-- Database: `cruidlogin`
--
DROP DATABASE IF EXISTS `cruidlogin`;
CREATE DATABASE IF NOT EXISTS `cruidlogin` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `cruidlogin`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'cruidlogin', 'pastas@pastas.pp', 'cruidlogin', 'b6fb5f0768688098d38ee8d24b9946e8'),
(2, 'cruidlogin2', 'test@npp.com', 'cruidlogin2', 'eeec8954305c0ca0f1c02c86c9e39459');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `qty` int(5) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `login_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_products_1` (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `products`
--

INSERT INTO `products` (`id`, `name`, `qty`, `price`, `login_id`) VALUES
(1, 'produktas 1', 15, '150.00', 1),
(2, '123', 1, '15.00', 2);

--
-- Apribojimai eksportuotom lentelėm
--

--
-- Apribojimai lentelei `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products_1` FOREIGN KEY (`login_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
