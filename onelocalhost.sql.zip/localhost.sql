-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2019 m. Sau 17 d. 19:21
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cruid`
--
DROP DATABASE IF EXISTS `cruid`;
CREATE DATABASE IF NOT EXISTS `cruid` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `cruid`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(3) NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `name`, `age`, `email`) VALUES
(1, 'Vardas', 30, 'pastas@pastas.pp');
--
-- Database: `cruidlogin`
--
DROP DATABASE IF EXISTS `cruidlogin`;
CREATE DATABASE IF NOT EXISTS `cruidlogin` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `cruidlogin`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'cruidlogin', 'pastas@pastas.pp', 'cruidlogin', 'b6fb5f0768688098d38ee8d24b9946e8'),
(2, 'cruidlogin2', 'test@npp.com', 'cruidlogin2', 'eeec8954305c0ca0f1c02c86c9e39459');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `qty` int(5) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `login_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_products_1` (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `products`
--

INSERT INTO `products` (`id`, `name`, `qty`, `price`, `login_id`) VALUES
(1, 'produktas 1', 15, '150.00', 1),
(2, '123', 1, '15.00', 2);

--
-- Apribojimai eksportuotom lentelėm
--

--
-- Apribojimai lentelei `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products_1` FOREIGN KEY (`login_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
--
-- Database: `laravel5example`
--
DROP DATABASE IF EXISTS `laravel5example`;
CREATE DATABASE IF NOT EXISTS `laravel5example` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `laravel5example`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_id_foreign` (`user_id`),
  KEY `comments_post_id_foreign` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `comments`
--

INSERT INTO `comments` (`id`, `created_at`, `updated_at`, `content`, `seen`, `user_id`, `post_id`) VALUES
(1, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum senectus dictum laoreet euismod primis nam sagittis dapibus, feugiat lectus congue ad semper sociosqu consequat cursus. \nIn nam etiam pharetra blandit quis justo elit class senectus ad, sem imperdiet tempus leo arcu dolor integer porta platea, varius congue vehicula fusce inceptos ultricies auctor platea interdum. \nAd neque elit molestie accumsan pulvinar mauris vulputate, congue a quisque ornare curae sociosqu. \nVivamus eros etiam amet platea fames per ullamcorper, elementum conubia nulla praesent integer platea. \nConsequat consectetur luctus eleifend sem id ullamcorper at etiam, nisi habitant donec himenaeos curabitur venenatis tellus. \n</p>\n<p>\nMi dictum eu at dictum lacinia curabitur lacinia, eleifend vulputate maecenas rhoncus malesuada. \nEgestas dolor curae placerat velit a tincidunt sodales bibendum taciti, senectus libero metus ultricies ac consequat blandit convallis, felis dapibus a mollis leo litora primis faucibus. \nAmet donec fames auctor tempor integer ac suspendisse, aliquet sed nullam at congue rhoncus diam porttitor, congue neque pretium integer eros laoreet. \nLectus morbi velit a ornare donec rutrum aliquam malesuada ultricies tempus sem dictumst sodales, pellentesque vivamus cras neque metus integer aliquam auctor mi netus curabitur turpis, lacinia sollicitudin etiam conubia elementum cras suscipit laoreet praesent aenean vehicula fermentum. \n</p>\n<p>\nSit integer imperdiet dolor auctor tortor, aptent libero habitant duis. \n</p>', 0, 2, 1),
(2, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum class gravida convallis urna amet lectus quisque morbi, semper molestie odio mi ad posuere praesent consequat cubilia accumsan, eget mauris velit pharetra mauris diam hac vulputate. \nRutrum phasellus nam quisque malesuada conubia sem lectus pretium consequat felis justo pharetra vestibulum, quisque ut cras metus vitae sit nam ultricies velit massa phasellus rhoncus. \nEt habitasse vel nulla gravida pretium facilisis amet rhoncus nam ornare ut hac, purus ac dui aliquet eleifend fames malesuada lacinia leo curabitur rhoncus, eleifend vivamus sed orci magna torquent augue cursus risus ullamcorper massa. \n</p>\n<p>\nScelerisque aliquet curabitur nisl ullamcorper vehicula phasellus metus rhoncus habitant iaculis tincidunt, ac leo tempor vulputate torquent quis dolor luctus faucibus ultrices. \nAdipiscing massa vehicula risus nullam nunc etiam per nam, cursus fames netus vulputate tempor sociosqu neque. \nNullam nostra sagittis tempor nullam taciti enim pellentesque egestas dapibus, congue ut aptent condimentum nullam scelerisque libero ornare, velit metus ante ut purus aliquam etiam adipiscing. \nEgestas congue nam auctor mattis mi feugiat ultricies elit, facilisis euismod ullamcorper suspendisse ut litora vivamus orci consectetur, urna leo nostra molestie gravida curabitur nibh. \n</p>\n<p>\nHac lacinia quisque tristique quisque blandit augue commodo ultricies pulvinar lacus condimentum, curabitur molestie ut eget felis vehicula inceptos phasellus cursus turpis. \n</p>', 0, 2, 2),
(3, '2018-12-10 13:38:34', '2018-12-10 13:38:34', '<p>\nLorem ipsum fusce ut rhoncus per erat suscipit, malesuada habitasse commodo nunc ullamcorper urna etiam et, inceptos non justo nisi convallis scelerisque. \nEget consectetur pretium sit ad ultricies, maecenas lectus molestie interdum donec ad, odio ornare massa nulla. \nPurus pulvinar augue curabitur aliquam velit et posuere, aenean amet vivamus tortor praesent elementum nostra, habitant lectus nunc tempor aliquam lobortis. \nVolutpat ante tempus consequat leo per vivamus, arcu luctus turpis mi congue tristique platea, ut molestie massa lorem auctor. \nFacilisis augue suscipit iaculis tempus eu netus inceptos conubia nisl pellentesque nec maecenas, eget lectus adipiscing primis orci diam cursus etiam rutrum taciti. \n</p>\n<p>\nLobortis suspendisse habitant lobortis mi urna ullamcorper curabitur sagittis volutpat etiam, quisque felis faucibus euismod hac et iaculis viverra eu dolor enim, lobortis adipiscing posuere proin non inceptos varius elementum cras. \nLuctus quisque elementum viverra etiam donec pharetra orci, blandit lobortis dictum nostra massa quisque. \nSapien et diam dictum nibh nisl porttitor suscipit amet, vitae lacinia egestas et hendrerit felis aenean nisi, aptent neque non nunc cursus dictum pretium. \nFusce molestie imperdiet dui nisi congue volutpat fermentum ultricies diam, mi arcu per eu libero curabitur praesent egestas, risus nostra enim leo orci duis accumsan placerat. \n</p>\n<p>\nTortor duis arcu, conubia. \n</p>', 0, 3, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `text`, `seen`, `created_at`, `updated_at`) VALUES
(1, 'Dupont', 'dupont@la.fr', 'Lorem ipsum inceptos malesuada leo fusce tortor sociosqu semper, facilisis semper class tempus faucibus tristique duis eros, cubilia quisque habitasse aliquam fringilla orci non. Vel laoreet dolor enim justo facilisis neque accumsan, in ad venenatis hac per dictumst nulla ligula, donec mollis massa porttitor ullamcorper risus. Eu platea fringilla, habitasse.', 0, '2018-12-10 13:38:32', '2018-12-10 13:38:32'),
(2, 'Durand', 'durand@la.fr', ' Lorem ipsum erat non elit ultrices placerat, netus metus feugiat non conubia fusce porttitor, sociosqu diam commodo metus in. Himenaeos vitae aptent consequat luctus purus eleifend enim, sollicitudin eleifend porta malesuada ac class conubia, condimentum mauris facilisis conubia quis scelerisque. Lacinia tempus nullam felis fusce ac potenti netus ornare semper molestie, iaculis fermentum ornare curabitur tincidunt imperdiet scelerisque imperdiet euismod.', 0, '2018-12-10 13:38:32', '2018-12-10 13:38:32'),
(3, 'Martin', 'martin@la.fr', 'Lorem ipsum tempor netus aenean ligula habitant vehicula tempor ultrices, placerat sociosqu ultrices consectetur ullamcorper tincidunt quisque tellus, ante nostra euismod nec suspendisse sem curabitur elit. Malesuada lacus viverra sagittis sit ornare orci, augue nullam adipiscing pulvinar libero aliquam vestibulum, platea cursus pellentesque leo dui. Lectus curabitur euismod ad, erat.', 1, '2018-12-10 13:38:32', '2018-12-10 13:38:32');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2014_10_21_105844_create_roles_table', 1),
('2014_10_21_110325_create_foreign_keys', 1),
('2014_10_24_205441_create_contact_table', 1),
('2014_10_26_172107_create_posts_table', 1),
('2014_10_26_172631_create_tags_table', 1),
('2014_10_26_172904_create_post_tag_table', 1),
('2014_10_26_222018_create_comments_table', 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `posts`
--

INSERT INTO `posts` (`id`, `created_at`, `updated_at`, `title`, `slug`, `summary`, `content`, `seen`, `active`, `user_id`) VALUES
(1, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 1', 'post-1', '<img alt=\"\" src=\"/filemanager/userfiles/user2/mega-champignon.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum pharetra bibendum blandit lobortis tincidunt aliquet congue molestie, inceptos lectus donec pellentesque egestas bibendum adipiscing eleifend, venenatis interdum massa vestibulum a lorem ante tempus. \nEt quis netus conubia dapibus gravida varius neque volutpat, cursus habitant risus nec leo eu massa ultrices, consectetur porta laoreet accumsan dui quis litora. \n</p>', '<p>\nLorem ipsum quam arcu commodo ut eu nisl metus, nec gravida euismod vulputate arcu pellentesque adipiscing ut, varius porttitor per placerat ut suscipit semper. \nQuisque amet dolor malesuada volutpat turpis nisi dictumst, diam felis facilisis integer habitant conubia, sem suspendisse morbi etiam suspendisse aliquam. \nErat lobortis potenti enim sociosqu pulvinar eget urna pellentesque ac quam proin nibh ipsum, praesent blandit neque donec fringilla nisl condimentum enim potenti ipsum egestas. \nNisl felis venenatis porta orci sagittis iaculis porta scelerisque lobortis, massa aenean tortor ullamcorper lacinia sed tincidunt tristique convallis, aenean pellentesque a habitasse aliquet lobortis pulvinar suscipit. \n</p>\n<p>\nAugue massa nisi enim malesuada dictum condimentum erat lacus vestibulum fames aliquam elementum vel ipsum, lobortis inceptos mattis pharetra vestibulum litora fringilla quam pellentesque risus semper sem cubilia. \nFacilisis posuere faucibus aliquam per hac commodo aliquet nisi tellus, condimentum porttitor erat elementum purus quisque curabitur egestas, adipiscing eget orci nec bibendum nostra metus neque. \nFusce donec suscipit arcu ac in per pulvinar lorem justo, id commodo aliquam vitae mollis porta iaculis rutrum semper viverra, dui platea tempor vel pretium orci porta aenean. \nFaucibus hac commodo odio himenaeos tempor scelerisque a ultricies arcu nostra, hendrerit fringilla inceptos dictumst elit sed porta ultricies congue lectus, curae augue fusce orci viverra velit accumsan odio sociosqu. \n</p>\n<p>\nDuis laoreet tellus orci tortor nisl quam, euismod lorem quis magna eleifend pellentesque quis, molestie odio quis nullam habitasse. \nPlatea in nulla purus eros nisi morbi phasellus lacus torquent laoreet vitae aptent mattis aenean, aliquam interdum et egestas per himenaeos sed curabitur himenaeos molestie lacinia nec. \nNullam libero adipiscing netus maecenas sodales porttitor justo bibendum praesent dictum, ac class litora quisque vel arcu vitae class libero, aenean rhoncus auctor condimentum auctor fusce quis elementum aliquet. \nFacilisis tristique nisi condimentum volutpat erat eget imperdiet, tincidunt tristique condimentum tellus aliquet suscipit, felis eros auctor eros tellus quisque. \n</p>\n<p>\nPlacerat auctor eget nostra cursus mauris a, lectus aliquam nec erat imperdiet, dolor senectus dolor gravida egestas. \nRutrum euismod molestie netus curae libero ultrices mauris condimentum et facilisis fringilla aenean leo molestie, donec vel posuere ultrices pharetra ad dictumst lobortis tristique fermentum dapibus ornare. \nInceptos consectetur platea odio duis praesent maecenas risus, eu curabitur lacinia suscipit ipsum eget scelerisque consectetur, mi at netus elementum sollicitudin curae. \nPotenti pharetra aenean dictum venenatis ut tempor, hac ligula integer suspendisse massa dictumst, dapibus accumsan justo faucibus convallis. \nNeque aenean nunc ullamcorper augue accumsan pellentesque, himenaeos morbi sed nibh ultrices luctus, duis quis torquent turpis ut. \n</p>\n<p>\nLorem et neque suscipit aptent dictumst libero cursus leo sapien placerat, curabitur morbi tellus dolor ante aliquet nostra tempus placerat. \nCondimentum dui vestibulum curabitur maecenas curabitur nibh placerat feugiat, lobortis tempus vulputate non aliquet potenti rutrum iaculis venenatis, cursus senectus turpis adipiscing hac aliquet vehicula. \nMi nisi ut fermentum bibendum quis sit eros netus euismod arcu habitant egestas luctus, varius leo congue class nisl velit cursus litora neque orci accumsan ipsum. \nVenenatis consectetur maecenas nisi est odio diam pretium leo, bibendum primis et cursus ut aliquam rhoncus nec, nisl aliquam aliquet tempus vitae egestas vitae. \n</p>', 0, 1, 1),
(2, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 2', 'post-2', '<img alt=\"\" src=\"/filemanager/userfiles/user2/goomba.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum pulvinar semper sem porta habitant phasellus consectetur, a integer primis lacinia etiam sagittis purus lacus purus, enim vel amet magna arcu a netus. \nPellentesque vel conubia nec amet tincidunt sapien curabitur massa, nullam class malesuada vitae sed dolor pellentesque posuere primis, eros fringilla netus lacus in odio aliquam. \n</p>', '<p>Lorem ipsum convallis ac curae non elit ultrices placerat netus metus feugiat, non conubia fusce porttitor sociosqu diam commodo metus in himenaeos, vitae aptent consequat luctus purus eleifend enim sollicitudin eleifend porta. Malesuada ac class conubia condimentum mauris facilisis conubia quis scelerisque lacinia, tempus nullam felis fusce ac potenti netus ornare semper. Molestie iaculis fermentum ornare curabitur tincidunt imperdiet scelerisque, imperdiet euismod scelerisque torquent curae rhoncus, sollicitudin tortor placerat aptent hac nec. Posuere suscipit sed tortor neque urna hendrerit vehicula duis litora tristique congue nec auctor felis libero, ornare habitasse nec elit felis inceptos tellus inceptos cubilia quis mattis faucibus sem non.</p>\n\n<p>Odio fringilla class aliquam metus ipsum lorem luctus pharetra dictum, vehicula tempus in venenatis gravida ut gravida proin orci, quis sed platea mi quisque hendrerit semper hendrerit. Facilisis ante sapien faucibus ligula commodo vestibulum rutrum pretium, varius sem aliquet himenaeos dolor cursus nunc habitasse, aliquam ut curabitur ipsum luctus ut rutrum. Odio condimentum donec suscipit molestie est etiam sit rutrum dui nostra, sem aliquet conubia nullam sollicitudin rhoncus venenatis vivamus rhoncus netus, risus tortor non mauris turpis eget integer nibh dolor. Commodo venenatis ut molestie semper adipiscing amet cras, class donec sapien malesuada auctor sapien arcu inceptos, aenean consequat metus litora mattis vivamus.</p>\n\n<pre>\n<code class=\"language-php\">protected function getUserByRecaller($recaller)\n{\n	if ($this-&gt;validRecaller($recaller) &amp;&amp; ! $this-&gt;tokenRetrievalAttempted)\n	{\n		$this-&gt;tokenRetrievalAttempted = true;\n\n		list($id, $token) = explode(\"|\", $recaller, 2);\n\n		$this-&gt;viaRemember = ! is_null($user = $this-&gt;provider-&gt;retrieveByToken($id, $token));\n\n		return $user;\n	}\n}</code></pre>\n\n<p>Feugiat arcu adipiscing mauris primis ante ullamcorper ad nisi, lobortis arcu per orci malesuada blandit metus tortor, urna turpis consectetur porttitor egestas sed eleifend. Eget tincidunt pharetra varius tincidunt morbi malesuada elementum mi torquent mollis, eu lobortis curae purus amet vivamus amet nulla torquent, nibh eu diam aliquam pretium donec aliquam tempus lacus. Tempus feugiat lectus cras non velit mollis sit et integer, egestas habitant auctor integer sem at nam massa himenaeos, netus vel dapibus nibh malesuada leo fusce tortor. Sociosqu semper facilisis semper class tempus faucibus tristique duis eros, cubilia quisque habitasse aliquam fringilla orci non vel, laoreet dolor enim justo facilisis neque accumsan in.</p>\n\n<p>Ad venenatis hac per dictumst nulla ligula donec, mollis massa porttitor ullamcorper risus eu platea, fringilla habitasse suscipit pellentesque donec est. Habitant vehicula tempor ultrices placerat sociosqu ultrices consectetur ullamcorper tincidunt quisque tellus, ante nostra euismod nec suspendisse sem curabitur elit malesuada lacus. Viverra sagittis sit ornare orci augue nullam adipiscing pulvinar libero aliquam vestibulum platea cursus pellentesque leo dui lectus, curabitur euismod ad erat curae non elit ultrices placerat netus metus feugiat non conubia fusce porttitor. Sociosqu diam commodo metus in himenaeos vitae aptent consequat luctus purus eleifend enim sollicitudin eleifend, porta malesuada ac class conubia condimentum mauris facilisis conubia quis scelerisque lacinia.</p>\n\n<p>Tempus nullam felis fusce ac potenti netus ornare semper molestie iaculis, fermentum ornare curabitur tincidunt imperdiet scelerisque imperdiet euismod. Scelerisque torquent curae rhoncus sollicitudin tortor placerat aptent hac, nec posuere suscipit sed tortor neque urna hendrerit, vehicula duis litora tristique congue nec auctor. Felis libero ornare habitasse nec elit felis, inceptos tellus inceptos cubilia quis mattis, faucibus sem non odio fringilla. Class aliquam metus ipsum lorem luctus pharetra dictum vehicula, tempus in venenatis gravida ut gravida proin orci, quis sed platea mi quisque hendrerit semper.</p>\n', 0, 1, 2),
(3, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 3', 'post-3', '<img alt=\"\" src=\"/filemanager/userfiles/user2/rouge-shell.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum tristique quam volutpat posuere hendrerit laoreet sapien, lorem vestibulum viverra turpis fermentum taciti neque viverra pellentesque, quisque aenean morbi magna rutrum arcu habitant. \nPlacerat sit aliquam etiam hac massa convallis, nam aptent viverra porta adipiscing ligula himenaeos, viverra lorem quam arcu tortor. \nFacilisis non semper luctus, vestibulum cras. \n</p>', '<p>\nLorem ipsum neque elementum vehicula lacinia porta arcu aenean, nec bibendum duis sociosqu dapibus tortor etiam, dolor vel et faucibus laoreet potenti aliquam. \nMauris tincidunt mollis pretium lorem potenti, amet sagittis habitasse donec a quisque, etiam aptent tortor hendrerit. \nUllamcorper sapien amet aliquam convallis posuere urna vehicula, pharetra a ut lacus amet nullam convallis sapien, blandit turpis sem ad neque egestas. \nSemper suscipit vitae molestie aptent pulvinar quisque a suscipit id lacus, etiam ullamcorper ultrices fusce cubilia nibh justo proin nunc auctor lorem, feugiat leo mauris dapibus viverra curabitur ante tincidunt etiam. \n</p>\n<p>\nMi phasellus donec malesuada hac pharetra faucibus leo eu, molestie sagittis litora feugiat lorem ligula dictum morbi congue, proin blandit porta habitant class ullamcorper leo. \nSuspendisse elit gravida dui tortor urna accumsan quam vivamus, ut mauris torquent risus posuere primis aenean, nibh congue eget dapibus senectus laoreet placerat. \nImperdiet habitant dapibus vivamus elementum duis aliquam dui vel porta mollis, dolor malesuada eros taciti rhoncus lacus curae velit dictum. \nUltrices himenaeos neque ac ultricies ut purus quis, sollicitudin magna feugiat viverra magna donec, euismod inceptos leo etiam sed aenean. \n</p>\n<p>\nHendrerit maecenas odio nullam nec blandit neque feugiat hac, interdum placerat vel et ligula maecenas egestas mollis sollicitudin, amet dui enim curabitur nibh leo fringilla. \nJusto aliquet ipsum pharetra dui vitae fames proin diam, est rutrum praesent purus rutrum at suspendisse, dictumst himenaeos ultricies fusce per cras lacus. \nPharetra quisque lobortis curabitur pulvinar etiam porttitor nam, bibendum habitasse ante diam molestie dictumst nisi dictumst, interdum augue nullam tellus in suscipit. \nAliquam et nam donec tincidunt porta quis nibh id in, non porttitor fames neque pharetra odio maecenas tellus placerat, suscipit magna eros nibh metus dictum varius vivamus. \n</p>\n<p>\nMagna nam maecenas platea ad maecenas fringilla blandit aptent nostra amet, diam nibh nisi pulvinar a senectus vel potenti ultricies himenaeos curae, habitant lacus augue convallis porttitor eros sociosqu tempus quisque. \nFacilisis lectus lacus ut ad aliquam enim tempor cursus, fusce malesuada placerat himenaeos bibendum euismod aliquet, augue consequat ante fringilla convallis nostra sed egestas, potenti volutpat ac elit purus nec. \nTellus commodo pharetra fusce phasellus congue urna mi dui, quisque senectus orci blandit lacinia cursus imperdiet turpis tempus, eros pretium lectus pretium ut pulvinar integer. \nTellus rhoncus semper dictum risus inceptos venenatis aliquam nulla eleifend, sodales enim orci tincidunt ut mauris curae class, in mollis per facilisis scelerisque aenean erat sollicitudin. \n</p>\n<p>\nTempor eros risus primis tincidunt rhoncus tempus ultrices augue pretium varius at fusce volutpat, pretium conubia platea porttitor tellus in viverra egestas purus lacinia diam felis, class morbi congue et phasellus tellus eleifend urna hac vulputate praesent ante. \nPlatea nostra fames curae nisl ultricies augue vestibulum elementum litora integer, arcu conubia primis aenean ante etiam inceptos nibh dolor enim laoreet, duis hendrerit rutrum suscipit fusce risus sagittis tortor fusce. \nTortor lobortis sit mattis consectetur potenti nam congue, condimentum sem donec varius augue nunc in, erat fringilla et fusce praesent nec. \n</p>\n<p>\nDictumst lacus faucibus sapien lectus imperdiet pulvinar cursus nisi habitasse porttitor urna, integer conubia eros quis pretium ornare blandit molestie odio. \n</p>', 0, 1, 2),
(4, '2018-12-10 13:38:33', '2018-12-10 13:38:33', 'Post 4', 'post-4', '<img alt=\"\" src=\"/filemanager/userfiles/user2/rouge-shyguy.png\" style=\"float:left; height:128px; width:128px\" /><p>\nLorem ipsum iaculis pharetra aliquam ipsum, ante ultricies eu nostra sed enim, donec commodo aliquet litora. \nMorbi porttitor magna tellus quis vitae egestas fames tristique aptent, curabitur nec urna primis consectetur facilisis aliquet hac non, interdum duis felis conubia etiam pulvinar consequat tellus. \nVivamus cubilia pharetra ligula vulputate, consectetur hac. \n</p>', '<p>\nLorem ipsum taciti consectetur tempor primis id ultrices taciti, etiam laoreet vivamus lobortis rutrum odio malesuada enim cras, suspendisse eu dui pretium primis enim aenean. \nMolestie pretium platea curabitur adipiscing dui suscipit curae, vulputate quis convallis aliquam nisl magna non laoreet, venenatis lobortis tellus mollis sociosqu malesuada. \nAptent class fermentum suspendisse class porttitor vehicula lacus donec morbi sociosqu, massa nisi erat duis hac lobortis tempus inceptos quis erat, accumsan fames sem non purus ut tempus sem nec. \nAt lectus imperdiet dui netus sagittis interdum adipiscing, lorem phasellus consequat donec sociosqu eget ultrices, ultricies lectus et nisl pulvinar scelerisque. \n</p>\n<p>\nRutrum nullam tempor aenean amet morbi feugiat interdum placerat feugiat ante dui, cubilia et duis erat egestas ultricies iaculis neque aliquam curabitur, lacus quam metus habitant dictumst lobortis scelerisque tempus molestie felis. \nAenean cras justo aliquam tellus dui semper nulla quis non vivamus euismod, curae consectetur imperdiet est vitae consectetur per dapibus metus fermentum, et vestibulum enim maecenas donec odio nostra tellus hendrerit suspendisse. \nId aliquet maecenas scelerisque integer placerat lorem etiam nec, id venenatis aptent vestibulum sociosqu vivamus vehicula, massa tempor quis mattis conubia malesuada sociosqu. \nSemper tortor tempus lacinia pellentesque mauris per consequat purus urna sagittis morbi suscipit blandit venenatis, hendrerit porttitor lacinia dui tellus aenean blandit curabitur metus dapibus vivamus purus elementum. \n</p>\n<p>\nVarius netus orci facilisis vulputate lobortis leo sollicitudin tincidunt eleifend velit, nullam augue pharetra magna lectus nisl sodales curabitur sollicitudin habitant, pellentesque rutrum eleifend fringilla vel libero lacus maecenas ipsum. \nAptent conubia magna sem magna diam cras interdum, etiam aenean amet adipiscing faucibus rhoncus, vel ullamcorper curabitur tristique sodales ut. \nMollis erat commodo adipiscing platea in donec himenaeos ut urna, tempor amet urna vulputate a enim risus et elementum curabitur, volutpat fames per sodales duis fames ipsum blandit. \nPer ad eu pulvinar donec at posuere ullamcorper, erat velit neque elit lobortis ultrices sit senectus, vivamus libero elit pulvinar porta mattis. \n</p>\n<p>\nFeugiat magna lobortis phasellus suscipit bibendum lobortis class, nec mattis elementum erat mauris fringilla ultrices, nisl fusce elementum imperdiet risus proin. \nDolor ligula vel tristique ipsum fames per quis, suspendisse aenean nam vehicula rutrum vehicula maecenas porta, fermentum ultrices eros cubilia curae praesent. \nSenectus posuere elit bibendum semper tempor ipsum integer laoreet lacus, turpis sapien placerat donec libero adipiscing nam sed nisi, habitasse curabitur per odio ad facilisis vulputate fermentum. \nTempus inceptos in gravida pretium pharetra ac rutrum eros arcu habitant, faucibus congue taciti donec venenatis etiam netus aliquam posuere himenaeos, vestibulum aliquam ligula non odio mauris non vitae ante. \n</p>\n<p>\nQuam molestie neque urna et dapibus phasellus, odio cras curae fringilla dolor congue, auctor dictumst proin pellentesque augue. \nLibero quisque ornare sem curae hendrerit libero pellentesque lectus, libero tincidunt ac adipiscing convallis dapibus sodales, sit gravida pretium magna dui quam primis. \nUt pellentesque luctus suscipit rutrum erat eleifend fames euismod, bibendum massa aliquet curae integer fringilla nunc ullamcorper, suspendisse tellus sagittis euismod vitae cras dictum. \nSit torquent aenean netus lorem leo libero, gravida sollicitudin risus fusce imperdiet, mi faucibus aliquam ut metus. \nFusce sapien quisque iaculis, phasellus. \n</p>', 0, 1, 2);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
CREATE TABLE IF NOT EXISTS `post_tag` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_tag_post_id_foreign` (`post_id`),
  KEY `post_tag_tag_id_foreign` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `post_tag`
--

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 2, 2),
(5, 2, 3),
(6, 3, 1),
(7, 3, 2),
(8, 3, 4);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `roles`
--

INSERT INTO `roles` (`id`, `title`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin', '2018-12-10 13:38:31', '2018-12-10 13:38:31'),
(2, 'Redactor', 'redac', '2018-12-10 13:38:31', '2018-12-10 13:38:31'),
(3, 'User', 'user', '2018-12-10 13:38:31', '2018-12-10 13:38:31');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tag` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_tag_unique` (`tag`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `tags`
--

INSERT INTO `tags` (`id`, `created_at`, `updated_at`, `tag`) VALUES
(1, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag1'),
(2, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag2'),
(3, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag3'),
(4, '2018-12-10 13:38:32', '2018-12-10 13:38:32', 'Tag4');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `valid` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `confirmation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role_id`, `seen`, `valid`, `confirmed`, `confirmation_code`, `created_at`, `updated_at`, `remember_token`) VALUES
(1, 'GreatAdmin', 'admin@la.fr', '$2y$10$CL5XUr3YoVwrqedqg39BOea68mAbm63MWf4OQnmjhgPDlC3GHXhhK', 1, 1, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(2, 'GreatRedactor', 'redac@la.fr', '$2y$10$yvOMN/KpOvT9ITCvKvjd/eiF5wdw4kgHLXI8BKKo4.5fUJLtJjZaW', 2, 1, 1, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(3, 'Walker', 'walker@la.fr', '$2y$10$3JoNJsjJxkkOvmiIFION2OsS.QyXMOsXV0R0lGOGb8WwE2M3uy3Ve', 3, 0, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL),
(4, 'Slacker', 'slacker@la.fr', '$2y$10$hAnb3Vs8Bxjj4m4JpFNRCuGuOoGVSvPTZvK0YTgcSiIVHUcELq0jC', 3, 0, 0, 1, NULL, '2018-12-10 13:38:32', '2018-12-10 13:38:32', NULL);

--
-- Apribojimai eksportuotom lentelėm
--

--
-- Apribojimai lentelei `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Apribojimai lentelei `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Apribojimai lentelei `post_tag`
--
ALTER TABLE `post_tag`
  ADD CONSTRAINT `post_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `post_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Apribojimai lentelei `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
--
-- Database: `laravel55`
--
DROP DATABASE IF EXISTS `laravel55`;
CREATE DATABASE IF NOT EXISTS `laravel55` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `laravel55`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_08_20_231444_create_products_table', 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(1, 'produktas 1', 100, '2018-12-10 13:36:17', '2018-12-10 13:36:17');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Database: `mvc_exm`
--
DROP DATABASE IF EXISTS `mvc_exm`;
CREATE DATABASE IF NOT EXISTS `mvc_exm` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `mvc_exm`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `name`) VALUES
(24, 'Abby Ward'),
(21, 'Aleksandra Devine'),
(43, 'Aston Simmonds'),
(47, 'Aston Simmonds'),
(15, 'Beth Skywalker'),
(26, 'Bridget Wooten'),
(10, 'Coby Kelleigh'),
(20, 'Darrah Shadow'),
(9, 'Drake Adelaide'),
(12, 'Elizabeth Stewart'),
(19, 'Gareth Solderini'),
(42, 'Gregor Bryant'),
(46, 'Gregor Bryant'),
(13, 'Hannah Strickland'),
(52, 'Harvey Frame'),
(7, 'Imogene Thad'),
(53, 'Ismaeel Carty'),
(41, 'Issac Calderon'),
(45, 'Issac Calderon'),
(2, 'Jane Doe'),
(5, 'Jaslyn Keely'),
(40, 'Jax Howe'),
(39, 'Joey Whyte'),
(1, 'John Doe'),
(17, 'Joseph Stewart'),
(34, 'Julia Greaves'),
(31, 'Junior Douglas'),
(32, 'Kaiden Bentley'),
(16, 'Kenneth Sanders'),
(30, 'Keziah Knapp'),
(28, 'Kirstie Thomas'),
(33, 'Lawrence Murphy'),
(14, 'Leah Shan'),
(51, 'Marcus Best'),
(29, 'Maya Paine'),
(23, 'Myla Bostock'),
(50, 'Nathaniel Khan'),
(4, 'Peers Sera'),
(6, 'Richard Breann'),
(54, 'Rowan Avalos'),
(3, 'Rusty Terry'),
(37, 'Sacha Gross'),
(27, 'Sally Castillo'),
(11, 'Sarah Sanders'),
(18, 'Seth Sonnel'),
(38, 'Shannon Peterson'),
(25, 'Shayan Clements'),
(49, 'Shoaib Vickers'),
(35, 'Sulaiman Gilmour'),
(44, 'Taran Morin'),
(48, 'Taran Morin'),
(22, 'Thelma Kim'),
(8, 'Tillie Sharalyn'),
(36, 'Virgil Collier');
--
-- Database: `newdb`
--
DROP DATABASE IF EXISTS `newdb`;
CREATE DATABASE IF NOT EXISTS `newdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `newdb`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'new', '$2y$12$prS16k300EQp4RNwouPSgOrThtl4Yv4mK17xXV5L0Ne9IE8WSFBha');
--
-- Database: `pdo`
--
DROP DATABASE IF EXISTS `pdo`;
CREATE DATABASE IF NOT EXISTS `pdo` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `pdo`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(3) DEFAULT NULL,
  `location` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `age`, `location`, `date`) VALUES
(2, 'pdo', 'pdo', 'test@npp.com', 30, 'LT', '2019-01-16 18:01:31');
--
-- Database: `phplogin`
--
DROP DATABASE IF EXISTS `phplogin`;
CREATE DATABASE IF NOT EXISTS `phplogin` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `phplogin`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(128) NOT NULL,
  `user_status` varchar(1) NOT NULL DEFAULT 'P',
  `user_data` text,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`),
  KEY `user_name` (`user_name`),
  KEY `user_status` (`user_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Sukurta duomenų kopija lentelei `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_password`, `user_status`, `user_data`) VALUES
(0, 'admin', 'admin@test.com', 'e10adc3949ba59abbe56e057f20f883e', 'A', NULL);
--
-- Database: `phpmyadmin`
--
DROP DATABASE IF EXISTS `phpmyadmin`;
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__bookmark`
--

DROP TABLE IF EXISTS `pma__bookmark`;
CREATE TABLE IF NOT EXISTS `pma__bookmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__central_columns`
--

DROP TABLE IF EXISTS `pma__central_columns`;
CREATE TABLE IF NOT EXISTS `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin,
  PRIMARY KEY (`db_name`,`col_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__column_info`
--

DROP TABLE IF EXISTS `pma__column_info`;
CREATE TABLE IF NOT EXISTS `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__designer_settings`
--

DROP TABLE IF EXISTS `pma__designer_settings`;
CREATE TABLE IF NOT EXISTS `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__export_templates`
--

DROP TABLE IF EXISTS `pma__export_templates`;
CREATE TABLE IF NOT EXISTS `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__favorite`
--

DROP TABLE IF EXISTS `pma__favorite`;
CREATE TABLE IF NOT EXISTS `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__history`
--

DROP TABLE IF EXISTS `pma__history`;
CREATE TABLE IF NOT EXISTS `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`,`db`,`table`,`timevalue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__navigationhiding`
--

DROP TABLE IF EXISTS `pma__navigationhiding`;
CREATE TABLE IF NOT EXISTS `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__pdf_pages`
--

DROP TABLE IF EXISTS `pma__pdf_pages`;
CREATE TABLE IF NOT EXISTS `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`page_nr`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__recent`
--

DROP TABLE IF EXISTS `pma__recent`;
CREATE TABLE IF NOT EXISTS `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Sukurta duomenų kopija lentelei `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"phplogin\",\"table\":\"users\"},{\"db\":\"mvc_exm\",\"table\":\"users\"},{\"db\":\"newdb\",\"table\":\"users\"},{\"db\":\"cruidlogin\",\"table\":\"products\"},{\"db\":\"cruidlogin\",\"table\":\"login\"},{\"db\":\"cruid\",\"table\":\"users\"},{\"db\":\"php_clicks\",\"table\":\"student\"},{\"db\":\"pdo\",\"table\":\"users\"},{\"db\":\"php_clicks\",\"table\":\"users\"},{\"db\":\"phpclicks\",\"table\":\"users\"}]');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__relation`
--

DROP TABLE IF EXISTS `pma__relation`;
CREATE TABLE IF NOT EXISTS `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__savedsearches`
--

DROP TABLE IF EXISTS `pma__savedsearches`;
CREATE TABLE IF NOT EXISTS `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__table_coords`
--

DROP TABLE IF EXISTS `pma__table_coords`;
CREATE TABLE IF NOT EXISTS `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__table_info`
--

DROP TABLE IF EXISTS `pma__table_info`;
CREATE TABLE IF NOT EXISTS `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__table_uiprefs`
--

DROP TABLE IF EXISTS `pma__table_uiprefs`;
CREATE TABLE IF NOT EXISTS `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`username`,`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__tracking`
--

DROP TABLE IF EXISTS `pma__tracking`;
CREATE TABLE IF NOT EXISTS `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`db_name`,`table_name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__userconfig`
--

DROP TABLE IF EXISTS `pma__userconfig`;
CREATE TABLE IF NOT EXISTS `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Sukurta duomenų kopija lentelei `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-01-17 17:56:55', '{\"lang\":\"lt\",\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__usergroups`
--

DROP TABLE IF EXISTS `pma__usergroups`;
CREATE TABLE IF NOT EXISTS `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N',
  PRIMARY KEY (`usergroup`,`tab`,`allowed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `pma__users`
--

DROP TABLE IF EXISTS `pma__users`;
CREATE TABLE IF NOT EXISTS `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`usergroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';
--
-- Database: `php_clicks`
--
DROP DATABASE IF EXISTS `php_clicks`;
CREATE DATABASE IF NOT EXISTS `php_clicks` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `php_clicks`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `student`
--

INSERT INTO `student` (`student_id`, `first_name`, `last_name`, `email`, `user_name`, `password`, `date_added`) VALUES
(8, 'test', 'test', 'test@npp.com', 'testtest', '098f6bcd4621d373cade4e832627b4f6', '2019-01-16 17:58:11');
--
-- Database: `symfony`
--
DROP DATABASE IF EXISTS `symfony`;
CREATE DATABASE IF NOT EXISTS `symfony` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `symfony`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `body_type`
--

DROP TABLE IF EXISTS `body_type`;
CREATE TABLE IF NOT EXISTS `body_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D95AEB4B5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `body_type`
--

INSERT INTO `body_type` (`id`, `name`) VALUES
(2, 'Hečbekas'),
(8, 'Kabrioletas / Roadster'),
(11, 'Keleivinis mikroautobusas'),
(15, 'Kita'),
(12, 'Kombi mikroautobusas'),
(7, 'Komercinis'),
(13, 'Krovininis mikroautobusas'),
(6, 'Kupė (Coupe)'),
(9, 'Limuzinas'),
(10, 'Pikapas'),
(14, 'Savadarbis auto'),
(1, 'Sedanas'),
(3, 'Universalas'),
(4, 'Vienatūris'),
(5, 'Visureigis');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `brand`
--

DROP TABLE IF EXISTS `brand`;
CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_1C52F9585E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `brand`
--

INSERT INTO `brand` (`id`, `name`) VALUES
(1, 'Abarth'),
(2, 'AC'),
(3, 'Acura'),
(4, 'Aixam'),
(5, 'Alfa Romeo'),
(6, 'Alpina'),
(7, 'AMC'),
(8, 'ARO'),
(9, 'Asia'),
(10, 'Aston Martin'),
(11, 'Audi'),
(12, 'Austin Rover'),
(13, 'Autobianchi'),
(14, 'Bentley'),
(15, 'BMW'),
(16, 'Briliance'),
(17, 'Bugatti'),
(18, 'Buick'),
(19, 'Cadillac'),
(20, 'Chevrolet'),
(21, 'Chrysler'),
(22, 'Citroen'),
(23, 'Cobra'),
(24, 'Dacia'),
(25, 'Daewoo'),
(26, 'DAF'),
(27, 'Daihatsu'),
(28, 'Datsun'),
(29, 'Delorean'),
(30, 'Desoto'),
(31, 'Dodge'),
(32, 'DR Motor'),
(33, 'Eagle'),
(34, 'Ferrari'),
(35, 'Fiat'),
(36, 'Fisker'),
(37, 'Ford'),
(38, 'GAZ'),
(39, 'Geo'),
(40, 'GMC'),
(41, 'Gonow'),
(42, 'Great Wall'),
(43, 'Honda'),
(44, 'Hummer'),
(45, 'Hyundai'),
(46, 'Infiniti'),
(47, 'International'),
(48, 'Isuzu'),
(49, 'Iveco'),
(50, 'Jaguar'),
(51, 'Jeep'),
(52, 'Kia'),
(53, 'Koenigsegg'),
(54, 'Lada'),
(55, 'Lamborghini'),
(56, 'Lancia'),
(57, 'Land Rover'),
(58, 'Landwind'),
(59, 'Lexus'),
(60, 'Ligier'),
(61, 'Lincoln'),
(62, 'Lotus'),
(63, 'LuAZ'),
(64, 'Mahindra'),
(65, 'Maserati'),
(66, 'Maybach'),
(67, 'Mazda'),
(68, 'Mclaren'),
(69, 'Mercedes Benz'),
(70, 'Mercury'),
(71, 'MG'),
(72, 'Microcar'),
(73, 'Mini'),
(74, 'Mitsubishi'),
(75, 'Morgan'),
(76, 'Moskvich'),
(77, 'Nissan'),
(78, 'Norster'),
(79, 'Nysa'),
(80, 'Oldsmobile'),
(81, 'Opel'),
(82, 'Packard'),
(83, 'Peugeot'),
(84, 'Plymouth'),
(85, 'Pontiac'),
(86, 'Porsche'),
(87, 'Proton'),
(88, 'Renault'),
(89, 'Rolls Royce'),
(90, 'Roosevelt'),
(91, 'Rover'),
(92, 'Saab'),
(93, 'Santana'),
(94, 'Saturn'),
(95, 'Scion'),
(96, 'Seat'),
(97, 'Secma'),
(98, 'Shuanghuan'),
(99, 'Skoda'),
(100, 'Smart'),
(101, 'Spartan'),
(102, 'Spyker'),
(103, 'SsangYong'),
(104, 'Studebaker'),
(105, 'Subaru'),
(106, 'Suzuki'),
(107, 'Talbot'),
(108, 'Tartan'),
(109, 'Tata'),
(110, 'Tatra'),
(111, 'Tazzari'),
(112, 'Tesla'),
(113, 'Think'),
(114, 'Toyota'),
(115, 'Trabant'),
(116, 'Triumph'),
(117, 'UAZ'),
(118, 'Vauxhall'),
(119, 'Venturi'),
(120, 'Volkswagen'),
(121, 'Volvo'),
(122, 'Wanderer'),
(123, 'Wartburg'),
(124, 'ZAZ');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2D5B02345373C966` (`country`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `city`
--

INSERT INTO `city` (`id`, `country`, `name`) VALUES
(1, 1, '-kita-'),
(2, 1, 'Vilnius'),
(3, 1, 'Kaunas'),
(4, 1, 'Klaipėda'),
(5, 1, 'Šiauliai'),
(6, 1, 'Panevėžys'),
(7, 1, 'Akmenė'),
(8, 1, 'Alytus'),
(9, 1, 'Anykščiai'),
(10, 1, 'Ariogala'),
(11, 1, 'Birštonas'),
(12, 1, 'Biržai'),
(13, 1, 'Druskininkai'),
(14, 1, 'Elektrėnai'),
(15, 1, 'Gargždai'),
(16, 1, 'Ignalina'),
(17, 1, 'Jonava'),
(18, 1, 'Joniškis'),
(19, 1, 'Juodkrantė'),
(20, 1, 'Jurbarkas'),
(21, 1, 'Kaišiadorys'),
(22, 1, 'Kalvarija'),
(23, 1, 'Karklė'),
(24, 1, 'Kazlų Rūda'),
(25, 1, 'Kėdainiai'),
(26, 1, 'Kelmė'),
(27, 1, 'Kretinga'),
(28, 1, 'Kupiškis'),
(29, 1, 'Kuršėnai'),
(30, 1, 'Lazdijai'),
(31, 1, 'Marijampolė'),
(32, 1, 'Mažeikiai'),
(33, 1, 'Melnragė'),
(34, 1, 'Molėtai'),
(35, 1, 'Naujoji Akmenė'),
(36, 1, 'Nemenčinė'),
(37, 1, 'Neringa'),
(38, 1, 'Nida'),
(39, 1, 'Pagėgiai'),
(40, 1, 'Pakruojis'),
(41, 1, 'Palanga'),
(42, 1, 'Pasvalys'),
(43, 1, 'Plungė'),
(44, 1, 'Prienai'),
(45, 1, 'Radviliškis'),
(46, 1, 'Raseiniai'),
(47, 1, 'Rietavas'),
(48, 1, 'Rokiškis'),
(49, 1, 'Šakiai'),
(50, 1, 'Šalčininkai'),
(51, 1, 'Šilalė'),
(52, 1, 'Šilutė'),
(53, 1, 'Širvintos'),
(54, 1, 'Skaudvilė'),
(55, 1, 'Skuodas'),
(56, 1, 'Švenčionys'),
(57, 1, 'Šventoji'),
(58, 1, 'Tauragė'),
(59, 1, 'Telšiai'),
(60, 1, 'Trakai'),
(61, 1, 'Ukmergė'),
(62, 1, 'Utena'),
(63, 1, 'Varėna'),
(64, 1, 'Vievis'),
(65, 1, 'Vilkaviškis'),
(66, 1, 'Visaginas'),
(67, 1, 'Zarasai'),
(68, 2, 'Ryga'),
(69, 2, 'Jūrmala'),
(70, 2, 'Daugavpils'),
(71, 2, 'Liepāja'),
(72, 2, 'Jelgava'),
(73, 2, 'Rēzekne'),
(74, 2, 'Ventspils'),
(75, 2, 'Ādaži'),
(76, 2, 'Ainaži'),
(77, 2, 'Aizkraukle'),
(78, 2, 'Aizpute'),
(79, 2, 'Aknīste'),
(80, 2, 'Aloja'),
(81, 2, 'Alūksne'),
(82, 2, 'Ape'),
(83, 2, 'Auce'),
(84, 2, 'Baldone'),
(85, 2, 'Baloži'),
(86, 2, 'Balvi'),
(87, 2, 'Bauska'),
(88, 2, 'Brocēni'),
(89, 2, 'Cēsis'),
(90, 2, 'Cesvaine'),
(91, 2, 'Dagda'),
(92, 2, 'Dobele'),
(93, 2, 'Durbe'),
(94, 2, 'Grobiņa'),
(95, 2, 'Gulbene'),
(96, 2, 'Iecava'),
(97, 2, 'Ikšķile'),
(98, 2, 'Ilūkste'),
(99, 2, 'Jaunjelgava'),
(100, 2, 'Jaunmārupe'),
(101, 2, 'Jaunolaine'),
(102, 2, 'Jēkabpils'),
(103, 2, 'Kalnciems'),
(104, 2, 'Kandava'),
(105, 2, 'Kārsava'),
(106, 2, 'Ķegums'),
(107, 2, 'Ķemeri'),
(108, 2, 'Krāslava'),
(109, 2, 'Kuldīga'),
(110, 2, 'Lielvārde'),
(111, 2, 'Līgatne'),
(112, 2, 'Limbaži'),
(113, 2, 'Līvāni'),
(114, 2, 'Lubāna'),
(115, 2, 'Ludza'),
(116, 2, 'Madona'),
(117, 2, 'Mazsalaca'),
(118, 2, 'Ogre'),
(119, 2, 'Olaine'),
(120, 2, 'Pāvilosta'),
(121, 2, 'Piltene'),
(122, 2, 'Pļaviņas'),
(123, 2, 'Preiļi'),
(124, 2, 'Rucava'),
(125, 2, 'Rūjiena'),
(126, 2, 'Sabile'),
(127, 2, 'Salacgrīva'),
(128, 2, 'Salaspils'),
(129, 2, 'Saldus'),
(130, 2, 'Saulkrasti'),
(131, 2, 'Seda'),
(132, 2, 'Sēlpils'),
(133, 2, 'Sigulda'),
(134, 2, 'Skrunda'),
(135, 2, 'Smiltene'),
(136, 2, 'Staicele'),
(137, 2, 'Stende'),
(138, 2, 'Strenči'),
(139, 2, 'Subate'),
(140, 2, 'Talsi'),
(141, 2, 'Tukums'),
(142, 2, 'Valdemārpils'),
(143, 2, 'Valka'),
(144, 2, 'Valmiera'),
(145, 2, 'Vangaži'),
(146, 2, 'Varakļāni'),
(147, 2, 'Viesīte'),
(148, 2, 'Viļaka'),
(149, 2, 'Viļāni'),
(150, 2, 'Zilupe'),
(151, 3, 'Harjumaa'),
(152, 3, 'Hiiumaa'),
(153, 3, 'Ida-Virumaa'),
(154, 3, 'Järvamaa'),
(155, 3, 'Jõgevamaa'),
(156, 3, 'Kita'),
(157, 3, 'Lääne-Virumaa'),
(158, 3, 'Läänemaa'),
(159, 3, 'Maardu'),
(160, 3, 'Pärnumaa'),
(161, 3, 'Põlvamaa'),
(162, 3, 'Raplamaa'),
(163, 3, 'Saaremaa'),
(164, 3, 'Tallinn'),
(165, 3, 'Tartumaa'),
(166, 3, 'Valgamaa'),
(167, 3, 'Viljandimaa'),
(168, 3, 'Võrumaa'),
(169, 13, 'Lucca');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `climate_control`
--

DROP TABLE IF EXISTS `climate_control`;
CREATE TABLE IF NOT EXISTS `climate_control` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_999E35875E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `climate_control`
--

INSERT INTO `climate_control` (`id`, `name`) VALUES
(3, 'Klimato kontrolė'),
(1, 'Nėra'),
(2, 'Oro kondicionierius');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `color`
--

DROP TABLE IF EXISTS `color`;
CREATE TABLE IF NOT EXISTS `color` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_665648E95E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `color`
--

INSERT INTO `color` (`id`, `name`) VALUES
(3, 'Auksinė'),
(1, 'Balta'),
(2, 'Geltona'),
(4, 'Juoda'),
(16, 'Kita'),
(5, 'Marga'),
(6, 'Mėlyna'),
(8, 'Oranžinė'),
(9, 'Pilka'),
(11, 'Raudona / vyšninė'),
(12, 'Ruda'),
(10, 'Sidabrinė'),
(13, 'Smėlio'),
(14, 'Violetinė'),
(15, 'Žalia / chaki'),
(7, 'Žydra');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE IF NOT EXISTS `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_5373C9665E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(4, 'Airija'),
(5, 'Anglija'),
(6, 'Austrija'),
(7, 'Baltarusija'),
(8, 'Belgija'),
(9, 'Čekija'),
(10, 'Danija'),
(3, 'Estija'),
(11, 'Graikija'),
(12, 'Ispanija'),
(13, 'Italija'),
(14, 'JAV'),
(2, 'Latvija'),
(15, 'Lenkija'),
(1, 'Lietuva'),
(16, 'Liuksemburgas'),
(17, 'Norvegija'),
(18, 'Olandija'),
(19, 'Prancūzija'),
(20, 'Rusija'),
(21, 'Slovakija'),
(24, 'Suomija'),
(22, 'Švedija'),
(23, 'Šveicarija'),
(25, 'Vengrija'),
(26, 'Vokietija');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `defects`
--

DROP TABLE IF EXISTS `defects`;
CREATE TABLE IF NOT EXISTS `defects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_68E845B05E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `defects`
--

INSERT INTO `defects` (`id`, `name`) VALUES
(1, 'Be defektų'),
(2, 'Daužtas'),
(3, 'Degęs'),
(8, 'Kiti stambūs defektai'),
(4, 'Pavarų dėžės defektas'),
(5, 'Pažeistas krušos'),
(6, 'Skendęs'),
(7, 'Variklio defektas');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `fos_user`
--

DROP TABLE IF EXISTS `fos_user`;
CREATE TABLE IF NOT EXISTS `fos_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_957A6479C05FB297` (`confirmation_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `fuel_type`
--

DROP TABLE IF EXISTS `fuel_type`;
CREATE TABLE IF NOT EXISTS `fuel_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9CA10F385E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `fuel_type`
--

INSERT INTO `fuel_type` (`id`, `name`) VALUES
(2, 'Benzinas'),
(3, 'Benzinas / dujos'),
(4, 'Benzinas / elektra'),
(10, 'Benzinas / gamtinės dujos'),
(8, 'Bioetanolis (E85)'),
(9, 'Dujos'),
(1, 'Dyzelinas'),
(7, 'Dyzelinas / dujos'),
(6, 'Dyzelinas / elektra'),
(5, 'Elektra'),
(11, 'Kita');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `model`
--

DROP TABLE IF EXISTS `model`;
CREATE TABLE IF NOT EXISTS `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D79572D91C52F958` (`brand`)
) ENGINE=InnoDB AUTO_INCREMENT=2499 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `model`
--

INSERT INTO `model` (`id`, `brand`, `name`) VALUES
(1, 1, '-kita-'),
(2, 1, 'Punto Evo'),
(3, 2, '-kita-'),
(4, 2, 'Ace'),
(5, 2, 'Aceca'),
(6, 2, 'Cobra'),
(7, 3, '-kita-'),
(8, 3, 'CL'),
(9, 3, 'EL'),
(10, 3, 'ILX'),
(11, 3, 'Integra'),
(12, 3, 'Legend'),
(13, 3, 'MDX'),
(14, 3, 'NSX'),
(15, 3, 'RDX'),
(16, 3, 'RL'),
(17, 3, 'RLX'),
(18, 3, 'RSX'),
(19, 3, 'SLX'),
(20, 3, 'TL'),
(21, 3, 'TLX'),
(22, 3, 'TSX'),
(23, 3, 'Vigor'),
(24, 3, 'ZDX'),
(25, 4, '-kita-'),
(26, 4, '400'),
(27, 4, '500'),
(28, 4, 'A721'),
(29, 4, 'A741'),
(30, 4, 'A751'),
(31, 4, 'City'),
(32, 4, 'Coupe'),
(33, 4, 'Crossline'),
(34, 4, 'Crossover'),
(35, 4, 'GTO'),
(36, 4, 'Roadline'),
(37, 4, 'Ligier'),
(38, 4, 'Scouty'),
(39, 4, 'Scouty R'),
(40, 5, '-kita-'),
(41, 5, '145'),
(42, 5, '146'),
(43, 5, '147'),
(44, 5, '155'),
(45, 5, '156'),
(46, 5, '159'),
(47, 5, '164'),
(48, 5, '166'),
(49, 5, '33'),
(50, 5, '4C'),
(51, 5, '75'),
(52, 5, '8C'),
(53, 5, '90'),
(54, 5, 'Alfasud'),
(55, 5, 'Alfetta'),
(56, 5, 'Arna'),
(57, 5, 'Brera'),
(58, 5, 'Crosswagon'),
(59, 5, 'Crosswagon Q4'),
(60, 5, 'Giulia'),
(61, 5, 'Giulietta'),
(62, 5, 'GT'),
(63, 5, 'GTV'),
(64, 5, 'Junior'),
(65, 5, 'Mito'),
(66, 5, 'RZ/SZ'),
(67, 5, 'Spider'),
(68, 5, 'Sportwagon'),
(69, 5, 'Sprint'),
(70, 5, 'Stelvio'),
(71, 6, '-kita-'),
(72, 6, 'B12'),
(73, 6, 'B3'),
(74, 6, 'B5'),
(75, 6, 'B6'),
(76, 6, 'B7'),
(77, 6, 'B8'),
(78, 6, 'D10'),
(79, 6, 'D3'),
(80, 6, 'Roadster S'),
(81, 7, '-kita-'),
(82, 7, 'Ambassador'),
(83, 7, 'Concord'),
(84, 7, 'Eagle'),
(85, 7, 'Gremlin'),
(86, 7, 'Javelin'),
(87, 7, 'Matador'),
(88, 7, 'Pacer'),
(89, 7, 'Rambler'),
(90, 7, 'Rebel'),
(91, 7, 'Spirit'),
(92, 8, '-kita-'),
(93, 8, '10'),
(94, 8, '10-4'),
(95, 8, '11-4'),
(96, 8, '24'),
(97, 8, '243'),
(98, 8, '244'),
(99, 8, '245'),
(100, 8, '246'),
(101, 8, 'K450'),
(102, 8, 'Dragon'),
(103, 8, 'M 461'),
(104, 8, 'Muscel'),
(105, 8, 'Serija 10'),
(106, 8, 'Serija 240'),
(107, 8, 'Serija 320'),
(108, 8, 'Spartana'),
(109, 9, '-kita-'),
(110, 9, 'Hi Topic'),
(111, 9, 'Retona'),
(112, 9, 'Rocsta'),
(113, 9, 'Towner'),
(114, 10, '-kita-'),
(115, 10, 'AR1'),
(116, 10, 'Bulldog'),
(117, 10, 'Cygnet'),
(118, 10, 'DB'),
(119, 10, 'DB6'),
(120, 10, 'DB7'),
(121, 10, 'DB9'),
(122, 10, 'DBS'),
(123, 10, 'Lagonda'),
(124, 10, 'One-77'),
(125, 10, 'Rapide'),
(126, 10, 'V12 Vanquish'),
(127, 10, 'V12 Vantage'),
(128, 10, 'V8'),
(129, 10, 'Vanquish'),
(130, 10, 'Vantage'),
(131, 10, 'Virage'),
(132, 10, 'Volante'),
(133, 10, 'Zagato'),
(134, 11, '-kita-'),
(135, 11, '100'),
(136, 11, '200'),
(137, 11, '5000'),
(138, 11, '80'),
(139, 11, '90'),
(140, 11, 'A1'),
(141, 11, 'A2'),
(142, 11, 'A3'),
(143, 11, 'A4'),
(144, 11, 'A4 ALLROAD'),
(145, 11, 'A5'),
(146, 11, 'A5 SPORTBACK'),
(147, 11, 'A6'),
(148, 11, 'A6 ALLROAD'),
(149, 11, 'A7 SPORTBACK'),
(150, 11, 'A8'),
(151, 11, 'Allroad'),
(152, 11, 'Cabriolet'),
(153, 11, 'Coupe'),
(154, 11, 'Q2'),
(155, 11, 'Q3'),
(156, 11, 'Q5'),
(157, 11, 'Q7'),
(158, 11, 'Quattro'),
(159, 11, 'R8'),
(160, 11, 'RS Q3'),
(161, 11, 'RS2'),
(162, 11, 'RS3'),
(163, 11, 'RS4'),
(164, 11, 'RS5'),
(165, 11, 'RS6'),
(166, 11, 'RS7'),
(167, 11, 'S1'),
(168, 11, 'S2'),
(169, 11, 'S3'),
(170, 11, 'S4'),
(171, 11, 'S5'),
(172, 11, 'S6'),
(173, 11, 'S7'),
(174, 11, 'S8'),
(175, 11, 'SQ5'),
(176, 11, 'SQ7'),
(177, 11, 'TT'),
(178, 11, 'TT RS'),
(179, 11, 'TTS'),
(180, 11, 'V8'),
(181, 12, '-kita-'),
(182, 12, 'Allegro'),
(183, 12, 'Ambasador'),
(184, 12, 'Healey'),
(185, 12, 'Maxi'),
(186, 12, 'Metro'),
(187, 12, 'Mini'),
(188, 12, 'Montego'),
(189, 13, '-kita-'),
(190, 13, 'Bianchina'),
(191, 14, '-kita-'),
(192, 14, 'Arnage'),
(193, 14, 'Azure'),
(194, 14, 'Bentayga'),
(195, 14, 'Brooklands'),
(196, 14, 'Continental'),
(197, 14, 'Continental Flying Spur'),
(198, 14, 'Eight'),
(199, 14, 'Flying Spur'),
(200, 14, 'Mulsanne'),
(201, 14, 'S1'),
(202, 14, 'Turbo R'),
(203, 14, 'Turbo RT'),
(204, 14, 'Turbo S'),
(205, 15, '-kita-'),
(206, 15, '1 serija'),
(207, 15, '114'),
(208, 15, '116'),
(209, 15, '118'),
(210, 15, '120'),
(211, 15, '123'),
(212, 15, '125'),
(213, 15, '128'),
(214, 15, '130'),
(215, 15, '135'),
(216, 15, '2 serija'),
(217, 15, '214 Active Tourer'),
(218, 15, '216 Active Tourer'),
(219, 15, '216 Gran Tourer'),
(220, 15, '218'),
(221, 15, '218 Active Tourer'),
(222, 15, '218 Gran Tourer'),
(223, 15, '220'),
(224, 15, '220 Active Tourer'),
(225, 15, '220 Gran Tourer'),
(226, 15, '225'),
(227, 15, '225 Active Tourer'),
(228, 15, '228'),
(229, 15, '230'),
(230, 15, '3 serija'),
(231, 15, '315'),
(232, 15, '316'),
(233, 15, '318'),
(234, 15, '318 Gran turismo'),
(235, 15, '320'),
(236, 15, '320 Gran turismo'),
(237, 15, '323'),
(238, 15, '324'),
(239, 15, '325'),
(240, 15, '325 Gran turismo'),
(241, 15, '327'),
(242, 15, '328'),
(243, 15, '328 Gran turismo'),
(244, 15, '330'),
(245, 15, '330 Gran turismo'),
(246, 15, '335'),
(247, 15, '335 Gran turismo'),
(248, 15, '340'),
(249, 15, '346'),
(250, 15, 'Active Hybrid 3'),
(251, 15, '4 serija'),
(252, 15, '418 Gran Coupe'),
(253, 15, '420'),
(254, 15, '420 Gran Coupe'),
(255, 15, '425'),
(256, 15, '428'),
(257, 15, '428 Gran Coupe'),
(258, 15, '430'),
(259, 15, '430 Gran Coupe'),
(260, 15, '435'),
(261, 15, '435 Gran Coupe'),
(262, 15, '5 serija'),
(263, 15, '518'),
(264, 15, '520'),
(265, 15, '520 Gran turismo'),
(266, 15, '523'),
(267, 15, '524'),
(268, 15, '525'),
(269, 15, '528'),
(270, 15, '530'),
(271, 15, '530 Gran Turismo'),
(272, 15, '535'),
(273, 15, '535 Gran Turismo'),
(274, 15, '540'),
(275, 15, '545'),
(276, 15, '550'),
(277, 15, '550 Gran turismo'),
(278, 15, '5GT (F07)'),
(279, 15, 'Active Hybrid 5'),
(280, 15, '6 serija'),
(281, 15, '628'),
(282, 15, '630'),
(283, 15, '632'),
(284, 15, '633'),
(285, 15, '635'),
(286, 15, '640'),
(287, 15, '640 Gran Coupe'),
(288, 15, '645'),
(289, 15, '650'),
(290, 15, '650 Gran Coupe'),
(291, 15, '7 serija'),
(292, 15, '725'),
(293, 15, '728'),
(294, 15, '730'),
(295, 15, '732'),
(296, 15, '735'),
(297, 15, '740'),
(298, 15, '745'),
(299, 15, '750'),
(300, 15, '760'),
(301, 15, 'Active Hybrid 7'),
(302, 15, '8 serija'),
(303, 15, '840'),
(304, 15, '850'),
(305, 15, 'i serija'),
(306, 15, 'i3'),
(307, 15, 'i8'),
(308, 15, 'M serija'),
(309, 15, '1M Coupe'),
(310, 15, 'M Coupe'),
(311, 15, 'M Roadster'),
(312, 15, 'M1'),
(313, 15, 'M135'),
(314, 15, 'M135i'),
(315, 15, 'M2'),
(316, 15, 'M235'),
(317, 15, 'M3'),
(318, 15, 'M4'),
(319, 15, 'M5'),
(320, 15, 'M550'),
(321, 15, 'M550d'),
(322, 15, 'M6'),
(323, 15, 'X serija'),
(324, 15, 'X1'),
(325, 15, 'X3'),
(326, 15, 'X4'),
(327, 15, 'X5'),
(328, 15, 'X5 M'),
(329, 15, 'X6'),
(330, 15, 'X6 M'),
(331, 15, 'Z serija'),
(332, 15, 'Z1'),
(333, 15, 'Z3'),
(334, 15, 'Z3 M'),
(335, 15, 'Z4'),
(336, 15, 'Z4 M'),
(337, 15, 'Z8'),
(338, 15, '1502'),
(339, 15, '1602'),
(340, 15, '1802'),
(341, 15, '2002'),
(342, 15, '2800CS'),
(343, 16, '-kita-'),
(344, 16, 'Andere'),
(345, 16, 'BC3'),
(346, 16, 'BS2'),
(347, 16, 'BS4'),
(348, 16, 'BS6'),
(349, 17, '-kita-'),
(350, 17, 'EB 110'),
(351, 17, 'Veyron'),
(352, 18, '-kita-'),
(353, 18, 'Century'),
(354, 18, 'Centurion'),
(355, 18, 'Electra'),
(356, 18, 'Enclave'),
(357, 18, 'Encore'),
(358, 18, 'LaCrosse'),
(359, 18, 'Le Sabre'),
(360, 18, 'LeSabre'),
(361, 18, 'Lucerne'),
(362, 18, 'Park Avenue'),
(363, 18, 'Rainier'),
(364, 18, 'Regal'),
(365, 18, 'Rendezvous'),
(366, 18, 'Riviera'),
(367, 18, 'Roadmaster'),
(368, 18, 'Skylark'),
(369, 18, 'Terraza'),
(370, 18, 'Verano'),
(371, 19, '-kita-'),
(372, 19, 'Allante'),
(373, 19, 'ATS'),
(374, 19, 'BLS'),
(375, 19, 'Catera'),
(376, 19, 'CTS'),
(377, 19, 'DeVille'),
(378, 19, 'DTS'),
(379, 19, 'Eldorado'),
(380, 19, 'Escalade'),
(381, 19, 'Fleetwood'),
(382, 19, 'Seville'),
(383, 19, 'SRX'),
(384, 19, 'STS'),
(385, 19, 'Vizon'),
(386, 19, 'XLR'),
(387, 19, 'XTS'),
(388, 20, '-kita-'),
(389, 20, '2500'),
(390, 20, 'Alero'),
(391, 20, 'Astro'),
(392, 20, 'Avalanche'),
(393, 20, 'Aveo'),
(394, 20, 'Bel Air'),
(395, 20, 'Beretta'),
(396, 20, 'Blazer'),
(397, 20, 'C1500'),
(398, 20, 'Camaro'),
(399, 20, 'Caprice'),
(400, 20, 'Captiva'),
(401, 20, 'Cavalier'),
(402, 20, 'Chevelle'),
(403, 20, 'Chevy Van'),
(404, 20, 'Citation'),
(405, 20, 'Cobalt'),
(406, 20, 'Colorado'),
(407, 20, 'Corsica'),
(408, 20, 'Corvette'),
(409, 20, 'Cruze'),
(410, 20, 'El Camino'),
(411, 20, 'Epica'),
(412, 20, 'Equinox'),
(413, 20, 'Evanda'),
(414, 20, 'Express'),
(415, 20, 'HHR'),
(416, 20, 'Impala'),
(417, 20, 'Ipanema'),
(418, 20, 'Kalos'),
(419, 20, 'Lacetti'),
(420, 20, 'Lumina'),
(421, 20, 'M 1009'),
(422, 20, 'Malibu'),
(423, 20, 'Matiz'),
(424, 20, 'Metro'),
(425, 20, 'Monte Carlo'),
(426, 20, 'Monza'),
(427, 20, 'Nubira'),
(428, 20, 'Orlando'),
(429, 20, 'Pickup'),
(430, 20, 'Prizm'),
(431, 20, 'Rezzo'),
(432, 20, 'S 10'),
(433, 20, 'Silverado'),
(434, 20, 'Sonic'),
(435, 20, 'Spark'),
(436, 20, 'Special Deluxe'),
(437, 20, 'SSR'),
(438, 20, 'Suburban'),
(439, 20, 'Tacuma'),
(440, 20, 'Tahoe'),
(441, 20, 'Tracker'),
(442, 20, 'TrailBlazer'),
(443, 20, 'Trans Sport'),
(444, 20, 'Traverse'),
(445, 20, 'Trax'),
(446, 20, 'Uplander'),
(447, 20, 'Venture'),
(448, 20, 'Volt'),
(449, 21, '-kita-'),
(450, 21, '200'),
(451, 21, '300'),
(452, 21, '300C'),
(453, 21, '300M'),
(454, 21, 'Aspen'),
(455, 21, 'Cirrus'),
(456, 21, 'Concorde'),
(457, 21, 'Conquest'),
(458, 21, 'Crossfire'),
(459, 21, 'Daytona'),
(460, 21, 'Daytona Shelby'),
(461, 21, 'ES'),
(462, 21, 'Grand Voyager'),
(463, 21, 'Imperial'),
(464, 21, 'Intrepid'),
(465, 21, 'Le Baron'),
(466, 21, 'LHS'),
(467, 21, 'Neon'),
(468, 21, 'New Yorker'),
(469, 21, 'Newport'),
(470, 21, 'Pacifica'),
(471, 21, 'Plymouth'),
(472, 21, 'Prowler'),
(473, 21, 'PT Cruiser'),
(474, 21, 'Saratoga'),
(475, 21, 'Sebring'),
(476, 21, 'Stratus'),
(477, 21, 'Town & Country'),
(478, 21, 'Valiant'),
(479, 21, 'Viper'),
(480, 21, 'Vision'),
(481, 21, 'Voyager'),
(482, 22, '-kita-'),
(483, 22, '2 CV'),
(484, 22, 'AX'),
(485, 22, 'Berlingo'),
(486, 22, 'BX'),
(487, 22, 'C Crosser'),
(488, 22, 'C Elysee'),
(489, 22, 'C Zero'),
(490, 22, 'C1'),
(491, 22, 'C15'),
(492, 22, 'C2'),
(493, 22, 'C25'),
(494, 22, 'C3'),
(495, 22, 'C3 Picasso  '),
(496, 22, 'C3 Pluriel'),
(497, 22, 'C4'),
(498, 22, 'C4 Aircross'),
(499, 22, 'C4 Cactus'),
(500, 22, 'C4 Picasso'),
(501, 22, 'C5'),
(502, 22, 'C6'),
(503, 22, 'C8'),
(504, 22, 'CX'),
(505, 22, 'DS'),
(506, 22, 'DS3'),
(507, 22, 'DS4'),
(508, 22, 'DS5'),
(509, 22, 'Evasion'),
(510, 22, 'Grand C4 Picasso'),
(511, 22, 'GSA'),
(512, 22, 'Jumper'),
(513, 22, 'Jumpy'),
(514, 22, 'Nemo'),
(515, 22, 'Saxo'),
(516, 22, 'SM'),
(517, 22, 'Spacetourer'),
(518, 22, 'Synergie'),
(519, 22, 'Visa'),
(520, 22, 'Xantia'),
(521, 22, 'XM'),
(522, 22, 'Xsara'),
(523, 22, 'Xsara Picasso'),
(524, 22, 'ZX'),
(525, 23, '-kita-'),
(526, 23, 'AC'),
(527, 24, '-kita-'),
(528, 24, 'Dokker'),
(529, 24, 'Duster'),
(530, 24, 'Lodgy'),
(531, 24, 'Logan'),
(532, 24, 'Sandero'),
(533, 25, '-kita-'),
(534, 25, 'Espero'),
(535, 25, 'Evanda'),
(536, 25, 'Istana'),
(537, 25, 'Kalos'),
(538, 25, 'Korando'),
(539, 25, 'Labo'),
(540, 25, 'Lacetti'),
(541, 25, 'Lanos'),
(542, 25, 'Leganza'),
(543, 25, 'Lublin'),
(544, 25, 'Magnus'),
(545, 25, 'Matiz'),
(546, 25, 'Musso'),
(547, 25, 'Nexia'),
(548, 25, 'Nubira'),
(549, 25, 'Polonez'),
(550, 25, 'Prince'),
(551, 25, 'Racer'),
(552, 25, 'Rexton'),
(553, 25, 'Rezzo'),
(554, 25, 'Tacuma'),
(555, 25, 'Tico'),
(556, 26, '-kita-'),
(557, 26, '33'),
(558, 26, '44'),
(559, 26, '46'),
(560, 26, '55'),
(561, 26, '600'),
(562, 26, '66'),
(563, 27, '-kita-'),
(564, 27, '1000'),
(565, 27, '1000'),
(566, 27, 'Applause'),
(567, 27, 'Charade'),
(568, 27, 'Charmant'),
(569, 27, 'Copen'),
(570, 27, 'Cuore'),
(571, 27, 'Delta'),
(572, 27, 'Feroza'),
(573, 27, 'Freeclimber'),
(574, 27, 'Gran Move'),
(575, 27, 'Hi Jet'),
(576, 27, 'Leeza'),
(577, 27, 'Materia'),
(578, 27, 'Max'),
(579, 27, 'Mira'),
(580, 27, 'Move'),
(581, 27, 'Naked'),
(582, 27, 'Opti'),
(583, 27, 'Rocky'),
(584, 27, 'Sirion'),
(585, 27, 'Sparcar'),
(586, 27, 'Terios'),
(587, 27, 'Trevis'),
(588, 27, 'Valera'),
(589, 27, 'YRV'),
(590, 28, '-kita-'),
(591, 28, '260z'),
(592, 28, '280z'),
(593, 29, '-kita-'),
(594, 30, '-kita-'),
(595, 30, 'Adventurer'),
(596, 30, 'Airflow'),
(597, 30, 'Airstream'),
(598, 30, 'Custom'),
(599, 30, 'Deluxe'),
(600, 30, 'Diplomat'),
(601, 30, 'Firedome'),
(602, 30, 'Fireflite'),
(603, 30, 'Firesweep'),
(604, 30, 'Powermaster'),
(605, 31, '-kita-'),
(606, 31, 'Avenger'),
(607, 31, 'Caliber'),
(608, 31, 'Caravan'),
(609, 31, 'Challenger'),
(610, 31, 'Charger'),
(611, 31, 'Dakota'),
(612, 31, 'Dart'),
(613, 31, 'Demon'),
(614, 31, 'Durango'),
(615, 31, 'Grand Caravan'),
(616, 31, 'Hornet'),
(617, 31, 'Intrepid'),
(618, 31, 'Journey'),
(619, 31, 'Magnum'),
(620, 31, 'Neon'),
(621, 31, 'Nitro'),
(622, 31, 'Ram'),
(623, 31, 'Spirit'),
(624, 31, 'Stealth'),
(625, 31, 'Stratus'),
(626, 31, 'Viper'),
(627, 31, 'Voyager'),
(628, 32, '-kita-'),
(629, 33, '-kita-'),
(630, 33, 'Summit'),
(631, 33, 'Summit Wagon'),
(632, 33, 'Talon'),
(633, 33, 'Vision'),
(634, 34, '-kita-'),
(635, 34, 'F 360'),
(636, 34, '208'),
(637, 34, '246'),
(638, 34, '250'),
(639, 34, '275'),
(640, 34, '288'),
(641, 34, '308'),
(642, 34, '328'),
(643, 34, '330'),
(644, 34, '348'),
(645, 34, '360'),
(646, 34, '365'),
(647, 34, '400'),
(648, 34, '412'),
(649, 34, '456'),
(650, 34, '458'),
(651, 34, '512'),
(652, 34, '550'),
(653, 34, '575'),
(654, 34, '599 GTB Fiorano'),
(655, 34, '612'),
(656, 34, '612 Scaglietti'),
(657, 34, '750'),
(658, 34, 'Barchetta'),
(659, 34, 'California'),
(660, 34, 'Daytona'),
(661, 34, 'Enzo'),
(662, 34, 'F 355'),
(663, 34, 'F 40'),
(664, 34, 'F 430'),
(665, 34, 'F 50'),
(666, 34, 'F 512'),
(667, 34, 'Maranello'),
(668, 34, 'Mondial'),
(669, 34, 'Superamerica'),
(670, 34, 'Testarossa'),
(671, 35, '-kita-'),
(672, 35, '124'),
(673, 35, '126'),
(674, 35, '127'),
(675, 35, '130'),
(676, 35, '131'),
(677, 35, '500'),
(678, 35, '500 Abarth'),
(679, 35, '500L'),
(680, 35, '500X'),
(681, 35, '850 Spider '),
(682, 35, 'Albea'),
(683, 35, 'Barchetta'),
(684, 35, 'Brava'),
(685, 35, 'Bravo'),
(686, 35, 'Cinquecento'),
(687, 35, 'Coupe'),
(688, 35, 'Croma'),
(689, 35, 'Dino'),
(690, 35, 'Doblo'),
(691, 35, 'Ducato'),
(692, 35, 'Duna'),
(693, 35, 'Fiorino'),
(694, 35, 'Freemont'),
(695, 35, 'Fullback'),
(696, 35, 'Grande Punto'),
(697, 35, 'Idea'),
(698, 35, 'Linea'),
(699, 35, 'Marea'),
(700, 35, 'Marengo'),
(701, 35, 'Multipla'),
(702, 35, 'Palio'),
(703, 35, 'Palio Weekend'),
(704, 35, 'Panda'),
(705, 35, 'Punto'),
(706, 35, 'Punto Evo'),
(707, 35, 'Qubo'),
(708, 35, 'Regata'),
(709, 35, 'Ritmo'),
(710, 35, 'Scudo'),
(711, 35, 'Sedici'),
(712, 35, 'Seicento'),
(713, 35, 'Stilo'),
(714, 35, 'Strada'),
(715, 35, 'Talento'),
(716, 35, 'Tempra'),
(717, 35, 'Tipo'),
(718, 35, 'Ulysse'),
(719, 35, 'Uno'),
(720, 35, 'X 1/9'),
(721, 36, '-kita-'),
(722, 36, 'Atlantic'),
(723, 36, 'Karma '),
(724, 37, '-kita-'),
(725, 37, 'Aerostar'),
(726, 37, 'Aspire'),
(727, 37, 'B MAX'),
(728, 37, 'Bronco'),
(729, 37, 'C MAX'),
(730, 37, 'Capri'),
(731, 37, 'Caravan'),
(732, 37, 'Cargo'),
(733, 37, 'Club Wagon'),
(734, 37, 'Connect Tourneo'),
(735, 37, 'Contour'),
(736, 37, 'Cougar'),
(737, 37, 'Courier'),
(738, 37, 'Crown Victoria'),
(739, 37, 'Econoline'),
(740, 37, 'Econovan'),
(741, 37, 'EcoSport'),
(742, 37, 'Edge'),
(743, 37, 'Escape'),
(744, 37, 'Escort'),
(745, 37, 'Excursion'),
(746, 37, 'Expedition'),
(747, 37, 'Explorer'),
(748, 37, 'Express'),
(749, 37, 'F150'),
(750, 37, 'F250'),
(751, 37, 'F350'),
(752, 37, 'F450'),
(753, 37, 'F470'),
(754, 37, 'F700'),
(755, 37, 'Fairlane'),
(756, 37, 'Falcon'),
(757, 37, 'Fiesta'),
(758, 37, 'Five Hundred'),
(759, 37, 'Flex'),
(760, 37, 'Focus'),
(761, 37, 'Freestar'),
(762, 37, 'Freestyle'),
(763, 37, 'Fusion'),
(764, 37, 'Galaxy'),
(765, 37, 'Granada'),
(766, 37, 'Grand C MAX'),
(767, 37, 'GT'),
(768, 37, 'Ka'),
(769, 37, 'Kuga'),
(770, 37, 'LTD'),
(771, 37, 'Maverick'),
(772, 37, 'Mercury'),
(773, 37, 'Mondeo'),
(774, 37, 'Mustang'),
(775, 37, 'Orion'),
(776, 37, 'Probe'),
(777, 37, 'Puma'),
(778, 37, 'Ranger'),
(779, 37, 'S MAX'),
(780, 37, 'Scorpio'),
(781, 37, 'Sierra'),
(782, 37, 'Sportka'),
(783, 37, 'Streetka'),
(784, 37, 'Superduty'),
(785, 37, 'Taunus'),
(786, 37, 'Taurus'),
(787, 37, 'Tempo'),
(788, 37, 'Thunderbird'),
(789, 37, 'Tourneo'),
(790, 37, 'Transit'),
(791, 37, 'Transit Connect'),
(792, 37, 'Transit Custom'),
(793, 37, 'Windstar'),
(794, 38, '-kita-'),
(795, 38, '22'),
(796, 38, '11 73'),
(797, 38, '12 ZiM'),
(798, 38, '12B'),
(799, 38, '13'),
(800, 38, '14'),
(801, 38, '21'),
(802, 38, '2110'),
(803, 38, '24'),
(804, 38, '2410'),
(805, 38, '2752'),
(806, 38, '3110'),
(807, 38, '32213'),
(808, 38, '3302'),
(809, 38, '3308'),
(810, 38, '53'),
(811, 38, '61'),
(812, 38, '64'),
(813, 38, '66'),
(814, 38, '67'),
(815, 38, '69A'),
(816, 38, 'Chaika'),
(817, 38, 'Gazele'),
(818, 38, 'M 20 Pobeda'),
(819, 38, 'M1'),
(820, 38, 'Volga'),
(821, 39, '-kita-'),
(822, 39, 'Metro'),
(823, 39, 'Prizm'),
(824, 39, 'Spectrum'),
(825, 39, 'Storm'),
(826, 39, 'Tracker'),
(827, 40, '-kita-'),
(828, 40, 'Acadia'),
(829, 40, 'Envoy'),
(830, 40, 'Jimmy'),
(831, 40, 'Safari'),
(832, 40, 'Savana'),
(833, 40, 'Sierra'),
(834, 40, 'Sonoma'),
(835, 40, 'Suburban'),
(836, 40, 'Syclone'),
(837, 40, 'Terrain'),
(838, 40, 'Typhoon'),
(839, 40, 'Yukon'),
(840, 41, '-kita-'),
(841, 41, 'GA200'),
(842, 41, 'GX6'),
(843, 42, '-kita-'),
(844, 42, 'Deer'),
(845, 42, 'Hover'),
(846, 42, 'Pegasus'),
(847, 42, 'Safe'),
(848, 42, 'Sailor'),
(849, 42, 'Sing'),
(850, 42, 'Socool'),
(851, 42, 'Wingle'),
(852, 43, '-kita-'),
(853, 43, 'Accord'),
(854, 43, 'Aerodeck'),
(855, 43, 'Avancier'),
(856, 43, 'Capa'),
(857, 43, 'City'),
(858, 43, 'Civic'),
(859, 43, 'Concerto'),
(860, 43, 'CR V'),
(861, 43, 'Crosstour'),
(862, 43, 'CRX'),
(863, 43, 'CRZ'),
(864, 43, 'Domani'),
(865, 43, 'Element'),
(866, 43, 'F- MX'),
(867, 43, 'FIT'),
(868, 43, 'FR V'),
(869, 43, 'HR V'),
(870, 43, 'Insight'),
(871, 43, 'Inspire'),
(872, 43, 'Integra'),
(873, 43, 'Jazz'),
(874, 43, 'Lagreat'),
(875, 43, 'Legend'),
(876, 43, 'Life'),
(877, 43, 'Logo'),
(878, 43, 'Mobilo'),
(879, 43, 'NSX'),
(880, 43, 'Odyssey'),
(881, 43, 'Passport'),
(882, 43, 'Pilot'),
(883, 43, 'Prelude'),
(884, 43, 'Ridgeline'),
(885, 43, 'S2000'),
(886, 43, 'Shuttle'),
(887, 43, 'Stream'),
(888, 43, 'Today'),
(889, 44, '-kita-'),
(890, 44, 'H1'),
(891, 44, 'H2'),
(892, 44, 'H3'),
(893, 45, '-kita-'),
(894, 45, 'Accent'),
(895, 45, 'Atos'),
(896, 45, 'Azera'),
(897, 45, 'Coupe'),
(898, 45, 'Elantra'),
(899, 45, 'Entourage'),
(900, 45, 'Equus'),
(901, 45, 'Excel'),
(902, 45, 'Galloper'),
(903, 45, 'Genesis'),
(904, 45, 'Getz'),
(905, 45, 'Grandeur'),
(906, 45, 'H1'),
(907, 45, 'H1 Travel'),
(908, 45, 'H100'),
(909, 45, 'H200'),
(910, 45, 'i10'),
(911, 45, 'i20'),
(912, 45, 'i30'),
(913, 45, 'i40'),
(914, 45, 'i50'),
(915, 45, 'IONIQ'),
(916, 45, 'ix20'),
(917, 45, 'ix35'),
(918, 45, 'ix55'),
(919, 45, 'Lantra'),
(920, 45, 'Lavita'),
(921, 45, 'Marcia'),
(922, 45, 'Matrix'),
(923, 45, 'Pony'),
(924, 45, 'S Coupe'),
(925, 45, 'Santa Fe'),
(926, 45, 'Santamo'),
(927, 45, 'Solaris'),
(928, 45, 'Sonata'),
(929, 45, 'Sonica'),
(930, 45, 'Starex'),
(931, 45, 'Terracan'),
(932, 45, 'Tiburon'),
(933, 45, 'Trajet'),
(934, 45, 'Tucson'),
(935, 45, 'Veloster'),
(936, 45, 'Veracruz'),
(937, 45, 'XG'),
(938, 45, 'XG 350'),
(939, 45, 'XG30'),
(940, 46, '-kita-'),
(941, 46, 'EX'),
(942, 46, 'EX30'),
(943, 46, 'EX35'),
(944, 46, 'EX37'),
(945, 46, 'FX'),
(946, 46, 'FX30'),
(947, 46, 'FX35'),
(948, 46, 'FX37'),
(949, 46, 'FX45'),
(950, 46, 'FX50'),
(951, 46, 'G20'),
(952, 46, 'G35'),
(953, 46, 'G37'),
(954, 46, 'I30'),
(955, 46, 'I35'),
(956, 46, 'J30'),
(957, 46, 'JX35'),
(958, 46, 'M30'),
(959, 46, 'M35/45'),
(960, 46, 'M37'),
(961, 46, 'M56'),
(962, 46, 'Q30'),
(963, 46, 'Q45'),
(964, 46, 'Q50'),
(965, 46, 'Q60'),
(966, 46, 'Q70'),
(967, 46, 'QX4'),
(968, 46, 'QX50'),
(969, 46, 'QX56'),
(970, 46, 'QX60'),
(971, 46, 'QX70'),
(972, 47, '-kita-'),
(973, 47, 'Scout'),
(974, 47, 'Scout II'),
(975, 48, '-kita-'),
(976, 48, 'Amigo'),
(977, 48, 'Ascender'),
(978, 48, 'Aska'),
(979, 48, 'Axiom'),
(980, 48, 'Bighorn'),
(981, 48, 'Campo'),
(982, 48, 'D Max'),
(983, 48, 'Gemini'),
(984, 48, 'HiLander'),
(985, 48, 'Impulse'),
(986, 48, 'Midi'),
(987, 48, 'MU'),
(988, 48, 'NPR'),
(989, 48, 'Panther'),
(990, 48, 'Piazza'),
(991, 48, 'Pick Up'),
(992, 48, 'Rodeo'),
(993, 48, 'Trooper'),
(994, 48, 'Turkuaz'),
(995, 48, 'Vehi Cross'),
(996, 48, 'Wizard'),
(997, 49, '-kita-'),
(998, 49, 'Daily'),
(999, 49, '35 12'),
(1000, 49, 'Massif'),
(1001, 50, '-kita-'),
(1002, 50, 'Daimler'),
(1003, 50, 'E Type'),
(1004, 50, 'F Pace'),
(1005, 50, 'F Type'),
(1006, 50, 'MK II'),
(1007, 50, 'S Type'),
(1008, 50, 'Sovereign'),
(1009, 50, 'Vanden Plas'),
(1010, 50, 'X Type'),
(1011, 50, 'XE'),
(1012, 50, 'XF'),
(1013, 50, 'XJ'),
(1014, 50, 'XJ Series'),
(1015, 50, 'XJ12'),
(1016, 50, 'XJ40'),
(1017, 50, 'XJ6'),
(1018, 50, 'XJ8'),
(1019, 50, 'XJR'),
(1020, 50, 'XJS'),
(1021, 50, 'XK'),
(1022, 50, 'XK Series'),
(1023, 50, 'XK8'),
(1024, 50, 'XKR'),
(1025, 51, '-kita-'),
(1026, 51, 'Cherokee'),
(1027, 51, 'CJ'),
(1028, 51, 'Comanche'),
(1029, 51, 'Commander'),
(1030, 51, 'Compass'),
(1031, 51, 'Grand Cherokee'),
(1032, 51, 'Liberty'),
(1033, 51, 'Patriot'),
(1034, 51, 'Renegade'),
(1035, 51, 'Wagoneer'),
(1036, 51, 'Willys'),
(1037, 51, 'Wrangler'),
(1038, 52, '-kita-'),
(1039, 52, 'Avella'),
(1040, 52, 'Besta'),
(1041, 52, 'Borrego'),
(1042, 52, 'Cadenza'),
(1043, 52, 'Carens'),
(1044, 52, 'Carnival'),
(1045, 52, 'cee\'d'),
(1046, 52, 'Cerato'),
(1047, 52, 'Clarus'),
(1048, 52, 'Elan'),
(1049, 52, 'Enterprise'),
(1050, 52, 'Forte'),
(1051, 52, 'Joice'),
(1052, 52, 'K2500'),
(1053, 52, 'K2700'),
(1054, 52, 'Leo'),
(1055, 52, 'Magentis'),
(1056, 52, 'Mentor'),
(1057, 52, 'Mini'),
(1058, 52, 'Niro'),
(1059, 52, 'Opirus'),
(1060, 52, 'Optima'),
(1061, 52, 'Picanto'),
(1062, 52, 'Potentia'),
(1063, 52, 'Pregio'),
(1064, 52, 'Pride'),
(1065, 52, 'Pro cee\'d'),
(1066, 52, 'Retona'),
(1067, 52, 'Rio'),
(1068, 52, 'Roadster'),
(1069, 52, 'Rocsta'),
(1070, 52, 'Rondo'),
(1071, 52, 'Sedona'),
(1072, 52, 'Sephia'),
(1073, 52, 'Shuma'),
(1074, 52, 'Sorento'),
(1075, 52, 'Soul'),
(1076, 52, 'Spectra'),
(1077, 52, 'Sportage'),
(1078, 52, 'Venga'),
(1079, 53, '-kita-'),
(1080, 53, 'Agera'),
(1081, 53, 'CC8S'),
(1082, 53, 'CCGT'),
(1083, 53, 'CCR'),
(1084, 53, 'CCX'),
(1085, 53, 'CCX Edition'),
(1086, 53, 'CCXR'),
(1087, 53, 'CCXR Edition'),
(1088, 53, 'CCXR Special Edition'),
(1089, 53, 'Trevita'),
(1090, 54, '-kita-'),
(1091, 54, '110'),
(1092, 54, '111'),
(1093, 54, '112'),
(1094, 54, '1200'),
(1095, 54, '2101'),
(1096, 54, '21011'),
(1097, 54, '21013'),
(1098, 54, '2102'),
(1099, 54, '2103'),
(1100, 54, '2104'),
(1101, 54, '2105'),
(1102, 54, '21051'),
(1103, 54, '21053'),
(1104, 54, '2106'),
(1105, 54, '21061'),
(1106, 54, '21063'),
(1107, 54, '2107'),
(1108, 54, '2108'),
(1109, 54, '2109'),
(1110, 54, '2110'),
(1111, 54, '2111'),
(1112, 54, '21110'),
(1113, 54, '21111'),
(1114, 54, '2112'),
(1115, 54, '2115'),
(1116, 54, '2120'),
(1117, 54, '2121'),
(1118, 54, '21213'),
(1119, 54, '21214'),
(1120, 54, '21215'),
(1121, 54, '2123'),
(1122, 54, '2129'),
(1123, 54, '2131'),
(1124, 54, '2141'),
(1125, 54, '2329'),
(1126, 54, 'Aleko'),
(1127, 54, 'Forma'),
(1128, 54, 'Kalina'),
(1129, 54, 'Niva'),
(1130, 54, 'Nova'),
(1131, 54, 'Oka'),
(1132, 54, 'Priora'),
(1133, 54, 'Samara'),
(1134, 54, 'Vis'),
(1135, 55, '-kita-'),
(1136, 55, 'Aventador'),
(1137, 55, 'Countach'),
(1138, 55, 'Diablo'),
(1139, 55, 'Espada'),
(1140, 55, 'Gallardo'),
(1141, 55, 'Huracan'),
(1142, 55, 'Jalpa'),
(1143, 55, 'LM'),
(1144, 55, 'Miura'),
(1145, 55, 'Murcielago'),
(1146, 55, 'Urraco'),
(1147, 56, '-kita-'),
(1148, 56, 'Beta'),
(1149, 56, 'Dedra'),
(1150, 56, 'Delta'),
(1151, 56, 'Flaminia'),
(1152, 56, 'Fulvia'),
(1153, 56, 'Gamma'),
(1154, 56, 'Kappa'),
(1155, 56, 'Lybra'),
(1156, 56, 'Montecarlo'),
(1157, 56, 'Musa'),
(1158, 56, 'Phedra'),
(1159, 56, 'Prisma'),
(1160, 56, 'Stratos'),
(1161, 56, 'Thema'),
(1162, 56, 'Thesis'),
(1163, 56, 'Voyager'),
(1164, 56, 'Y'),
(1165, 56, 'Ypsilon'),
(1166, 56, 'Zeta'),
(1167, 57, '-kita-'),
(1168, 57, 'Defender'),
(1169, 57, 'Discovery'),
(1170, 57, 'Evoque'),
(1171, 57, 'Freelander'),
(1172, 57, 'Range Rover'),
(1173, 57, 'Range Rover Sport'),
(1174, 58, '-kita-'),
(1175, 58, '-kita-'),
(1176, 58, 'S'),
(1177, 58, 'SC 2'),
(1178, 58, 'SC 4'),
(1179, 59, '-kita-'),
(1180, 59, 'CT 200h'),
(1181, 59, 'ES klasė'),
(1182, 59, 'ES 300'),
(1183, 59, 'ES 330'),
(1184, 59, 'ES 350h'),
(1185, 59, 'ES 350'),
(1186, 59, 'GS klasė'),
(1187, 59, 'GS 200t'),
(1188, 59, 'GS 250'),
(1189, 59, 'GS 300'),
(1190, 59, 'GS 300h'),
(1191, 59, 'GS 350 '),
(1192, 59, 'GS 400'),
(1193, 59, 'GS 430'),
(1194, 59, 'GS 450'),
(1195, 59, 'GS 460'),
(1196, 59, 'GS F'),
(1197, 59, 'GX klasė'),
(1198, 59, 'GX 460'),
(1199, 59, 'GX 470'),
(1200, 59, 'GX 640'),
(1201, 59, 'HS klasė'),
(1202, 59, 'HS 250'),
(1203, 59, 'IS klasė'),
(1204, 59, 'IS 200'),
(1205, 59, 'IS 300h'),
(1206, 59, 'IS 220'),
(1207, 59, 'IS 250'),
(1208, 59, 'IS 300'),
(1209, 59, 'IS 350'),
(1210, 59, 'IS F'),
(1211, 59, 'LFA'),
(1212, 59, 'LS klasė'),
(1213, 59, 'LS 400'),
(1214, 59, 'LS 430'),
(1215, 59, 'LS 460'),
(1216, 59, 'LS 600 h'),
(1217, 59, 'LX klasė'),
(1218, 59, 'LX 450'),
(1219, 59, 'LX 470'),
(1220, 59, 'LX 570'),
(1221, 59, 'NX klasė'),
(1222, 59, 'NX 200t'),
(1223, 59, 'NX 300h'),
(1224, 59, 'RC klasė'),
(1225, 59, 'RC 200t'),
(1226, 59, 'RC 300h'),
(1227, 59, 'RC 350'),
(1228, 59, 'RC F'),
(1229, 59, 'RX klasė'),
(1230, 59, 'RX 200t'),
(1231, 59, 'RX 300'),
(1232, 59, 'RX 330'),
(1233, 59, 'RX 350'),
(1234, 59, 'RX 400h'),
(1235, 59, 'RX 450h'),
(1236, 59, 'SC klasė'),
(1237, 59, 'SC 300'),
(1238, 59, 'SC 400'),
(1239, 59, 'SC 430'),
(1240, 59, 'SL'),
(1241, 60, '-kita-'),
(1242, 60, 'Ambra'),
(1243, 60, 'Andere'),
(1244, 60, 'ixo'),
(1245, 60, 'JS 50'),
(1246, 60, 'Nova'),
(1247, 60, 'Optima'),
(1248, 60, 'X - Too'),
(1249, 61, '-kita-'),
(1250, 61, 'Aviator'),
(1251, 61, 'Continental'),
(1252, 61, 'LS'),
(1253, 61, 'Mark'),
(1254, 61, 'MKS'),
(1255, 61, 'MKT'),
(1256, 61, 'MKX'),
(1257, 61, 'MKZ'),
(1258, 61, 'Navigator'),
(1259, 61, 'Town Car'),
(1260, 61, 'Zephyr'),
(1261, 62, '-kita-'),
(1262, 62, '340 R'),
(1263, 62, 'Cortina'),
(1264, 62, 'Eagle'),
(1265, 62, 'Elan'),
(1266, 62, 'Elise'),
(1267, 62, 'Elite'),
(1268, 62, 'Esprit'),
(1269, 62, 'Europa'),
(1270, 62, 'Evora'),
(1271, 62, 'Excel'),
(1272, 62, 'Exige'),
(1273, 62, 'Super Seven'),
(1274, 62, 'V8'),
(1275, 63, '-kita-'),
(1276, 63, '1302'),
(1277, 63, '967M'),
(1278, 63, '969M'),
(1279, 64, '-kita-'),
(1280, 65, '-kita-'),
(1281, 65, '222'),
(1282, 65, '224'),
(1283, 65, '228'),
(1284, 65, '3200'),
(1285, 65, '3200 GT'),
(1286, 65, '418'),
(1287, 65, '420'),
(1288, 65, '4200'),
(1289, 65, '422'),
(1290, 65, '424'),
(1291, 65, '430'),
(1292, 65, 'Biturbo'),
(1293, 65, 'Chamal'),
(1294, 65, 'Ghibli'),
(1295, 65, 'GranCabrio'),
(1296, 65, 'Gransport'),
(1297, 65, 'GranTurismo'),
(1298, 65, 'Indy'),
(1299, 65, 'Karif'),
(1300, 65, 'Levante'),
(1301, 65, 'MC12'),
(1302, 65, 'Merak'),
(1303, 65, 'Quattroporte'),
(1304, 65, 'Spyder'),
(1305, 66, '-kita-'),
(1306, 66, '57'),
(1307, 66, '62'),
(1308, 67, '-kita-'),
(1309, 67, '121'),
(1310, 67, '2'),
(1311, 67, '3'),
(1312, 67, '323'),
(1313, 67, '323F'),
(1314, 67, '5'),
(1315, 67, '6'),
(1316, 67, '626'),
(1317, 67, '929'),
(1318, 67, 'Atenza'),
(1319, 67, 'AZ'),
(1320, 67, 'B Series'),
(1321, 67, 'Bongo'),
(1322, 67, 'BT 50'),
(1323, 67, 'Carol'),
(1324, 67, 'Clef'),
(1325, 67, 'Cronos'),
(1326, 67, 'CX 3'),
(1327, 67, 'CX 5'),
(1328, 67, 'CX 7'),
(1329, 67, 'CX 9'),
(1330, 67, 'Demio'),
(1331, 67, 'Eunos'),
(1332, 67, 'Lantis'),
(1333, 67, 'Laputa'),
(1334, 67, 'Levante'),
(1335, 67, 'Miata'),
(1336, 67, 'Millenia'),
(1337, 67, 'MPV'),
(1338, 67, 'MX 3'),
(1339, 67, 'MX 5'),
(1340, 67, 'MX 6'),
(1341, 67, 'Navajo'),
(1342, 67, 'PickUp'),
(1343, 67, 'Premacy'),
(1344, 67, 'Protege'),
(1345, 67, 'Rustler'),
(1346, 67, 'RX 6'),
(1347, 67, 'RX 7'),
(1348, 67, 'RX 8'),
(1349, 67, 'Tribute'),
(1350, 67, 'Vantred'),
(1351, 67, 'Xedos 6'),
(1352, 67, 'Xedos 9'),
(1353, 68, '-kita-'),
(1354, 68, '570S'),
(1355, 68, '650S'),
(1356, 68, '650S Coupe'),
(1357, 68, '650S Spider'),
(1358, 68, '675LT'),
(1359, 68, '675LT Spider'),
(1360, 68, 'Andere'),
(1361, 68, 'MP4 12C'),
(1362, 68, 'P1'),
(1363, 69, '-kita-'),
(1364, 69, '100'),
(1365, 69, '108'),
(1366, 69, '110'),
(1367, 69, '123'),
(1368, 69, '124'),
(1369, 69, '180'),
(1370, 69, '190'),
(1371, 69, '200'),
(1372, 69, '207'),
(1373, 69, '208'),
(1374, 69, '209'),
(1375, 69, '210'),
(1376, 69, '211'),
(1377, 69, '212'),
(1378, 69, '219'),
(1379, 69, '220'),
(1380, 69, '230'),
(1381, 69, '240'),
(1382, 69, '250'),
(1383, 69, '260'),
(1384, 69, '270'),
(1385, 69, '280'),
(1386, 69, '290'),
(1387, 69, '300'),
(1388, 69, '300 GD'),
(1389, 69, '307'),
(1390, 69, '308'),
(1391, 69, '320'),
(1392, 69, '350'),
(1393, 69, '380'),
(1394, 69, '400'),
(1395, 69, '416'),
(1396, 69, '420'),
(1397, 69, '450'),
(1398, 69, '500'),
(1399, 69, '560'),
(1400, 69, '600'),
(1401, 69, '608'),
(1402, 69, 'A klasė'),
(1403, 69, 'A140'),
(1404, 69, 'A150'),
(1405, 69, 'A160'),
(1406, 69, 'A170'),
(1407, 69, 'A180'),
(1408, 69, 'A190'),
(1409, 69, 'A200'),
(1410, 69, 'A210'),
(1411, 69, 'A220'),
(1412, 69, 'A250'),
(1413, 69, 'A45 AMG'),
(1414, 69, 'AMG GT '),
(1415, 69, 'Atego'),
(1416, 69, 'B klasė'),
(1417, 69, 'B150'),
(1418, 69, 'B160'),
(1419, 69, 'B170'),
(1420, 69, 'B180'),
(1421, 69, 'B200'),
(1422, 69, 'B220'),
(1423, 69, 'B246'),
(1424, 69, 'B250'),
(1425, 69, 'C klasė'),
(1426, 69, 'C160'),
(1427, 69, 'C180'),
(1428, 69, 'C200'),
(1429, 69, 'C220'),
(1430, 69, 'C230'),
(1431, 69, 'C240'),
(1432, 69, 'C250'),
(1433, 69, 'C270'),
(1434, 69, 'C280'),
(1435, 69, 'C30 AMG'),
(1436, 69, 'C300'),
(1437, 69, 'C32 AMG'),
(1438, 69, 'C320'),
(1439, 69, 'C350'),
(1440, 69, 'C36 AMG'),
(1441, 69, 'C400'),
(1442, 69, 'C43 AMG'),
(1443, 69, 'C450'),
(1444, 69, 'C55 AMG'),
(1445, 69, 'C63 AMG'),
(1446, 69, 'C klasė SC'),
(1447, 69, 'CE klasė'),
(1448, 69, 'CE200'),
(1449, 69, 'CE220'),
(1450, 69, 'CE230'),
(1451, 69, 'CE300'),
(1452, 69, 'Citan'),
(1453, 69, 'CL klasė'),
(1454, 69, 'CL180'),
(1455, 69, 'CL200'),
(1456, 69, 'CL220'),
(1457, 69, 'CL230'),
(1458, 69, 'CL420'),
(1459, 69, 'CL500'),
(1460, 69, 'CL55 AMG'),
(1461, 69, 'CL600'),
(1462, 69, 'CL63 AMG'),
(1463, 69, 'CL65 AMG'),
(1464, 69, 'CLA klasė'),
(1465, 69, 'CLA180'),
(1466, 69, 'CLA200'),
(1467, 69, 'CLA220'),
(1468, 69, 'CLA250'),
(1469, 69, 'CLA45 AMG'),
(1470, 69, 'CLC klasė'),
(1471, 69, 'CLC160'),
(1472, 69, 'CLC180'),
(1473, 69, 'CLC200'),
(1474, 69, 'CLC220'),
(1475, 69, 'CLC230'),
(1476, 69, 'CLC250'),
(1477, 69, 'CLC350'),
(1478, 69, 'CLK klasė'),
(1479, 69, 'CLK200'),
(1480, 69, 'CLK220'),
(1481, 69, 'CLK230'),
(1482, 69, 'CLK240'),
(1483, 69, 'CLK270'),
(1484, 69, 'CLK280'),
(1485, 69, 'CLK320'),
(1486, 69, 'CLK350'),
(1487, 69, 'CLK430'),
(1488, 69, 'CLK500'),
(1489, 69, 'CLK55 AMG'),
(1490, 69, 'CLK63 AMG'),
(1491, 69, 'CLS klasė'),
(1492, 69, 'CLS220'),
(1493, 69, 'CLS250'),
(1494, 69, 'CLS280'),
(1495, 69, 'CLS300'),
(1496, 69, 'CLS320'),
(1497, 69, 'CLS350'),
(1498, 69, 'CLS400'),
(1499, 69, 'CLS500'),
(1500, 69, 'CLS55 AMG'),
(1501, 69, 'CLS550'),
(1502, 69, 'CLS63 AMG'),
(1503, 69, 'E klasė'),
(1504, 69, 'E200'),
(1505, 69, 'E220'),
(1506, 69, 'E230'),
(1507, 69, 'E240'),
(1508, 69, 'E250'),
(1509, 69, 'E260'),
(1510, 69, 'E270'),
(1511, 69, 'E280'),
(1512, 69, 'E290'),
(1513, 69, 'E300'),
(1514, 69, 'E320'),
(1515, 69, 'E350'),
(1516, 69, 'E36 AMG'),
(1517, 69, 'E400'),
(1518, 69, 'E420'),
(1519, 69, 'E430'),
(1520, 69, 'E50 AMG'),
(1521, 69, 'E500'),
(1522, 69, 'E55'),
(1523, 69, 'E55 AMG'),
(1524, 69, 'E550'),
(1525, 69, 'E60 AMG'),
(1526, 69, 'E63 AMG'),
(1527, 69, 'G klasė'),
(1528, 69, 'G230'),
(1529, 69, 'G240'),
(1530, 69, 'G250'),
(1531, 69, 'G270'),
(1532, 69, 'G280'),
(1533, 69, 'G290'),
(1534, 69, 'G300'),
(1535, 69, 'G320'),
(1536, 69, 'G350'),
(1537, 69, 'G400'),
(1538, 69, 'G500'),
(1539, 69, 'G55 AMG'),
(1540, 69, 'G63 AMG'),
(1541, 69, 'G65 AMG'),
(1542, 69, 'GL klasė'),
(1543, 69, 'GL320'),
(1544, 69, 'GL350'),
(1545, 69, 'GL350 BlueTEC'),
(1546, 69, 'GL420'),
(1547, 69, 'GL450'),
(1548, 69, 'GL500'),
(1549, 69, 'GL550'),
(1550, 69, 'GL55 AMG'),
(1551, 69, 'GL63 AMG'),
(1552, 69, 'GLA klasė'),
(1553, 69, 'GLA180'),
(1554, 69, 'GLA200'),
(1555, 69, 'GLA220'),
(1556, 69, 'GLA250'),
(1557, 69, 'GLA45 AMG'),
(1558, 69, 'GLC Coupe klasė '),
(1559, 69, '-kita-'),
(1560, 69, 'GLC Coupe 220 '),
(1561, 69, 'GLC Coupe 250 '),
(1562, 69, 'GLC Coupe 300 '),
(1563, 69, 'GLC Coupe 350 '),
(1564, 69, 'GLC Coupe 43 AMG '),
(1565, 69, 'GLC klasė'),
(1566, 69, 'GLC220'),
(1567, 69, 'GLC250'),
(1568, 69, 'GLC300'),
(1569, 69, 'GLC350'),
(1570, 69, 'GLC43 AMG'),
(1571, 69, 'GLE Coupe klasė'),
(1572, 69, 'GLE Coupe 250'),
(1573, 69, 'GLE Coupe 350'),
(1574, 69, 'GLE Coupe 400'),
(1575, 69, 'GLE Coupe 450'),
(1576, 69, 'GLE Coupe 500'),
(1577, 69, 'GLE Coupe 63 AMG'),
(1578, 69, 'GLE klasė'),
(1579, 69, 'GLE250'),
(1580, 69, 'GLE350'),
(1581, 69, 'GLE400'),
(1582, 69, 'GLE450'),
(1583, 69, 'GLE500'),
(1584, 69, 'GLE63 AMG'),
(1585, 69, 'GLK klasė'),
(1586, 69, 'GLK200'),
(1587, 69, 'GLK220'),
(1588, 69, 'GLK250'),
(1589, 69, 'GLK280'),
(1590, 69, 'GLK300'),
(1591, 69, 'GLK320'),
(1592, 69, 'GLK350'),
(1593, 69, 'GLS klasė '),
(1594, 69, 'GLS350'),
(1595, 69, 'GLS500'),
(1596, 69, 'M klasė'),
(1597, 69, 'ML klasė'),
(1598, 69, 'ML230'),
(1599, 69, 'ML250'),
(1600, 69, 'ML270'),
(1601, 69, 'ML280'),
(1602, 69, 'ML300'),
(1603, 69, 'ML320'),
(1604, 69, 'ML350'),
(1605, 69, 'ML400'),
(1606, 69, 'ML420'),
(1607, 69, 'ML430'),
(1608, 69, 'ML450'),
(1609, 69, 'ML500'),
(1610, 69, 'ML53 AMG'),
(1611, 69, 'ML55 AMG'),
(1612, 69, 'ML63 AMG'),
(1613, 69, 'R klasė'),
(1614, 69, 'R280'),
(1615, 69, 'R300'),
(1616, 69, 'R320'),
(1617, 69, 'R350'),
(1618, 69, 'R500'),
(1619, 69, 'R63 AMG'),
(1620, 69, 'S klasė'),
(1621, 69, 'S250'),
(1622, 69, 'S260'),
(1623, 69, 'S280'),
(1624, 69, 'S300'),
(1625, 69, 'S320'),
(1626, 69, 'S350'),
(1627, 69, 'S400'),
(1628, 69, 'S420'),
(1629, 69, 'S430'),
(1630, 69, 'S450'),
(1631, 69, 'S500'),
(1632, 69, 'S55 AMG'),
(1633, 69, 'S550'),
(1634, 69, 'S560'),
(1635, 69, 'S600'),
(1636, 69, 'S63 AMG'),
(1637, 69, 'S65 AMG'),
(1638, 69, 'SL klasė'),
(1639, 69, 'SL280'),
(1640, 69, 'SL300'),
(1641, 69, 'SL320'),
(1642, 69, 'SL350'),
(1643, 69, 'SL380'),
(1644, 69, 'SL400'),
(1645, 69, 'SL420'),
(1646, 69, 'SL450'),
(1647, 69, 'SL500'),
(1648, 69, 'SL55 AMG'),
(1649, 69, 'SL560'),
(1650, 69, 'SL60 AMG'),
(1651, 69, 'SL600'),
(1652, 69, 'SL63 AMG'),
(1653, 69, 'SL65 AMG'),
(1654, 69, 'SL70 AMG'),
(1655, 69, 'SL73 AMG'),
(1656, 69, 'SLK klasė'),
(1657, 69, 'SLK200'),
(1658, 69, 'SLK230'),
(1659, 69, 'SLK250'),
(1660, 69, 'SLK260'),
(1661, 69, 'SLK280 '),
(1662, 69, 'SLK300'),
(1663, 69, 'SLK32 AMG'),
(1664, 69, 'SLK320'),
(1665, 69, 'SLK350'),
(1666, 69, 'SLK55 AMG'),
(1667, 69, 'SLR McLaren'),
(1668, 69, 'SLS AMG'),
(1669, 69, 'Sprinter'),
(1670, 69, 'T 1'),
(1671, 69, 'V klasė'),
(1672, 69, 'V200'),
(1673, 69, 'V220'),
(1674, 69, 'V230'),
(1675, 69, 'V250'),
(1676, 69, 'V280'),
(1677, 69, 'Vaneo'),
(1678, 69, 'Vario'),
(1679, 69, 'Viano'),
(1680, 69, 'Vito'),
(1681, 70, '-kita-'),
(1682, 70, 'Tiffany'),
(1683, 70, 'Capri'),
(1684, 70, 'Cougar'),
(1685, 70, 'Grand Marquis'),
(1686, 70, 'Marauder'),
(1687, 70, 'Milan'),
(1688, 70, 'Mountaineer'),
(1689, 70, 'Mystique'),
(1690, 70, 'Sable'),
(1691, 70, 'Topaz'),
(1692, 70, 'Tracer'),
(1693, 70, 'Villager'),
(1694, 71, '-kita-'),
(1695, 71, 'Express'),
(1696, 71, 'Maestro'),
(1697, 71, 'Metro'),
(1698, 71, 'MGA'),
(1699, 71, 'MGB'),
(1700, 71, 'MGF'),
(1701, 71, 'MGR V8'),
(1702, 71, 'Midget'),
(1703, 71, 'Montego'),
(1704, 71, 'TF'),
(1705, 71, 'X'),
(1706, 71, 'ZR'),
(1707, 71, 'ZS'),
(1708, 71, 'ZT'),
(1709, 72, '-kita-'),
(1710, 72, 'Mc 1 '),
(1711, 72, 'Mgo'),
(1712, 73, '-kita-'),
(1713, 73, '1000'),
(1714, 73, '1300'),
(1715, 73, 'Clubman'),
(1716, 73, 'Cooper'),
(1717, 73, 'Cooper S'),
(1718, 73, 'Countryman'),
(1719, 73, 'Mini'),
(1720, 73, 'One'),
(1721, 73, 'Paceman'),
(1722, 74, '-kita-'),
(1723, 74, '3000 GT'),
(1724, 74, 'ASX'),
(1725, 74, 'Canter'),
(1726, 74, 'Carisma'),
(1727, 74, 'Colt'),
(1728, 74, 'Cordia'),
(1729, 74, 'Delica'),
(1730, 74, 'Diamante'),
(1731, 74, 'Eclipse'),
(1732, 74, 'Endeavor'),
(1733, 74, 'FTO'),
(1734, 74, 'Galant'),
(1735, 74, 'Galloper'),
(1736, 74, 'Grandis'),
(1737, 74, 'GTO'),
(1738, 74, 'L200'),
(1739, 74, 'L300'),
(1740, 74, 'L400'),
(1741, 74, 'Lancer'),
(1742, 74, 'Lancer  Evolution'),
(1743, 74, 'MiEV'),
(1744, 74, 'Mirage'),
(1745, 74, 'Montero'),
(1746, 74, 'Outlander'),
(1747, 74, 'Pajero'),
(1748, 74, 'Pajero Pinin'),
(1749, 74, 'Pajero Sport'),
(1750, 74, 'Pick up'),
(1751, 74, 'Pinin'),
(1752, 74, 'Santamo'),
(1753, 74, 'Sapporo'),
(1754, 74, 'Shogun'),
(1755, 74, 'Sigma'),
(1756, 74, 'Space Gear'),
(1757, 74, 'Space Runner'),
(1758, 74, 'Space Star'),
(1759, 74, 'Space Wagon'),
(1760, 74, 'Starion'),
(1761, 75, '-kita-'),
(1762, 75, '4/4'),
(1763, 75, 'Aero 8'),
(1764, 75, 'Plus 4'),
(1765, 75, 'Plus 8'),
(1766, 75, 'Roadster'),
(1767, 76, '-kita-'),
(1768, 76, '407'),
(1769, 76, '423'),
(1770, 76, '2140'),
(1771, 76, '2141'),
(1772, 76, '401'),
(1773, 76, '403'),
(1774, 76, '408'),
(1775, 76, '412'),
(1776, 76, 'M 400'),
(1777, 76, 'M 402'),
(1778, 76, 'M 408'),
(1779, 76, 'M 412'),
(1780, 77, '-kita-'),
(1781, 77, '100 NX'),
(1782, 77, '200 SX'),
(1783, 77, '240 SX'),
(1784, 77, '280 ZX'),
(1785, 77, '300 ZX'),
(1786, 77, '350Z'),
(1787, 77, '370Z'),
(1788, 77, 'Almera'),
(1789, 77, 'Almera Tino'),
(1790, 77, 'Altima'),
(1791, 77, 'Armada'),
(1792, 77, 'Bluebird'),
(1793, 77, 'Cabstar'),
(1794, 77, 'Cargo'),
(1795, 77, 'Cherry'),
(1796, 77, 'Cima'),
(1797, 77, 'Cube'),
(1798, 77, 'Evalia'),
(1799, 77, 'Frontier'),
(1800, 77, 'GT R'),
(1801, 77, 'Interstar'),
(1802, 77, 'Juke'),
(1803, 77, 'King Cab'),
(1804, 77, 'Kubistar'),
(1805, 77, 'Laurel'),
(1806, 77, 'Leaf'),
(1807, 77, 'Liberty'),
(1808, 77, 'Maxima'),
(1809, 77, 'Micra'),
(1810, 77, 'Murano'),
(1811, 77, 'Navara'),
(1812, 77, 'Note'),
(1813, 77, 'NP300'),
(1814, 77, 'NV200'),
(1815, 77, 'NV300'),
(1816, 77, 'NV400'),
(1817, 77, 'Pathfinder'),
(1818, 77, 'Patrol'),
(1819, 77, 'Pick Up'),
(1820, 77, 'Pixo'),
(1821, 77, 'Prairie'),
(1822, 77, 'President'),
(1823, 77, 'Primastar'),
(1824, 77, 'Primera'),
(1825, 77, 'Pulsar'),
(1826, 77, 'Qashqai'),
(1827, 77, 'Qashqai+2'),
(1828, 77, 'Quest'),
(1829, 77, 'Rogue'),
(1830, 77, 'Rougue'),
(1831, 77, 'Sentra'),
(1832, 77, 'Serena'),
(1833, 77, 'Silvia'),
(1834, 77, 'Skyline'),
(1835, 77, 'Sunny'),
(1836, 77, 'Terrano'),
(1837, 77, 'Tiida'),
(1838, 77, 'Titan'),
(1839, 77, 'Trade'),
(1840, 77, 'Urvan'),
(1841, 77, 'Vanette'),
(1842, 77, 'Versa'),
(1843, 77, 'Wingroad'),
(1844, 77, 'X Terra'),
(1845, 77, 'X Trail'),
(1846, 78, '-kita-'),
(1847, 78, '600R'),
(1848, 79, '-kita-'),
(1849, 79, '522'),
(1850, 80, '-kita-'),
(1851, 80, 'Achieva'),
(1852, 80, 'Alero'),
(1853, 80, 'Aurora'),
(1854, 80, 'Bravada'),
(1855, 80, 'Custom Cruiser'),
(1856, 80, 'Cutlass'),
(1857, 80, 'Delta 88'),
(1858, 80, 'Eighty Eight'),
(1859, 80, 'Intrigue'),
(1860, 80, 'Silhouete'),
(1861, 80, 'Silhouette'),
(1862, 80, 'Super 88'),
(1863, 80, 'Toronado'),
(1864, 81, '-kita-'),
(1865, 81, 'Adam'),
(1866, 81, 'Agila'),
(1867, 81, 'Ampera'),
(1868, 81, 'Antara'),
(1869, 81, 'Arena'),
(1870, 81, 'Ascona'),
(1871, 81, 'Astra'),
(1872, 81, 'Calibra'),
(1873, 81, 'Campo'),
(1874, 81, 'Cascada'),
(1875, 81, 'Combo'),
(1876, 81, 'Corsa'),
(1877, 81, 'Diplomat'),
(1878, 81, 'Frontera'),
(1879, 81, 'GT'),
(1880, 81, 'Insignia'),
(1881, 81, 'Kadett'),
(1882, 81, 'Karl'),
(1883, 81, 'Manta'),
(1884, 81, 'Meriva'),
(1885, 81, 'Mokka'),
(1886, 81, 'Mokka X'),
(1887, 81, 'Monterey'),
(1888, 81, 'Monza'),
(1889, 81, 'Movano'),
(1890, 81, 'Nova'),
(1891, 81, 'Omega'),
(1892, 81, 'Rekord'),
(1893, 81, 'Senator'),
(1894, 81, 'Signum'),
(1895, 81, 'Sintra'),
(1896, 81, 'Speedster'),
(1897, 81, 'Tigra'),
(1898, 81, 'Vectra'),
(1899, 81, 'Vivaro'),
(1900, 81, 'Zafira'),
(1901, 81, 'Zafira tourer'),
(1902, 82, '-kita-'),
(1903, 82, '110'),
(1904, 82, '120'),
(1905, 82, '180'),
(1906, 82, '200'),
(1907, 82, '300'),
(1908, 82, 'Caribbean'),
(1909, 82, 'Cavalier'),
(1910, 82, 'Clipper'),
(1911, 82, 'Executive'),
(1912, 82, 'Hawk'),
(1913, 82, 'Patrician'),
(1914, 82, 'Station Sedan'),
(1915, 82, 'Super Eight'),
(1916, 83, '-kita-'),
(1917, 83, '1007'),
(1918, 83, '104'),
(1919, 83, '106'),
(1920, 83, '107'),
(1921, 83, '108'),
(1922, 83, '2008'),
(1923, 83, '204'),
(1924, 83, '205'),
(1925, 83, '206'),
(1926, 83, '206+'),
(1927, 83, '207'),
(1928, 83, '208'),
(1929, 83, '3008'),
(1930, 83, '301'),
(1931, 83, '304'),
(1932, 83, '305'),
(1933, 83, '306'),
(1934, 83, '307'),
(1935, 83, '308'),
(1936, 83, '309'),
(1937, 83, '4007'),
(1938, 83, '4008'),
(1939, 83, '404'),
(1940, 83, '405'),
(1941, 83, '406'),
(1942, 83, '407'),
(1943, 83, '5008'),
(1944, 83, '504'),
(1945, 83, '505'),
(1946, 83, '508'),
(1947, 83, '508 RXH'),
(1948, 83, '604'),
(1949, 83, '605'),
(1950, 83, '607'),
(1951, 83, '806'),
(1952, 83, '807'),
(1953, 83, 'Bipper'),
(1954, 83, 'Boxer'),
(1955, 83, 'Expert'),
(1956, 83, 'iOn'),
(1957, 83, 'J5'),
(1958, 83, 'Partner'),
(1959, 83, 'RCZ'),
(1960, 83, 'Traveller'),
(1961, 83, 'Vivacity'),
(1962, 84, '-kita-'),
(1963, 84, 'Breeze'),
(1964, 84, 'Grand Voyager'),
(1965, 84, 'Neon'),
(1966, 84, 'Prowler'),
(1967, 84, 'Voyager'),
(1968, 85, '-kita-'),
(1969, 85, '6000'),
(1970, 85, 'Aztek'),
(1971, 85, 'Bonneville'),
(1972, 85, 'Catalina'),
(1973, 85, 'Fiero'),
(1974, 85, 'Firebird'),
(1975, 85, 'G6'),
(1976, 85, 'G8'),
(1977, 85, 'Grand Am'),
(1978, 85, 'Grand Prix'),
(1979, 85, 'GTO'),
(1980, 85, 'Montana'),
(1981, 85, 'Solstice'),
(1982, 85, 'Sunbird'),
(1983, 85, 'Sunfire'),
(1984, 85, 'Targa'),
(1985, 85, 'Trans Am'),
(1986, 85, 'Trans Sport'),
(1987, 85, 'Vibe'),
(1988, 86, '-kita-'),
(1989, 86, '356'),
(1990, 86, '911'),
(1991, 86, '912'),
(1992, 86, '914'),
(1993, 86, '924'),
(1994, 86, '928'),
(1995, 86, '944'),
(1996, 86, '959'),
(1997, 86, '968'),
(1998, 86, 'Boxster'),
(1999, 86, 'Carrera GT'),
(2000, 86, 'Cayenne'),
(2001, 86, 'Cayman'),
(2002, 86, 'Macan'),
(2003, 86, 'Panamera'),
(2004, 87, '-kita-'),
(2005, 87, '313'),
(2006, 87, '315'),
(2007, 87, '416'),
(2008, 87, 'Gen 2'),
(2009, 87, 'Persona'),
(2010, 87, 'Satria'),
(2011, 88, '-kita-'),
(2012, 88, '11'),
(2013, 88, '19'),
(2014, 88, '21'),
(2015, 88, '25'),
(2016, 88, '4'),
(2017, 88, '5'),
(2018, 88, '9'),
(2019, 88, 'Avantime'),
(2020, 88, 'Captur'),
(2021, 88, 'Clio'),
(2022, 88, 'Espace'),
(2023, 88, 'Express'),
(2024, 88, 'Fluence'),
(2025, 88, 'Fuego'),
(2026, 88, 'Grand Espace'),
(2027, 88, 'Grand Modus'),
(2028, 88, 'Grand Scenic'),
(2029, 88, 'Kadjar'),
(2030, 88, 'Kangoo'),
(2031, 88, 'Koleos'),
(2032, 88, 'Laguna'),
(2033, 88, 'Latitude'),
(2034, 88, 'Logan'),
(2035, 88, 'Magnum'),
(2036, 88, 'Mascott'),
(2037, 88, 'Master'),
(2038, 88, 'Megane'),
(2039, 88, 'Modus'),
(2040, 88, 'Nevada'),
(2041, 88, 'Rapid'),
(2042, 88, 'Safrane'),
(2043, 88, 'Scenic'),
(2044, 88, 'Spacetourer'),
(2045, 88, 'Sport Spider'),
(2046, 88, 'Super 5'),
(2047, 88, 'Symbol'),
(2048, 88, 'Talisman'),
(2049, 88, 'Thalia'),
(2050, 88, 'Trafic'),
(2051, 88, 'Twingo'),
(2052, 88, 'Twizy'),
(2053, 88, 'Vel Satis'),
(2054, 88, 'Wind'),
(2055, 88, 'Zoe'),
(2056, 89, '-kita-'),
(2057, 89, 'Corniche'),
(2058, 89, 'Flying Spur'),
(2059, 89, 'Ghost'),
(2060, 89, 'Park Ward'),
(2061, 89, 'Phantom'),
(2062, 89, 'Silver'),
(2063, 90, '-kita-'),
(2064, 91, '-kita-'),
(2065, 91, '25'),
(2066, 91, '45'),
(2067, 91, '75'),
(2068, 91, '100'),
(2069, 91, '200 serija'),
(2070, 91, '200'),
(2071, 91, '211'),
(2072, 91, '213'),
(2073, 91, '214'),
(2074, 91, '216'),
(2075, 91, '218'),
(2076, 91, '220'),
(2077, 91, '400 serija'),
(2078, 91, '400'),
(2079, 91, '414'),
(2080, 91, '416'),
(2081, 91, '418'),
(2082, 91, '420'),
(2083, 91, '600 serija'),
(2084, 91, '600'),
(2085, 91, '618'),
(2086, 91, '620'),
(2087, 91, '623'),
(2088, 91, '800 serija'),
(2089, 91, '800'),
(2090, 91, '820'),
(2091, 91, '825'),
(2092, 91, '827'),
(2093, 91, 'Discovery'),
(2094, 91, 'Maestro'),
(2095, 91, 'Metro'),
(2096, 91, 'MGF'),
(2097, 91, 'Mini'),
(2098, 91, 'Montego'),
(2099, 91, 'Streetwise'),
(2100, 92, '-kita-'),
(2101, 92, '9 2X'),
(2102, 92, '9 3'),
(2103, 92, '9 4X'),
(2104, 92, '9 5'),
(2105, 92, '9 7X'),
(2106, 92, '90'),
(2107, 92, '900'),
(2108, 92, '9000'),
(2109, 92, '92'),
(2110, 92, '96'),
(2111, 92, '97'),
(2112, 92, '99'),
(2113, 93, '-kita-'),
(2114, 93, '300'),
(2115, 93, '350'),
(2116, 93, 'PS 10'),
(2117, 94, '-kita-'),
(2118, 94, 'Aura'),
(2119, 94, 'ION'),
(2120, 94, 'LS'),
(2121, 94, 'LW'),
(2122, 94, 'Relay'),
(2123, 94, 'SC'),
(2124, 94, 'Sky'),
(2125, 94, 'SL'),
(2126, 94, 'SW'),
(2127, 94, 'VUE'),
(2128, 95, '-kita-'),
(2129, 95, 'iM'),
(2130, 95, 'IQ'),
(2131, 95, 'TC'),
(2132, 95, 'XA'),
(2133, 95, 'XB'),
(2134, 95, 'XD'),
(2135, 96, '-kita-'),
(2136, 96, 'Alhambra'),
(2137, 96, 'Altea'),
(2138, 96, 'Altea XL'),
(2139, 96, 'Arosa'),
(2140, 96, 'Ateca'),
(2141, 96, 'Cordoba'),
(2142, 96, 'Exeo'),
(2143, 96, 'Ibiza'),
(2144, 96, 'Inca'),
(2145, 96, 'Leon'),
(2146, 96, 'Malaga'),
(2147, 96, 'Marbella'),
(2148, 96, 'Mii'),
(2149, 96, 'Terra'),
(2150, 96, 'Toledo'),
(2151, 97, '-kita-'),
(2152, 97, 'Extrem 500'),
(2153, 97, 'F16'),
(2154, 97, 'Fun Family'),
(2155, 98, '-kita-'),
(2156, 98, 'CEO'),
(2157, 98, 'Sceo'),
(2158, 99, '-kita-'),
(2159, 99, '105'),
(2160, 99, '120'),
(2161, 99, '130'),
(2162, 99, '135'),
(2163, 99, 'Citigo'),
(2164, 99, 'Fabia'),
(2165, 99, 'Favorit'),
(2166, 99, 'Felicia'),
(2167, 99, 'Forman'),
(2168, 99, 'Kodiaq'),
(2169, 99, 'Octavia'),
(2170, 99, 'Pick Up'),
(2171, 99, 'Praktik'),
(2172, 99, 'Rapid'),
(2173, 99, 'Roomster'),
(2174, 99, 'Superb'),
(2175, 99, 'Yeti'),
(2176, 100, '-kita-'),
(2177, 100, 'City'),
(2178, 100, 'Coupe'),
(2179, 100, 'Crossblade'),
(2180, 100, 'Forfour'),
(2181, 100, 'Fortwo'),
(2182, 100, 'Fortwo Coupe'),
(2183, 100, 'MCC'),
(2184, 100, 'Roadster'),
(2185, 101, '-kita-'),
(2186, 101, 'Roadster'),
(2187, 101, 'Sherwood'),
(2188, 101, 'Starcraft'),
(2189, 101, 'Treka'),
(2190, 102, '-kita-'),
(2191, 103, '-kita-'),
(2192, 103, 'Actyon'),
(2193, 103, 'Actyon Sports'),
(2194, 103, 'Chairman'),
(2195, 103, 'Family'),
(2196, 103, 'Istana'),
(2197, 103, 'Kallista'),
(2198, 103, 'Korando'),
(2199, 103, 'Kyron'),
(2200, 103, 'Musso'),
(2201, 103, 'Rexton'),
(2202, 103, 'Rodius'),
(2203, 103, 'Tivoli'),
(2204, 104, '-kita-'),
(2205, 104, 'Avanti'),
(2206, 104, 'Big Six'),
(2207, 104, 'Champion'),
(2208, 104, 'Commander'),
(2209, 104, 'Conestoga'),
(2210, 104, 'Cruiser'),
(2211, 104, 'Daytona'),
(2212, 104, 'Desoto'),
(2213, 104, 'Dictator'),
(2214, 104, 'Electric car'),
(2215, 104, 'Flight Hawk'),
(2216, 104, 'Golden Hawk'),
(2217, 104, 'Gran Turismo Hawk'),
(2218, 104, 'Land Cruiser'),
(2219, 104, 'Lark'),
(2220, 104, 'Light Four'),
(2221, 104, 'Light Six'),
(2222, 104, 'Power Hawk'),
(2223, 104, 'President'),
(2224, 104, 'Scotsman'),
(2225, 104, 'Silver Hawk'),
(2226, 104, 'Sky Hawk'),
(2227, 104, 'Special Six'),
(2228, 104, 'Speedster'),
(2229, 104, 'Standard Six'),
(2230, 104, 'Starlight'),
(2231, 104, 'Wagonaire'),
(2232, 105, '-kita-'),
(2233, 105, 'Baja'),
(2234, 105, 'BRZ'),
(2235, 105, 'Forester'),
(2236, 105, 'Impreza'),
(2237, 105, 'Impreza  WRX'),
(2238, 105, 'Justy'),
(2239, 105, 'Legacy'),
(2240, 105, 'Leone'),
(2241, 105, 'Levorg'),
(2242, 105, 'Libero'),
(2243, 105, 'M 80'),
(2244, 105, 'Outback'),
(2245, 105, 'R1'),
(2246, 105, 'SVX'),
(2247, 105, 'Trezia'),
(2248, 105, 'Tribeca'),
(2249, 105, 'Vivio'),
(2250, 105, 'XT Coupe'),
(2251, 105, 'XV'),
(2252, 106, '-kita-'),
(2253, 106, 'Aerio'),
(2254, 106, 'Alto'),
(2255, 106, 'Baleno'),
(2256, 106, 'Cappuccino'),
(2257, 106, 'Carry'),
(2258, 106, 'Celerio '),
(2259, 106, 'Cultis Wagon'),
(2260, 106, 'Equator'),
(2261, 106, 'Esteem'),
(2262, 106, 'Every Landy'),
(2263, 106, 'Forenza'),
(2264, 106, 'Grand Vitara'),
(2265, 106, 'Ignis'),
(2266, 106, 'Jimny'),
(2267, 106, 'Kei'),
(2268, 106, 'Kizashi'),
(2269, 106, 'Liana'),
(2270, 106, 'LJ'),
(2271, 106, 'Reno'),
(2272, 106, 'Samurai'),
(2273, 106, 'SJ'),
(2274, 106, 'Splash'),
(2275, 106, 'Super Carry'),
(2276, 106, 'Swift'),
(2277, 106, 'SX4'),
(2278, 106, 'SX4 S Cross'),
(2279, 106, 'Twin'),
(2280, 106, 'Verona'),
(2281, 106, 'Vitara'),
(2282, 106, 'Wagon R+'),
(2283, 106, 'X 90'),
(2284, 106, 'XL7'),
(2285, 107, '-kita-'),
(2286, 107, 'Andere'),
(2287, 107, 'Horizon'),
(2288, 107, 'Samba'),
(2289, 108, '-kita-'),
(2290, 108, 'Prancer'),
(2291, 109, '-kita-'),
(2292, 109, 'Indica'),
(2293, 109, 'Indigo'),
(2294, 109, 'Nano'),
(2295, 109, 'Safari'),
(2296, 109, 'Sumo'),
(2297, 109, 'Telcoline'),
(2298, 109, 'Telcosport'),
(2299, 109, 'Xenon'),
(2300, 110, '-kita-'),
(2301, 110, '603'),
(2302, 110, '613'),
(2303, 110, '700'),
(2304, 110, '77'),
(2305, 110, '80'),
(2306, 110, '87'),
(2307, 111, '-kita-'),
(2308, 112, '-kita-'),
(2309, 112, 'Andere'),
(2310, 112, 'Model S'),
(2311, 112, 'Model X'),
(2312, 112, 'Roadster'),
(2313, 113, '-kita-'),
(2314, 113, 'City'),
(2315, 114, '-kita-'),
(2316, 114, '4Runner'),
(2317, 114, 'Allion'),
(2318, 114, 'Alphard'),
(2319, 114, 'Auris'),
(2320, 114, 'Avalon'),
(2321, 114, 'Avensis'),
(2322, 114, 'Avensis Verso'),
(2323, 114, 'Aygo'),
(2324, 114, 'C HR'),
(2325, 114, 'Camry'),
(2326, 114, 'Carina'),
(2327, 114, 'Celica'),
(2328, 114, 'Chaser'),
(2329, 114, 'Corolla'),
(2330, 114, 'Corolla Verso'),
(2331, 114, 'Cressida'),
(2332, 114, 'Cresta'),
(2333, 114, 'Crown'),
(2334, 114, 'Dyna'),
(2335, 114, 'Echo'),
(2336, 114, 'Estima'),
(2337, 114, 'FJ Cruiser'),
(2338, 114, 'GT 86'),
(2339, 114, 'Hiace'),
(2340, 114, 'Highlander'),
(2341, 114, 'Hilux'),
(2342, 114, 'Ipsum'),
(2343, 114, 'iQ'),
(2344, 114, 'Kluger V'),
(2345, 114, 'Land Cruiser'),
(2346, 114, 'Liteace'),
(2347, 114, 'Matrix'),
(2348, 114, 'Mega Cruiser'),
(2349, 114, 'MR 2'),
(2350, 114, 'Nadia'),
(2351, 114, 'Paseo'),
(2352, 114, 'Picnic'),
(2353, 114, 'Previa'),
(2354, 114, 'Prius'),
(2355, 114, 'Prius C'),
(2356, 114, 'Prius+'),
(2357, 114, 'ProAce'),
(2358, 114, 'RAV4'),
(2359, 114, 'Rush'),
(2360, 114, 'Sequoia'),
(2361, 114, 'Sienna'),
(2362, 114, 'Soarer'),
(2363, 114, 'Solara'),
(2364, 114, 'Starlet'),
(2365, 114, 'Supra'),
(2366, 114, 'Tacoma'),
(2367, 114, 'Tercel'),
(2368, 114, 'Tundra'),
(2369, 114, 'Urban Cruiser'),
(2370, 114, 'Venza'),
(2371, 114, 'Verso'),
(2372, 114, 'Verso S'),
(2373, 114, 'Yaris'),
(2374, 114, 'Yaris Verso'),
(2375, 115, '-kita-'),
(2376, 115, '601'),
(2377, 116, '-kita-'),
(2378, 116, 'Dolomite'),
(2379, 116, 'Moss'),
(2380, 116, 'Spitfire'),
(2381, 116, 'TR6'),
(2382, 117, '-kita-'),
(2383, 117, '2103'),
(2384, 117, '2206'),
(2385, 117, '3151'),
(2386, 117, '3303'),
(2387, 117, '3741'),
(2388, 117, '3909'),
(2389, 117, '3962'),
(2390, 117, '452'),
(2391, 117, '469'),
(2392, 117, 'Hunter'),
(2393, 117, 'Patriot'),
(2394, 117, 'Pickup'),
(2395, 118, '-kita-'),
(2396, 118, 'Astra'),
(2397, 118, 'Insignia'),
(2398, 118, 'Vectra'),
(2399, 119, '-kita-'),
(2400, 119, '210'),
(2401, 119, '260'),
(2402, 119, '300'),
(2403, 119, '400'),
(2404, 120, '-kita-'),
(2405, 120, 'Amarok'),
(2406, 120, 'Beetle'),
(2407, 120, 'Bora'),
(2408, 120, 'Buggy '),
(2409, 120, 'Caddy'),
(2410, 120, 'California'),
(2411, 120, 'Caravelle'),
(2412, 120, 'Corrado'),
(2413, 120, 'Crafter'),
(2414, 120, 'Derby'),
(2415, 120, 'Eos'),
(2416, 120, 'Fox'),
(2417, 120, 'Golf'),
(2418, 120, 'Golf Plus'),
(2419, 120, 'Golf Sportsvan'),
(2420, 120, 'Golf SportWagen'),
(2421, 120, 'Iltia'),
(2422, 120, 'Jetta'),
(2423, 120, 'Kaefer'),
(2424, 120, 'Karmann Ghia'),
(2425, 120, 'LT'),
(2426, 120, 'Lupo'),
(2427, 120, 'Multivan'),
(2428, 120, 'Passat'),
(2429, 120, 'Passat Alltrack'),
(2430, 120, 'Passat CC'),
(2431, 120, 'Phaeton'),
(2432, 120, 'Polo'),
(2433, 120, 'Rabbit'),
(2434, 120, 'Routan'),
(2435, 120, 'Santana'),
(2436, 120, 'Scirocco'),
(2437, 120, 'Sharan'),
(2438, 120, 'Taro'),
(2439, 120, 'Tiguan'),
(2440, 120, 'Touareg'),
(2441, 120, 'Touran'),
(2442, 120, 'Transporter'),
(2443, 120, 'Up'),
(2444, 120, 'Vento'),
(2445, 121, '-kita-'),
(2446, 121, '240'),
(2447, 121, '244'),
(2448, 121, '245'),
(2449, 121, '262'),
(2450, 121, '264'),
(2451, 121, '340'),
(2452, 121, '360'),
(2453, 121, '440'),
(2454, 121, '460'),
(2455, 121, '480'),
(2456, 121, '740'),
(2457, 121, '744'),
(2458, 121, '745'),
(2459, 121, '760'),
(2460, 121, '780'),
(2461, 121, '850'),
(2462, 121, '855'),
(2463, 121, '940'),
(2464, 121, '944'),
(2465, 121, '945'),
(2466, 121, '960'),
(2467, 121, '965'),
(2468, 121, 'Amazon'),
(2469, 121, 'C30'),
(2470, 121, 'C70'),
(2471, 121, 'Polar'),
(2472, 121, 'S40'),
(2473, 121, 'S60'),
(2474, 121, 'S70'),
(2475, 121, 'S80'),
(2476, 121, 'S90'),
(2477, 121, 'V40'),
(2478, 121, 'V40 Cross Country'),
(2479, 121, 'V50'),
(2480, 121, 'V60'),
(2481, 121, 'V60 Cross Country '),
(2482, 121, 'V70'),
(2483, 121, 'V90'),
(2484, 121, 'XC60'),
(2485, 121, 'XC70'),
(2486, 121, 'XC90'),
(2487, 122, '-kita-'),
(2488, 122, 'W 25K'),
(2489, 123, '-kita-'),
(2490, 123, '311'),
(2491, 123, '353'),
(2492, 124, '-kita-'),
(2493, 124, '965'),
(2494, 124, '966'),
(2495, 124, '968'),
(2496, 124, '968A'),
(2497, 124, '968M'),
(2498, 124, 'Tavrija');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `provider`
--

DROP TABLE IF EXISTS `provider`;
CREATE TABLE IF NOT EXISTS `provider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_92C4739C5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `provider`
--

INSERT INTO `provider` (`id`, `name`) VALUES
(3, 'Alio.lt'),
(2, 'Autogidas.lt'),
(1, 'Autoplius.lt');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_body_types`
--

DROP TABLE IF EXISTS `searches_body_types`;
CREATE TABLE IF NOT EXISTS `searches_body_types` (
  `vehicle_search_id` int(11) NOT NULL,
  `body_type_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`body_type_id`),
  KEY `IDX_F0FE85D092B825FB` (`vehicle_search_id`),
  KEY `IDX_F0FE85D02CBA3505` (`body_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_cities`
--

DROP TABLE IF EXISTS `searches_cities`;
CREATE TABLE IF NOT EXISTS `searches_cities` (
  `vehicle_search_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`city_id`),
  KEY `IDX_51B7217592B825FB` (`vehicle_search_id`),
  KEY `IDX_51B721758BAC62AF` (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_climate_controls`
--

DROP TABLE IF EXISTS `searches_climate_controls`;
CREATE TABLE IF NOT EXISTS `searches_climate_controls` (
  `vehicle_search_id` int(11) NOT NULL,
  `climate_control_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`climate_control_id`),
  KEY `IDX_325029E492B825FB` (`vehicle_search_id`),
  KEY `IDX_325029E437BDB459` (`climate_control_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_colors`
--

DROP TABLE IF EXISTS `searches_colors`;
CREATE TABLE IF NOT EXISTS `searches_colors` (
  `vehicle_search_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`color_id`),
  KEY `IDX_4A54538192B825FB` (`vehicle_search_id`),
  KEY `IDX_4A5453817ADA1FB5` (`color_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_defects`
--

DROP TABLE IF EXISTS `searches_defects`;
CREATE TABLE IF NOT EXISTS `searches_defects` (
  `vehicle_search_id` int(11) NOT NULL,
  `defects_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`defects_id`),
  KEY `IDX_926F924392B825FB` (`vehicle_search_id`),
  KEY `IDX_926F924380C0EA42` (`defects_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_first_countries`
--

DROP TABLE IF EXISTS `searches_first_countries`;
CREATE TABLE IF NOT EXISTS `searches_first_countries` (
  `vehicle_search_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`country_id`),
  KEY `IDX_BFDA391D92B825FB` (`vehicle_search_id`),
  KEY `IDX_BFDA391DF92F3E70` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_fuel_types`
--

DROP TABLE IF EXISTS `searches_fuel_types`;
CREATE TABLE IF NOT EXISTS `searches_fuel_types` (
  `vehicle_search_id` int(11) NOT NULL,
  `fuel_type_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`fuel_type_id`),
  KEY `IDX_39B75EB292B825FB` (`vehicle_search_id`),
  KEY `IDX_39B75EB26A70FE35` (`fuel_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_models`
--

DROP TABLE IF EXISTS `searches_models`;
CREATE TABLE IF NOT EXISTS `searches_models` (
  `vehicle_search_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`model_id`),
  KEY `IDX_6C3CA01792B825FB` (`vehicle_search_id`),
  KEY `IDX_6C3CA0177975B7E7` (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_providers`
--

DROP TABLE IF EXISTS `searches_providers`;
CREATE TABLE IF NOT EXISTS `searches_providers` (
  `vehicle_search_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`provider_id`),
  KEY `IDX_C503DB9992B825FB` (`vehicle_search_id`),
  KEY `IDX_C503DB99A53A8AA` (`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `searches_transmissions`
--

DROP TABLE IF EXISTS `searches_transmissions`;
CREATE TABLE IF NOT EXISTS `searches_transmissions` (
  `vehicle_search_id` int(11) NOT NULL,
  `transmission_id` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_search_id`,`transmission_id`),
  KEY `IDX_1BCF76BD92B825FB` (`vehicle_search_id`),
  KEY `IDX_1BCF76BD78D28519` (`transmission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `transmission`
--

DROP TABLE IF EXISTS `transmission`;
CREATE TABLE IF NOT EXISTS `transmission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_7F87199F5E237E06` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `transmission`
--

INSERT INTO `transmission` (`id`, `name`) VALUES
(2, 'Galiniai'),
(1, 'Priekiniai'),
(3, 'Visi varantys (4х4)');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `users_vehicles`
--

DROP TABLE IF EXISTS `users_vehicles`;
CREATE TABLE IF NOT EXISTS `users_vehicles` (
  `user_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`vehicle_id`),
  KEY `IDX_648F4220A76ED395` (`user_id`),
  KEY `IDX_648F4220545317D1` (`vehicle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE IF NOT EXISTS `vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` int(11) DEFAULT NULL,
  `brand` int(11) DEFAULT NULL,
  `model` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `body_type` int(11) DEFAULT NULL,
  `fuel_type` int(11) DEFAULT NULL,
  `transmission` int(11) DEFAULT NULL,
  `climate_control` int(11) DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `defects` int(11) DEFAULT NULL,
  `first_country` int(11) DEFAULT NULL,
  `provider_id` int(11) NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `engine_size` int(11) DEFAULT NULL,
  `power` int(11) DEFAULT NULL,
  `doors_number` int(11) DEFAULT NULL,
  `seats_number` int(11) DEFAULT NULL,
  `drive_type` int(11) DEFAULT NULL,
  `steering_wheel` int(11) DEFAULT NULL,
  `wheels_diameter` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `mileage` int(11) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `next_check_year` int(11) DEFAULT NULL,
  `gears_number` int(11) DEFAULT NULL,
  `last_ad_update` datetime DEFAULT NULL,
  `last_check` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1B80E48692C4739C` (`provider`),
  KEY `IDX_1B80E4861C52F958` (`brand`),
  KEY `IDX_1B80E486D79572D9` (`model`),
  KEY `IDX_1B80E4865373C966` (`country`),
  KEY `IDX_1B80E4862D5B0234` (`city`),
  KEY `IDX_1B80E486D95AEB4B` (`body_type`),
  KEY `IDX_1B80E4869CA10F38` (`fuel_type`),
  KEY `IDX_1B80E4867F87199F` (`transmission`),
  KEY `IDX_1B80E486999E3587` (`climate_control`),
  KEY `IDX_1B80E486665648E9` (`color`),
  KEY `IDX_1B80E48668E845B0` (`defects`),
  KEY `IDX_1B80E48640FFA59A` (`first_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `vehicle_search`
--

DROP TABLE IF EXISTS `vehicle_search`;
CREATE TABLE IF NOT EXISTS `vehicle_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) DEFAULT NULL,
  `brand` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `pinned` int(11) DEFAULT NULL,
  `price_from` int(11) DEFAULT NULL,
  `price_to` int(11) DEFAULT NULL,
  `year_from` int(11) DEFAULT NULL,
  `year_to` int(11) DEFAULT NULL,
  `engine_size_to` int(11) DEFAULT NULL,
  `engine_size_from` int(11) DEFAULT NULL,
  `power_from` int(11) DEFAULT NULL,
  `power_to` int(11) DEFAULT NULL,
  `doors_number` int(11) DEFAULT NULL,
  `seats_number` int(11) DEFAULT NULL,
  `drive_type` int(11) DEFAULT NULL,
  `steering_wheel` int(11) DEFAULT NULL,
  `wheels_diameter` int(11) DEFAULT NULL,
  `mileage_from` int(11) DEFAULT NULL,
  `mileage_to` int(11) DEFAULT NULL,
  `next_check_year` int(11) DEFAULT NULL,
  `gears_number` int(11) DEFAULT NULL,
  `last_ad_update` int(11) DEFAULT NULL,
  `sort_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1D2EDA748D93D649` (`user`),
  KEY `IDX_1D2EDA741C52F958` (`brand`),
  KEY `IDX_1D2EDA745373C966` (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Apribojimai eksportuotom lentelėm
--

--
-- Apribojimai lentelei `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `FK_2D5B02345373C966` FOREIGN KEY (`country`) REFERENCES `country` (`id`);

--
-- Apribojimai lentelei `model`
--
ALTER TABLE `model`
  ADD CONSTRAINT `FK_D79572D91C52F958` FOREIGN KEY (`brand`) REFERENCES `brand` (`id`);

--
-- Apribojimai lentelei `searches_body_types`
--
ALTER TABLE `searches_body_types`
  ADD CONSTRAINT `FK_F0FE85D02CBA3505` FOREIGN KEY (`body_type_id`) REFERENCES `body_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_F0FE85D092B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_cities`
--
ALTER TABLE `searches_cities`
  ADD CONSTRAINT `FK_51B721758BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_51B7217592B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_climate_controls`
--
ALTER TABLE `searches_climate_controls`
  ADD CONSTRAINT `FK_325029E437BDB459` FOREIGN KEY (`climate_control_id`) REFERENCES `climate_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_325029E492B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_colors`
--
ALTER TABLE `searches_colors`
  ADD CONSTRAINT `FK_4A5453817ADA1FB5` FOREIGN KEY (`color_id`) REFERENCES `color` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_4A54538192B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_defects`
--
ALTER TABLE `searches_defects`
  ADD CONSTRAINT `FK_926F924380C0EA42` FOREIGN KEY (`defects_id`) REFERENCES `defects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_926F924392B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_first_countries`
--
ALTER TABLE `searches_first_countries`
  ADD CONSTRAINT `FK_BFDA391D92B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_BFDA391DF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_fuel_types`
--
ALTER TABLE `searches_fuel_types`
  ADD CONSTRAINT `FK_39B75EB26A70FE35` FOREIGN KEY (`fuel_type_id`) REFERENCES `fuel_type` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_39B75EB292B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_models`
--
ALTER TABLE `searches_models`
  ADD CONSTRAINT `FK_6C3CA0177975B7E7` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_6C3CA01792B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_providers`
--
ALTER TABLE `searches_providers`
  ADD CONSTRAINT `FK_C503DB9992B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_C503DB99A53A8AA` FOREIGN KEY (`provider_id`) REFERENCES `provider` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `searches_transmissions`
--
ALTER TABLE `searches_transmissions`
  ADD CONSTRAINT `FK_1BCF76BD78D28519` FOREIGN KEY (`transmission_id`) REFERENCES `transmission` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_1BCF76BD92B825FB` FOREIGN KEY (`vehicle_search_id`) REFERENCES `vehicle_search` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `users_vehicles`
--
ALTER TABLE `users_vehicles`
  ADD CONSTRAINT `FK_648F4220545317D1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_648F4220A76ED395` FOREIGN KEY (`user_id`) REFERENCES `fos_user` (`id`) ON DELETE CASCADE;

--
-- Apribojimai lentelei `vehicle`
--
ALTER TABLE `vehicle`
  ADD CONSTRAINT `FK_1B80E4861C52F958` FOREIGN KEY (`brand`) REFERENCES `brand` (`id`),
  ADD CONSTRAINT `FK_1B80E4862D5B0234` FOREIGN KEY (`city`) REFERENCES `city` (`id`),
  ADD CONSTRAINT `FK_1B80E48640FFA59A` FOREIGN KEY (`first_country`) REFERENCES `country` (`id`),
  ADD CONSTRAINT `FK_1B80E4865373C966` FOREIGN KEY (`country`) REFERENCES `country` (`id`),
  ADD CONSTRAINT `FK_1B80E486665648E9` FOREIGN KEY (`color`) REFERENCES `color` (`id`),
  ADD CONSTRAINT `FK_1B80E48668E845B0` FOREIGN KEY (`defects`) REFERENCES `defects` (`id`),
  ADD CONSTRAINT `FK_1B80E4867F87199F` FOREIGN KEY (`transmission`) REFERENCES `transmission` (`id`),
  ADD CONSTRAINT `FK_1B80E48692C4739C` FOREIGN KEY (`provider`) REFERENCES `provider` (`id`),
  ADD CONSTRAINT `FK_1B80E486999E3587` FOREIGN KEY (`climate_control`) REFERENCES `climate_control` (`id`),
  ADD CONSTRAINT `FK_1B80E4869CA10F38` FOREIGN KEY (`fuel_type`) REFERENCES `fuel_type` (`id`),
  ADD CONSTRAINT `FK_1B80E486D79572D9` FOREIGN KEY (`model`) REFERENCES `model` (`id`),
  ADD CONSTRAINT `FK_1B80E486D95AEB4B` FOREIGN KEY (`body_type`) REFERENCES `body_type` (`id`);

--
-- Apribojimai lentelei `vehicle_search`
--
ALTER TABLE `vehicle_search`
  ADD CONSTRAINT `FK_1D2EDA741C52F958` FOREIGN KEY (`brand`) REFERENCES `brand` (`id`),
  ADD CONSTRAINT `FK_1D2EDA745373C966` FOREIGN KEY (`country`) REFERENCES `country` (`id`),
  ADD CONSTRAINT `FK_1D2EDA748D93D649` FOREIGN KEY (`user`) REFERENCES `fos_user` (`id`);
--
-- Database: `test`
--
DROP DATABASE IF EXISTS `test`;
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

DELIMITER $$
--
-- Procedūros
--
DROP PROCEDURE IF EXISTS `AddGeometryColumn`$$
CREATE DEFINER=`` PROCEDURE `AddGeometryColumn` (`catalog` VARCHAR(64), `t_schema` VARCHAR(64), `t_name` VARCHAR(64), `geometry_column` VARCHAR(64), `t_srid` INT)  begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' ADD ', geometry_column,' GEOMETRY REF_SYSTEM_ID=', t_srid); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end$$

DROP PROCEDURE IF EXISTS `DropGeometryColumn`$$
CREATE DEFINER=`` PROCEDURE `DropGeometryColumn` (`catalog` VARCHAR(64), `t_schema` VARCHAR(64), `t_name` VARCHAR(64), `geometry_column` VARCHAR(64))  begin
  set @qwe= concat('ALTER TABLE ', t_schema, '.', t_name, ' DROP ', geometry_column); PREPARE ls from @qwe; execute ls; deallocate prepare ls; end$$

DELIMITER ;
--
-- Database: `wptestas`
--
DROP DATABASE IF EXISTS `wptestas`;
CREATE DATABASE IF NOT EXISTS `wptestas` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `wptestas`;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'WordPress komentatorius', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-01-06 18:01:23', '2019-01-06 20:01:23', 'Sveiki, čia komentaras.\nJei norite pradėti moderuoti, taisyti ir trinti komentarus, aplankykite Komentarų langą valdymo skyde.\nKomentatorių atvaizdai pateikiami iš <a href=\"https://gravatar.com\">Gravatar</a> sistemos.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/test_ui/wordpress-wptestas', 'yes'),
(2, 'home', 'http://localhost/test_ui/wordpress-wptestas', 'yes'),
(3, 'blogname', 'wptestas', 'yes'),
(4, 'blogdescription', 'Kol kas tik dar vienas WordPress tinklalapis', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'pcr.kompiuteriai@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'Y F j', 'yes'),
(24, 'time_format', 'G:i', 'yes'),
(25, 'links_updated_date_format', 'Y F j - G:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-2', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:83:\"/opt/lampp/htdocs/test_ui/wordpress-wptestas/wp-content/plugins/akismet/akismet.php\";i:2;s:0:\"\";}', 'no'),
(40, 'template', 'catch-responsive', 'yes'),
(41, 'stylesheet', 'catch-responsive', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '1', 'yes'),
(96, 'WPLANG', '', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:6:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"primary-sidebar\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'nonce_key', ':y^Qml:ilY&yQ{8zj45]|[+g`zS56RoRVM ima=lLs>NCWj,[P!l0ZE;];4#=}Dz', 'no'),
(110, 'nonce_salt', '*L~dQ@JayvaX34iv4vJm(0/e<-Wi<LW*rPgb=U/un;YV{UNF~@qM7@MnA>b3an6}', 'no'),
(111, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'cron', 'a:4:{i:1546808486;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1546848086;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1546891303;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(115, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1546805085;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(127, 'auth_key', ';(~,4yGlmQX`: SU,0wm+<K:4i9{.p&bTm/ms7-3i1zP*Ha4c.F>.8-bvaO%V?6K', 'no'),
(128, 'auth_salt', 'l+M./.49r3jUXYl:o@IN~Gj(7W>taiw4T_@u_TY&wr22*cdwvF85A$O*xpW>d?5`', 'no'),
(129, 'logged_in_key', '`$e,!JcTC]l_2R2,~%3nXRn+{:tzo|FkKyJ^Ek,zNe9^-4kW>fpaHTyiM~no.hPy', 'no'),
(130, 'logged_in_salt', 'sLpv`N!_ON=4j&$i{q& j~4_y}2Y^RI>}KJO]:nGjxjw6!nDFvAjG=R%*5$m=yo+', 'no'),
(131, '_site_transient_timeout_browser_5b8fd1d60da9f748d773c2f3fc6ec89e', '1547409704', 'no'),
(132, '_site_transient_browser_5b8fd1d60da9f748d773c2f3fc6ec89e', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"64.0\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(134, '_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e', '1546848106', 'no'),
(135, '_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e', 'a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:5:{i:0;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:27:\"WordPress Meetup Kaunas #33\";s:3:\"url\";s:64:\"https://www.meetup.com/Kaunas-WordPress-Meetup/events/254830278/\";s:6:\"meetup\";s:23:\"Kaunas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Kaunas-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-01-17 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Kaunas, Lithuania\";s:7:\"country\";s:2:\"lt\";s:8:\"latitude\";d:54.8997650000000021464074961841106414794921875;s:9:\"longitude\";d:23.9617199999999996862243278883397579193115234375;}}i:1;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:27:\"WordPress Meetup Kaunas #34\";s:3:\"url\";s:64:\"https://www.meetup.com/Kaunas-WordPress-Meetup/events/257143475/\";s:6:\"meetup\";s:23:\"Kaunas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Kaunas-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-02-21 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Kaunas, Lithuania\";s:7:\"country\";s:2:\"lt\";s:8:\"latitude\";d:54.89999999999999857891452847979962825775146484375;s:9:\"longitude\";d:23.910000000000000142108547152020037174224853515625;}}i:2;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:27:\"WordPress Meetup Kaunas #35\";s:3:\"url\";s:64:\"https://www.meetup.com/Kaunas-WordPress-Meetup/events/257143547/\";s:6:\"meetup\";s:23:\"Kaunas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Kaunas-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-03-21 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Kaunas, Lithuania\";s:7:\"country\";s:2:\"lt\";s:8:\"latitude\";d:54.89999999999999857891452847979962825775146484375;s:9:\"longitude\";d:23.910000000000000142108547152020037174224853515625;}}i:3;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Kaunas\";s:3:\"url\";s:67:\"https://www.meetup.com/Kaunas-WordPress-Meetup/events/jwdrdqyzgbxb/\";s:6:\"meetup\";s:23:\"Kaunas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Kaunas-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-04-18 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Kaunas, Lithuania\";s:7:\"country\";s:2:\"lt\";s:8:\"latitude\";d:54.8996470000000016398189472965896129608154296875;s:9:\"longitude\";d:23.961511999999999034116626717150211334228515625;}}i:4;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Kaunas\";s:3:\"url\";s:67:\"https://www.meetup.com/Kaunas-WordPress-Meetup/events/jwdrdqyzhbvb/\";s:6:\"meetup\";s:23:\"Kaunas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Kaunas-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-05-16 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Kaunas, Lithuania\";s:7:\"country\";s:2:\"lt\";s:8:\"latitude\";d:54.8996470000000016398189472965896129608154296875;s:9:\"longitude\";d:23.961511999999999034116626717150211334228515625;}}}}', 'no'),
(136, 'can_compress_scripts', '1', 'no'),
(137, '_transient_is_multi_author', '0', 'yes'),
(138, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1546848108', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(139, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"\n\n\n\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"\n	\n	\n	\n	\n	\n	\n	\n	\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 23:49:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wordpress.org/?v=5.0.3-alpha-44387\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 5.0.2 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/12/wordpress-5-0-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 23:47:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6509\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:346:\"WordPress 5.0.2 is now available! 5.0.2 is a maintenance release that addresses 73 bugs. The primary focus of this release was performance improvements in the block editor: the cumulated performance gains make it 330% faster for a post with 200 blocks. Here are a few of the additional highlights: 45 total Block Editor improvements are [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4695:\"\n<p>WordPress 5.0.2 is now available!</p>\n\n\n\n<p>5.0.2 is a maintenance release that addresses 73 bugs. The primary focus of this release was performance improvements in the block editor: the cumulated performance gains make it 330% faster for a post with 200 blocks.</p>\n\n\n\n<p>Here are a few of the additional highlights:</p>\n\n\n\n<ul><li>45 total Block Editor improvements are included (14 performance enhancements &amp; 31 bug fixes).</li><li><a href=\"https://core.trac.wordpress.org/query?component=Bundled+Theme&amp;milestone=5.0.2&amp;col=id&amp;col=summary&amp;col=milestone&amp;col=owner&amp;col=type&amp;col=status&amp;col=priority&amp;order=priority\">17 Block Editor related bugs</a> have been fixed across all of the bundled themes.</li><li>Some <a href=\"https://core.trac.wordpress.org/query?component=I18N&amp;milestone=5.0.2&amp;col=id&amp;col=summary&amp;col=status&amp;col=owner&amp;col=type&amp;col=priority&amp;col=milestone&amp;order=priority\">internationalization (i18n) issues</a> related to script loading have also been fixed.</li></ul>\n\n\n\n<p>For a full list of changes, please consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.0.2&amp;group=component\">list of tickets on Trac</a> or the <a href=\"https://core.trac.wordpress.org/log/branches/5.0?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=44339&amp;stop_rev=44183&amp;limit=100&amp;sfp_email=&amp;sfph_mail=\">changelog</a>.</p>\n\n\n\n<p>You can <a href=\"https://wordpress.org/download/\">download WordPress 5.0.2</a> or visit Dashboard → Updates and click <em>Update Now</em>. Sites that support automatic background updates have already started to update automatically.</p>\n\n\n\n<p>Thank you to everyone who contributed to WordPress 5.0.2:</p>\n\n\n\n<p><a href=\"https://profiles.wordpress.org/babaevan/\">Alexander Babaev</a>, <a href=\"https://profiles.wordpress.org/akirk/\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/allancole/\">allancole</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/atimmer/\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/jdtrower/\">David Trower</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/edpittol/\">Eduardo Pittol</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/greg-raven/\">Greg Raven</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">gziolo</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">herregroen</a>, <a href=\"https://profiles.wordpress.org/icaleb/\">iCaleb</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/khleomix/\">khleomix</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">kjellr</a>, <a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff&nbsp;Paul</a>, <a href=\"https://profiles.wordpress.org/mihaivalentin/\">mihaivalentin</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/more/\"></a><a href=\"https://profiles.wordpress.org/mmaumio/\">Muntasir Mahmud</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pratikthink/\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/richtabor/\">Rich Tabor</a>, <a href=\"https://profiles.wordpress.org/strategio/\">strategio</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/torontodigits/\">TorontoDigits</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich/\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/volodymyrkolesnykov/\">volodymyrkolesnykov</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/ze3kr/\">ze3kr</a>, and <a href=\"https://profiles.wordpress.org/mypacecreator/\">のむらけい</a>.</p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordCamp US 2019 dates announced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2018/12/wordcamp-us-2019-dates-announced/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 19:47:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6496\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"Save the date! The next WordCamp US will be held on November 1-3, 2019, in beautiful St Louis, Missouri. One of our largest events of the year, WordCamp US is a great chance to connect with WordPress enthusiasts from around the world. This is also the event that features Matt Mullenweg&#8217;s annual State of the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:705:\"\n<p>Save the date! <a href=\"https://2019.us.wordcamp.org/2018/12/12/wordcamp-us-2019-announcing-our-dates/\">The next WordCamp US</a> will be held on November 1-3, 2019, in beautiful <a href=\"https://2018.us.wordcamp.org/2018/06/15/matt-mullenweg-announces-st-louis-as-wordcamp-us-2019-2020-host-city/\">St Louis, Missouri</a>. One of our largest events of the year, WordCamp US is a great chance to connect with WordPress enthusiasts from around the world. This is also the event that features Matt Mullenweg&#8217;s annual <a href=\"https://www.youtube.com/watch?v=r5b-N2RmxS8\">State of the Word</a> address. </p>\n\n\n\n<p>We&#8217;d love to see you in St. Louis next year, so mark your calendar now!<br></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6496\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 5.0.1 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 03:13:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6498\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:374:\"WordPress 5.0.1 is now available. This is a security release for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately. Plugin authors are encouraged to read the 5.0.1 developer notes for information on backwards-compatibility. WordPress versions 5.0 and earlier are affected by the following bugs, which are fixed in version [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Ian Dunn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4799:\"\n<p>WordPress 5.0.1 is now available. This is a <strong>security release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>\n\n\n\n<p>Plugin authors are encouraged to <a href=\"https://make.wordpress.org/core/2018/12/13/backwards-compatibility-breaks-in-5-0-1/\">read the 5.0.1 developer notes</a> for information on backwards-compatibility.</p>\n\n\n\n<p>WordPress versions 5.0 and earlier are affected by the following bugs, which are fixed in version 5.0.1. Updated versions of WordPress 4.9 and older releases are also available, for users who have not yet updated to 5.0.</p>\n\n\n\n<ul><li><a href=\"https://ripstech.com\">Karim El Ouerghemmi</a> discovered that authors could alter meta data to delete files that they weren&#8217;t authorized to.</li><li>Simon Scannell of <a href=\"https://blog.ripstech.com\">RIPS Technologies</a> discovered that authors could create posts of unauthorized post types with specially crafted input.</li><li><a href=\"https://twitter.com/_s_n_t\">Sam Thomas</a> discovered that contributors could craft meta data in a way that resulted in PHP object injection. </li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> discovered that contributors could edit new comments from higher-privileged users, potentially leading to a cross-site scripting vulnerability.</li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> also discovered that specially crafted URL inputs could lead to a cross-site scripting vulnerability in some circumstances. WordPress itself was not affected, but plugins could be in some situations. </li><li><a href=\"https://yoast.com/\">Team Yoast</a> discovered that the user activation screen could be indexed by search engines in some uncommon configurations, leading to exposure of email addresses, and in some rare cases, default generated passwords.</li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> and <a href=\"https://medium.com/websec\">Slavco</a> discovered that authors on Apache-hosted sites could upload specifically crafted files that bypass MIME verification, leading to a cross-site scripting vulnerability. </li></ul>\n\n\n\n<p>Thank you to all of the reporters for <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">privately disclosing the vulnerabilities</a>, which gave us time to fix them before WordPress sites could be attacked.</p>\n\n\n\n<p><a href=\"https://wordpress.org/download/\">Download WordPress 5.0.1</a>, or venture over to <code>Dashboard → Updates</code> and click <code>Update Now</code>. Sites that support automatic background updates are already beginning to update automatically.</p>\n\n\n\n<p>In addition to the security researchers mentioned above, thank you to everyone who contributed to WordPress 5.0.1:</p>\n\n\n\n<p><a href=\"https://profiles.wordpress.org/tellyworth\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/xknown\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron Campbell</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/vortfu\">Ben Bidner</a>, <a href=\"https://profiles.wordpress.org/barry\">Barry Abrahamson</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">Chris Christoff</a>, <a href=\"https://profiles.wordpress.org/darthhexx/\">David Newman</a>, <a href=\"https://profiles.wordpress.org/apokalyptik\">Demitrious Kelly</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/hnotess/\">Hannah Notess</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/herregroen\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/chanthaboune\">Josepha Haden</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/batmoo/\">Mo Jangda</a>, <a href=\"https://profiles.wordpress.org/nickdaugherty\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/SergeyBiryukov\">Sergey Biryukov</a>, and <a href=\"https://twitter.com/p_valentyn\">Valentyn Pylypchuk</a>.</p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6498\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:35:\"\n		\n		\n		\n		\n				\n\n		\n		\n				\n	\n\n		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"WordPress 5.0 “Bebo”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/news/2018/12/bebo/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Dec 2018 19:28:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6328\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:342:\"Say Hello to the New Editor We’ve made some big upgrades to the editor. Our new block-based editor is the first step toward an exciting new future with a streamlined editing experience across your site. You’ll have more flexibility with how content is displayed, whether you are building your first site, revamping your blog, or [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:2:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:52:\"https://s.w.org/images/core/5.0/videos/add-block.mp4\";s:6:\"length\";s:7:\"8086508\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:48:\"https://s.w.org/images/core/5.0/videos/build.mp4\";s:6:\"length\";s:7:\"2623964\";s:4:\"type\";s:9:\"video/mp4\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:56437:\"\n<h2 style=\"text-align:center\">Say Hello to the New Editor</h2>\n\n\n\n<figure class=\"wp-block-embed-youtube wp-block-embed is-type-video is-provider-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\n<iframe class=\'youtube-player\' type=\'text/html\' width=\'632\' height=\'386\' src=\'https://www.youtube.com/embed/72xdCU__XCk?version=3&#038;rel=1&#038;fs=1&#038;autohide=2&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' allowfullscreen=\'true\' style=\'border:0;\'></iframe>\n</div></figure>\n\n\n\n<p>We’ve made some big upgrades to the editor. Our new block-based editor is the first step toward an exciting new future with a streamlined editing experience across your site. You’ll have more flexibility with how content is displayed, whether you are building your first site, revamping your blog, or write code for a living.</p>\n\n\n\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?fit=2400%2C1200&amp;ssl=1\" alt=\"\" class=\"wp-image-6331\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?w=2400&amp;ssl=1 2400w, https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?resize=300%2C150&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?resize=768%2C384&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?resize=1024%2C512&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?w=1264&amp;ssl=1 1264w, https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" /></figure></div>\n\n\n\n<h2 style=\"text-align:center\">Building with Blocks</h2>\n\n\n\n<p>The new block-based editor won’t change the way any of your content looks to your visitors. What it will do is let you insert any type of multimedia in a snap and rearrange to your heart’s content. Each piece of content will be in its own block; a distinct wrapper for easy maneuvering. If you’re more of an HTML and CSS sort of person, then the blocks won’t stand in your way. WordPress is here to simplify the process, not the outcome.</p>\n\n\n\n<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/add-block.mp4\"></video></figure>\n\n\n\n<p>We have tons of blocks available by default, and more get added by the community every day. Here are a few of the blocks to help you get started:</p>\n\n\n\n<ul class=\"wp-block-gallery columns-4 is-cropped\"><li class=\"blocks-gallery-item\"><figure><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Paragraph.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6340\" data-link=\"https://wordpress.org/news/?attachment_id=6340\" class=\"wp-image-6340\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Paragraph.jpg?w=500&amp;ssl=1 500w, https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Paragraph.jpg?resize=150%2C150&amp;ssl=1 150w, https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Paragraph.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Paragraph</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Heading.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6341\" data-link=\"https://wordpress.org/news/?attachment_id=6341\" class=\"wp-image-6341\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Heading.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Heading.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Heading.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Heading</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Preformatted.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6342\" data-link=\"https://wordpress.org/news/?attachment_id=6342\" class=\"wp-image-6342\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Preformatted.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Preformatted.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Preformatted.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Preformatted</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Quote.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6343\" data-link=\"https://wordpress.org/news/?attachment_id=6343\" class=\"wp-image-6343\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Quote.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Quote.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Quote.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Quote</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Image.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6344\" data-link=\"https://wordpress.org/news/?attachment_id=6344\" class=\"wp-image-6344\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Image.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Image.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Image.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Image</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Gallery.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6345\" data-link=\"https://wordpress.org/news/?attachment_id=6345\" class=\"wp-image-6345\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Gallery.jpg?w=500&amp;ssl=1 500w, https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Gallery.jpg?resize=150%2C150&amp;ssl=1 150w, https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Gallery.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Gallery</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Cover-Image.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6346\" data-link=\"https://wordpress.org/news/?attachment_id=6346\" class=\"wp-image-6346\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Cover-Image.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Cover-Image.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Cover-Image.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Cover</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Video.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6347\" data-link=\"https://wordpress.org/news/?attachment_id=6347\" class=\"wp-image-6347\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Video.jpg?w=500&amp;ssl=1 500w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Video.jpg?resize=150%2C150&amp;ssl=1 150w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Video.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Video</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Audio.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6348\" data-link=\"https://wordpress.org/news/?attachment_id=6348\" class=\"wp-image-6348\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Audio.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Audio.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Audio.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Audio</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Column.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6349\" data-link=\"https://wordpress.org/news/?attachment_id=6349\" class=\"wp-image-6349\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Column.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Column.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Column.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Columns</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-File.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6350\" data-link=\"https://wordpress.org/news/?attachment_id=6350\" class=\"wp-image-6350\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-File.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-File.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-File.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>File</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Code.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6351\" data-link=\"https://wordpress.org/news/?attachment_id=6351\" class=\"wp-image-6351\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Code.jpg?w=500&amp;ssl=1 500w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Code.jpg?resize=150%2C150&amp;ssl=1 150w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Code.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Code</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-List.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6352\" data-link=\"https://wordpress.org/news/?attachment_id=6352\" class=\"wp-image-6352\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-List.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-List.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-List.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>List</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Button.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6353\" data-link=\"https://wordpress.org/news/?attachment_id=6353\" class=\"wp-image-6353\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Button.jpg?w=500&amp;ssl=1 500w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Button.jpg?resize=150%2C150&amp;ssl=1 150w, https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Button.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Button</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Embeds.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6354\" data-link=\"https://wordpress.org/news/?attachment_id=6354\" class=\"wp-image-6354\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Embeds.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Embeds.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Embeds.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>Embeds</figcaption></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-More.jpg?w=632&#038;ssl=1\" alt=\"\" data-id=\"6355\" data-link=\"https://wordpress.org/news/?attachment_id=6355\" class=\"wp-image-6355\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-More.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-More.jpg?resize=150%2C150&amp;ssl=1 150w, https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-More.jpg?resize=300%2C300&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /><figcaption>More</figcaption></figure></li></ul>\n\n\n\n<h2 style=\"text-align:center\">Freedom to Build, Freedom to Write</h2>\n\n\n\n<p>This new editing experience provides a more consistent treatment of design as well as content. If you’re building client sites, you can create reusable blocks. This lets your clients add new content anytime, while still maintaining a consistent look and feel.</p>\n\n\n\n<figure class=\"wp-block-video\"><video controls src=\"https://s.w.org/images/core/5.0/videos/build.mp4\"></video></figure>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2 style=\"text-align:center\">A Stunning New Default Theme</h2>\n\n\n\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?fit=2400%2C1600&amp;ssl=1\" alt=\"\" class=\"wp-image-6358\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?w=2400&amp;ssl=1 2400w, https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?resize=300%2C200&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?resize=768%2C512&amp;ssl=1 768w, https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?resize=1024%2C683&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?w=1264&amp;ssl=1 1264w, https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" /></figure></div>\n\n\n\n<p>Introducing Twenty Nineteen, a new default theme that shows off the power of the new editor.</p>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/block-editor-1024x683.jpg?resize=632%2C422&#038;ssl=1\" alt=\"\" class=\"wp-image-6359\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2018/12/block-editor.jpg?resize=1024%2C683&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2018/12/block-editor.jpg?resize=300%2C200&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2018/12/block-editor.jpg?resize=768%2C512&amp;ssl=1 768w, https://i0.wp.com/wordpress.org/news/files/2018/12/block-editor.jpg?w=1200&amp;ssl=1 1200w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_9\">Designed for the block editor</h3>\n\n\n\n<p>Twenty Nineteen features custom styles for the blocks available by default in 5.0. It makes extensive use of editor styles throughout the theme. That way, what you create in your content editor is what you see on the front of your site.<br></p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/typography-1.jpg?w=632&#038;ssl=1\" alt=\"\" class=\"wp-image-6427\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/typography-1.jpg?w=900&amp;ssl=1 900w, https://i1.wp.com/wordpress.org/news/files/2018/12/typography-1.jpg?resize=300%2C200&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2018/12/typography-1.jpg?resize=768%2C512&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_18\">Simple, type-driven layout</h3>\n\n\n\n<p>Featuring ample whitespace, and modern sans-serif headlines paired with classic serif body text, Twenty Nineteen is built to be beautiful on the go. It uses system fonts to increase loading speed. No more long waits on slow networks!</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen-versatile.gif?w=632&#038;ssl=1\" alt=\"\" class=\"wp-image-6361\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_24\">Versatile design for all sites</h3>\n\n\n\n<p>Twenty Nineteen is designed to work for a wide variety of use cases. Whether you’re running a photo blog, launching a new business, or supporting a non-profit, Twenty Nineteen is flexible enough to fit your needs.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/themes/twentynineteen/\" style=\"color:#ffffff\">Give Twenty Nineteen a try</a></div>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2 style=\"text-align:center\">Developer Happiness</h2>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Protect.jpg?w=632&#038;ssl=1\" alt=\"\" class=\"wp-image-6362\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Protect.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Protect.jpg?resize=300%2C210&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_34\">Protect</h3>\n\n\n\n<p>Blocks provide a comfortable way for users to change content directly, while also ensuring the content structure cannot be easily disturbed by accidental code edits. This allows the developer to control the output, building polished and semantic markup that is preserved through edits and not easily broken.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Compose.jpg?w=632&#038;ssl=1\" alt=\"\" class=\"wp-image-6363\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Compose.jpg?w=500&amp;ssl=1 500w, https://i2.wp.com/wordpress.org/news/files/2018/12/Compose.jpg?resize=300%2C210&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_39\">Compose</h3>\n\n\n\n<p>Take advantage of a wide collection of APIs and interface components to easily create blocks with intuitive controls for your clients. Utilizing these components not only speeds up development work but also provide a more consistent, usable, and accessible interface to all users.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><figure class=\"wp-block-media-text__media\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Create.jpg?w=632&#038;ssl=1\" alt=\"\" class=\"wp-image-6364\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Create.jpg?w=500&amp;ssl=1 500w, https://i1.wp.com/wordpress.org/news/files/2018/12/Create.jpg?resize=300%2C210&amp;ssl=1 300w\" sizes=\"(max-width: 500px) 100vw, 500px\" data-recalc-dims=\"1\" /></figure><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_45\">Create</h3>\n\n\n\n<p>The new block paradigm opens up a path of exploration and imagination when it comes to solving user needs. With the unified block insertion flow, it’s easier for your clients and customers to find and use blocks for all types of content. Developers can focus on executing their vision and providing rich editing experiences, rather than fussing with difficult APIs.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/gutenberg/handbook/\" style=\"color:#ffffff\">Learn how to get started</a></div>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2 style=\"text-align:center\">Keep it Classic</h2>\n\n\n\n<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?fit=2400%2C1130&amp;ssl=1\" alt=\"\" class=\"wp-image-6365\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?w=2400&amp;ssl=1 2400w, https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?resize=300%2C141&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?resize=768%2C362&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?resize=1024%2C482&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?w=1264&amp;ssl=1 1264w, https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" /></figure></div>\n\n\n\n<p>Prefer to stick with the familiar Classic Editor? No problem! Support for the Classic Editor plugin will remain in WordPress through 2021.</p>\n\n\n\n<p>The Classic Editor plugin restores the previous WordPress editor and the Edit Post screen. It lets you keep using plugins that extend it, add old-style meta boxes, or otherwise depend on the previous editor. To install, visit your plugins page and click the “Install Now” button next to “Classic Editor”. After the plugin finishes installing, click “Activate”. That’s it!</p>\n\n\n\n<p>Note to users of assistive technology: if you experience usability issues with the block editor, we recommend you continue to use the Classic Editor.</p>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/plugins/classic-editor/\" style=\"color:#ffffff\">Check out the Classic Editor</a></div>\n\n\n\n<p>This release is named in homage to the pioneering Cuban jazz musician <a href=\"https://en.wikipedia.org/wiki/Bebo_Vald%C3%A9s\">Bebo Valdés</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>The Squad</h2>\n\n\n\n<p>This release was led by <a href=\"http://ma.tt/\">Matt Mullenweg</a>, along with co-leads <a href=\"https://www.allancole.com/\">Allan Cole</a>, <a href=\"http://antpb.com/\">Anthony Burchell</a>, <a href=\"https://pento.net/\">Gary Pendergast</a>, <a href=\"https://josepha.blog/\">Josepha Haden Chomphosy</a>, <a href=\"https://laurel.blog/\">Laurel Fulford</a>, <a href=\"https://yoast.com/about-us/team/omar-reiss/\">Omar Reiss</a>, <a href=\"https://danielbachhuber.com/\">Daniel Bachhuber</a>, <a href=\"https://matiasventura.com/\">Matías Ventura</a>, <a href=\"https://lamda.blog/\">Miguel Fonseca</a>, <a href=\"https://tam.blog/\">Tammie Lister</a>, <a href=\"https://tofumatt.com/\">Matthew Riley MacPherson</a>. They were ably assisted by the following fabulous folks. There were 423 contributors with props in this release. Pull up some Bebo Valdés on your music service of choice, and check out some of their profiles:</p>\n\n\n<a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abdulwahab610\">Abdul Wahab</a>, <a href=\"https://profiles.wordpress.org/abdullahramzan\">Abdullah Ramzan</a>, <a href=\"https://profiles.wordpress.org/abhijitrakas\">Abhijit Rakas</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/afraithe\">afraithe</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/ahmadawais\">ahmadawais</a>, <a href=\"https://profiles.wordpress.org/airathalitov\">Airat Halitov</a>, <a href=\"https://profiles.wordpress.org/ajitbohra\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/schlessera\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/albertomedina\">albertomedina</a>, <a href=\"https://profiles.wordpress.org/aldavigdis\">aldavigdis</a>, <a href=\"https://profiles.wordpress.org/akirk\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/alexsanford1\">Alex Sanford</a>, <a href=\"https://profiles.wordpress.org/babaevan\">Alexander Babaev</a>, <a href=\"https://profiles.wordpress.org/xyfi\">Alexander Botteram</a>, <a href=\"https://profiles.wordpress.org/alexis\">alexis</a>, <a href=\"https://profiles.wordpress.org/alexislloyd\">Alexis Lloyd</a>, <a href=\"https://profiles.wordpress.org/arush\">Amanda Rush</a>, <a href=\"https://profiles.wordpress.org/amedina\">amedina</a>, <a href=\"https://profiles.wordpress.org/nosolosw\">Andr&#233;s</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/euthelup\">Andrei Lupu</a>, <a href=\"https://profiles.wordpress.org/andreiglingeanu\">andreiglingeanu</a>, <a href=\"https://profiles.wordpress.org/aduth\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/sumobi\">Andrew Munro</a>, <a href=\"https://profiles.wordpress.org/anevins\">Andrew Nevins</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/androb\">Andrew Roberts</a>, <a href=\"https://profiles.wordpress.org/andrewtaylor-1\">Andrew Taylor</a>, <a href=\"https://profiles.wordpress.org/andrewserong\">andrewserong</a>, <a href=\"https://profiles.wordpress.org/apeatling\">Andy Peatling</a>, <a href=\"https://profiles.wordpress.org/ameeker\">Angie Meeker</a>, <a href=\"https://profiles.wordpress.org/annaharrison\">Anna Harrison</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/arnaudban\">ArnaudBan</a>, <a href=\"https://profiles.wordpress.org/arshidkv12\">Arshid</a>, <a href=\"https://profiles.wordpress.org/aprakasa\">Arya Prakasa</a>, <a href=\"https://profiles.wordpress.org/artisticasad\">Asad</a>, <a href=\"https://profiles.wordpress.org/mrasharirfan\">Ashar Irfan</a>, <a href=\"https://profiles.wordpress.org/asvinballoo\">Asvin Balloo</a>, <a href=\"https://profiles.wordpress.org/atanasangelovdev\">Atanas Angelov</a>, <a href=\"https://profiles.wordpress.org/b-07\">Bappi</a>, <a href=\"https://profiles.wordpress.org/bcolumbia\">bcolumbia</a>, <a href=\"https://profiles.wordpress.org/belcherj\">belcherj</a>, <a href=\"https://profiles.wordpress.org/blowery\">Ben Lowery</a>, <a href=\"https://profiles.wordpress.org/caxco93\">Benjamin Eyzaguirre</a>, <a href=\"https://profiles.wordpress.org/benjamin_zekavica\">Benjamin Zekavica</a>, <a href=\"https://profiles.wordpress.org/benlk\">benlk</a>, <a href=\"https://profiles.wordpress.org/kau-boy\">Bernhard Kau</a>, <a href=\"https://profiles.wordpress.org/bernhard-reiter\">Bernhard Reiter</a>, <a href=\"https://profiles.wordpress.org/betsela\">betsela</a>, <a href=\"https://profiles.wordpress.org/bhargavmehta\">Bhargav Mehta</a>, <a href=\"https://profiles.wordpress.org/birgire\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bph\">Birgit Pauli-Haack</a>, <a href=\"https://profiles.wordpress.org/bobbingwide\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/boblinthorst\">boblinthorst</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bradyvercher\">Brady Vercher</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/bpayton\">Brandon Payton</a>, <a href=\"https://profiles.wordpress.org/brentswisher\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/technosiren\">Brianna Privett</a>, <a href=\"https://profiles.wordpress.org/briannaorg\">briannaorg</a>, <a href=\"https://profiles.wordpress.org/bronsonquick\">Bronson Quick</a>, <a href=\"https://profiles.wordpress.org/bandonrandon\">Brooke.</a>, <a href=\"https://profiles.wordpress.org/burhandodhy\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cantothemes\">CantoThemes</a>, <a href=\"https://profiles.wordpress.org/cathibosco\">cathibosco</a>, <a href=\"https://profiles.wordpress.org/chetan200891\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chetansatasiya\">chetansatasiya</a>, <a href=\"https://profiles.wordpress.org/ketuchetan\">chetansatasiya</a>, <a href=\"https://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisl27\">Chris Lloyd</a>, <a href=\"https://profiles.wordpress.org/crunnells\">Chris Runnells</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/chriskmnds\">chriskmnds</a>, <a href=\"https://profiles.wordpress.org/pixelverbieger\">Christian Sabo</a>, <a href=\"https://profiles.wordpress.org/christophherr\">Christoph Herr</a>, <a href=\"https://profiles.wordpress.org/claudiosanches\">Claudio Sanches</a>, <a href=\"https://profiles.wordpress.org/coderkevin\">coderkevin</a>, <a href=\"https://profiles.wordpress.org/copons\">Copons</a>, <a href=\"https://profiles.wordpress.org/courtney0burton\">courtney0burton</a>, <a href=\"https://profiles.wordpress.org/mitogh\">Crisoforo Gaspar</a>, <a href=\"https://profiles.wordpress.org/littlebigthing\">Csaba (LittleBigThings)</a>, <a href=\"https://profiles.wordpress.org/csabotta\">csabotta</a>, <a href=\"https://profiles.wordpress.org/danieltj\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/talldanwp\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/danielhw\">danielhw</a>, <a href=\"https://profiles.wordpress.org/daniloercoli\">daniloercoli</a>, <a href=\"https://profiles.wordpress.org/dannycooper\">DannyCooper</a>, <a href=\"https://profiles.wordpress.org/nerrad\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/davemoran118\">davemoran118</a>, <a href=\"https://profiles.wordpress.org/davidbinda\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/dcavins\">David Cavins</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David Kennedy</a>, <a href=\"https://profiles.wordpress.org/dryanpress\">David Ryan</a>, <a href=\"https://profiles.wordpress.org/davidsword\">David Sword</a>, <a href=\"https://profiles.wordpress.org/jdtrower\">David Trower</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/davidherrera\">davidherrera</a>, <a href=\"https://profiles.wordpress.org/davisshaver\">Davis</a>, <a href=\"https://profiles.wordpress.org/dciso\">dciso</a>, <a href=\"https://profiles.wordpress.org/dmsnell\">Dennis Snell</a>, <a href=\"https://profiles.wordpress.org/dsmart\">Derek Smart</a>, <a href=\"https://profiles.wordpress.org/designsimply\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dlocc\">Devin Walker</a>, <a href=\"https://profiles.wordpress.org/deviodigital\">Devio Digital</a>, <a href=\"https://profiles.wordpress.org/dfangstrom\">dfangstrom</a>, <a href=\"https://profiles.wordpress.org/dhanendran\">Dhanendran</a>, <a href=\"https://profiles.wordpress.org/diegoliv\">Diego de Oliveira</a>, <a href=\"https://profiles.wordpress.org/diegoreymendez\">diegoreymendez</a>, <a href=\"https://profiles.wordpress.org/dingo_bastard\">dingo-d</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dency\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/dixitadusara\">Dixita Dusara Gohil</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/donnapep\">Donna Peplinskie</a>, <a href=\"https://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dsawardekar\">dsawardekar</a>, <a href=\"https://profiles.wordpress.org/dsifford\">dsifford</a>, <a href=\"https://profiles.wordpress.org/duanestorey\">Duane Storey</a>, <a href=\"https://profiles.wordpress.org/edpittol\">Eduardo Pittol</a>, <a href=\"https://profiles.wordpress.org/chopinbach\">Edwin Cromley</a>, <a href=\"https://profiles.wordpress.org/ehg\">ehg</a>, <a href=\"https://profiles.wordpress.org/electricfeet\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/epointal\">Elisabeth Pointal</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/elrae\">elrae</a>, <a href=\"https://profiles.wordpress.org/enodekciw\">enodekciw</a>, <a href=\"https://profiles.wordpress.org/ephoxjames\">ephoxjames</a>, <a href=\"https://profiles.wordpress.org/ephoxmogran\">ephoxmogran</a>, <a href=\"https://profiles.wordpress.org/sewmyheadon\">Eric Amundson</a>, <a href=\"https://profiles.wordpress.org/ericnmurphy\">ericnmurphy</a>, <a href=\"https://profiles.wordpress.org/etoledom\">etoledom</a>, <a href=\"https://profiles.wordpress.org/circlecube\">Evan Mullins</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy\">fabiankaegy</a>, <a href=\"https://profiles.wordpress.org/fabs_pim\">fabs_pim</a>, <a href=\"https://profiles.wordpress.org/faishal\">Faishal</a>, <a href=\"https://profiles.wordpress.org/flixos90\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/floriansimeth\">Florian Simeth</a>, <a href=\"https://profiles.wordpress.org/foobar4u\">foobar4u</a>, <a href=\"https://profiles.wordpress.org/foreverpinetree\">foreverpinetree</a>, <a href=\"https://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/fuyuko\">fuyuko</a>, <a href=\"https://profiles.wordpress.org/gma992\">Gabriel Maldonado</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/doomwaxer\">Gary Thayer</a>, <a href=\"https://profiles.wordpress.org/garyjones\">garyjones</a>, <a href=\"https://profiles.wordpress.org/soulseekah\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/babbardel\">George Olaru</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/georgeh\">georgeh</a>, <a href=\"https://profiles.wordpress.org/gnif\">gnif</a>, <a href=\"https://profiles.wordpress.org/goldsounds\">goldsounds</a>, <a href=\"https://profiles.wordpress.org/grappler\">Grappler</a>, <a href=\"https://profiles.wordpress.org/greg-raven\">Greg Raven</a>, <a href=\"https://profiles.wordpress.org/gziolo\">Grzegorz Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/bordoni\">Gustavo Bordoni</a>, <a href=\"https://profiles.wordpress.org/gwwar\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hardeepasrani\">Hardeep Asrani</a>, <a href=\"https://profiles.wordpress.org/hblackett\">hblackett</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandi</a>, <a href=\"https://profiles.wordpress.org/luehrsen\">Hendrik Luehrsen</a>, <a href=\"https://profiles.wordpress.org/herbmiller\">herbmiller</a>, <a href=\"https://profiles.wordpress.org/herregroen\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/hypest\">hypest</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianstewart\">ianstewart</a>, <a href=\"https://profiles.wordpress.org/ianbelanger\">ibelanger</a>, <a href=\"https://profiles.wordpress.org/icaleb\">iCaleb</a>, <a href=\"https://profiles.wordpress.org/idpokute\">idpokute</a>, <a href=\"https://profiles.wordpress.org/igorsch\">Igor</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/imonly_ik\">Imran Khalid</a>, <a href=\"https://profiles.wordpress.org/intronic\">intronic</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/ireneyoast\">Irene Strikkers</a>, <a href=\"https://profiles.wordpress.org/ismailelkorchi\">Ismail El Korchi</a>, <a href=\"https://profiles.wordpress.org/israelshmueli\">israelshmueli</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jd55\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jakept\">Jacob Peattie</a>, <a href=\"https://profiles.wordpress.org/jagnew\">jagnew</a>, <a href=\"https://profiles.wordpress.org/jahvi\">jahvi</a>, <a href=\"https://profiles.wordpress.org/jnylen0\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/jamestryon\">jamestryon</a>, <a href=\"https://profiles.wordpress.org/jamiehalvorson\">jamiehalvorson</a>, <a href=\"https://profiles.wordpress.org/jdembowski\">Jan Dembowski</a>, <a href=\"https://profiles.wordpress.org/janalwin\">janalwin</a>, <a href=\"https://profiles.wordpress.org/jaswrks\">Jason Caldwell</a>, <a href=\"https://profiles.wordpress.org/octalmage\">Jason Stallings</a>, <a href=\"https://profiles.wordpress.org/yingling017\">Jason Yingling</a>, <a href=\"https://profiles.wordpress.org/vengisss\">Javier Villanueva</a>, <a href=\"https://profiles.wordpress.org/jhoffm34\">Jay Hoffmann</a>, <a href=\"https://profiles.wordpress.org/audrasjb\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jblz\">Jeff Bowen</a>, <a href=\"https://profiles.wordpress.org/jeffpaul\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">JJJ</a>, <a href=\"https://profiles.wordpress.org/sephsekla\">Joe Bailey-Roberts</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joemaller\">joemaller</a>, <a href=\"https://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/j-falk\">Johan Falk</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnny5\">John Godley</a>, <a href=\"https://profiles.wordpress.org/johndyer\">johndyer</a>, <a href=\"https://profiles.wordpress.org/johnpixle\">JohnPixle</a>, <a href=\"https://profiles.wordpress.org/johnwatkins0\">johnwatkins0</a>, <a href=\"https://profiles.wordpress.org/jomurgel\">jomurgel</a>, <a href=\"https://profiles.wordpress.org/jonsurrell\">Jon Surrell</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/koke\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/ieatwebsites\">Jose Fremaint</a>, <a href=\"https://profiles.wordpress.org/shelob9\">Josh Pollock</a>, <a href=\"https://profiles.wordpress.org/jvisick77\">Josh Visick</a>, <a href=\"https://profiles.wordpress.org/joshuawold\">Joshua Wold</a>, <a href=\"https://profiles.wordpress.org/joyously\">Joy</a>, <a href=\"https://profiles.wordpress.org/jrf\">jrf</a>, <a href=\"https://profiles.wordpress.org/jryancard\">jryancard</a>, <a href=\"https://profiles.wordpress.org/jsnajdr\">jsnajdr</a>, <a href=\"https://profiles.wordpress.org/julienmelissas\">JulienMelissas</a>, <a href=\"https://profiles.wordpress.org/kopepasah\">Justin Kopepasah</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"https://profiles.wordpress.org/kallehauge\">Kallehauge</a>, <a href=\"https://profiles.wordpress.org/kalpshit\">KalpShit Akabari</a>, <a href=\"https://profiles.wordpress.org/codebykat\">Kat Hagan</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kevinwhoffman\">Kevin Hoffman</a>, <a href=\"https://profiles.wordpress.org/khleomix\">khleomix</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/kluny\">kluny</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/krutidugade\">krutidugade</a>, <a href=\"https://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/notlaura\">Lara Schenck</a>, <a href=\"https://profiles.wordpress.org/leahkoerper\">leahkoerper</a>, <a href=\"https://profiles.wordpress.org/lloyd\">lloyd</a>, <a href=\"https://profiles.wordpress.org/loicblascos\">Lo&#239;c Blascos</a>, <a href=\"https://profiles.wordpress.org/lucasstark\">Lucas Stark</a>, <a href=\"https://profiles.wordpress.org/lucasrolff\">LucasRolff</a>, <a href=\"https://profiles.wordpress.org/luigipulcini\">luigipulcini</a>, <a href=\"https://profiles.wordpress.org/lukecavanagh\">Luke Cavanagh</a>, <a href=\"https://profiles.wordpress.org/lucaskowalski\">Luke Kowalski</a>, <a href=\"https://profiles.wordpress.org/lukepettway\">Luke Pettway</a>, <a href=\"https://profiles.wordpress.org/luminus\">Luminus</a>, <a href=\"https://profiles.wordpress.org/lynneux\">lynneux</a>, <a href=\"https://profiles.wordpress.org/macbookandrew\">macbookandrew</a>, <a href=\"https://profiles.wordpress.org/maedahbatool\">Maedah Batool</a>, <a href=\"https://profiles.wordpress.org/mahdiyazdani\">Mahdi Yazdani</a>, <a href=\"https://profiles.wordpress.org/mahmoudsaeed\">mahmoudsaeed</a>, <a href=\"https://profiles.wordpress.org/travel_girl\">Maja Benke</a>, <a href=\"https://profiles.wordpress.org/mkaz\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/marina_wp\">marina_wp</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mariusvw\">mariusvw</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/mapk\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/vindl\">Marko Andrijasevic</a>, <a href=\"https://profiles.wordpress.org/martinlugton\">martinlugton</a>, <a href=\"https://profiles.wordpress.org/m-e-h\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/mathiu\">mathiu</a>, <a href=\"https://profiles.wordpress.org/webdevmattcrom\">Matt Cromwell</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/mattgeri\">MattGeri</a>, <a href=\"https://profiles.wordpress.org/mboynes\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/maurobringolf\">maurobringolf</a>, <a href=\"https://profiles.wordpress.org/maximebj\">Maxime BERNARD-JACQUET</a>, <a href=\"https://profiles.wordpress.org/mayukojpn\">Mayo Moriyama</a>, <a href=\"https://profiles.wordpress.org/meetjey\">meetjey</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mendezcode\">mendezcode</a>, <a href=\"https://profiles.wordpress.org/woodent\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/wpscholar\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Michael Adams (mdawaffe)</a>, <a href=\"https://profiles.wordpress.org/michaelhull\">Michael Hull</a>, <a href=\"https://profiles.wordpress.org/mnelson4\">Michael Nelson</a>, <a href=\"https://profiles.wordpress.org/mizejewski\">Michele Mizejewski</a>, <a href=\"https://profiles.wordpress.org/jbpaul17\">Migrated to @jeffpaul</a>, <a href=\"https://profiles.wordpress.org/mihaivalentin\">mihaivalentin</a>, <a href=\"https://profiles.wordpress.org/stubgo\">Miina Sikk</a>, <a href=\"https://profiles.wordpress.org/simison\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mihai2u\">Mike Crantea</a>, <a href=\"https://profiles.wordpress.org/mike-haydon-swo\">Mike Haydon</a>, <a href=\"https://profiles.wordpress.org/mikeschroder\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeselander\">Mike Selander</a>, <a href=\"https://profiles.wordpress.org/mikehaydon\">mikehaydon</a>, <a href=\"https://profiles.wordpress.org/mikeyarce\">Mikey Arce</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/milana_cap\">Milana Cap</a>, <a href=\"https://profiles.wordpress.org/gonzomir\">Milen Petrinski - Gonzo</a>, <a href=\"https://profiles.wordpress.org/milesdelliott\">milesdelliott</a>, <a href=\"https://profiles.wordpress.org/mimo84\">mimo84</a>, <a href=\"https://profiles.wordpress.org/0mirka00\">mirka</a>, <a href=\"https://profiles.wordpress.org/mmtr86\">mmtr86</a>, <a href=\"https://profiles.wordpress.org/boemedia\">Monique Dubbelman</a>, <a href=\"https://profiles.wordpress.org/mor10\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/mostafas1990\">Mostafa Soufi</a>, <a href=\"https://profiles.wordpress.org/motleydev\">motleydev</a>, <a href=\"https://profiles.wordpress.org/mpheasant\">mpheasant</a>, <a href=\"https://profiles.wordpress.org/mrmadhat\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/mrwweb\">mrwweb</a>, <a href=\"https://profiles.wordpress.org/msdesign21\">msdesign21</a>, <a href=\"https://profiles.wordpress.org/mtias\">mtias</a>, <a href=\"https://profiles.wordpress.org/desideveloper\">Muhammad Irfan</a>, <a href=\"https://profiles.wordpress.org/mukesh27\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/munirkamal\">munirkamal</a>, <a href=\"https://profiles.wordpress.org/mmaumio\">Muntasir Mahmud</a>, <a href=\"https://profiles.wordpress.org/mzorz\">mzorz</a>, <a href=\"https://profiles.wordpress.org/nagayama\">nagayama</a>, <a href=\"https://profiles.wordpress.org/nfmohit\">Nahid F. Mohit</a>, <a href=\"https://profiles.wordpress.org/nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/napy84\">napy84</a>, <a href=\"https://profiles.wordpress.org/nateconley\">nateconley</a>, <a href=\"https://profiles.wordpress.org/nativeinside\">Native Inside</a>, <a href=\"https://profiles.wordpress.org/greatislander\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/buzztone\">Neil Murray</a>, <a href=\"https://profiles.wordpress.org/nicbertino\">nic.bertino</a>, <a href=\"https://profiles.wordpress.org/notnownikki\">Nicola Heald</a>, <a href=\"https://profiles.wordpress.org/nielslange\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/nikschavan\">Nikhil Chavan</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/nitrajka\">nitrajka</a>, <a href=\"https://profiles.wordpress.org/njpanderson\">njpanderson</a>, <a href=\"https://profiles.wordpress.org/nshki\">nshki</a>, <a href=\"https://profiles.wordpress.org/hideokamoto\">Okamoto Hidetaka</a>, <a href=\"https://profiles.wordpress.org/oskosk\">oskosk</a>, <a href=\"https://profiles.wordpress.org/otto42\">Otto</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya-1\">Paresh Radadiya</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pauldechov\">Paul Dechov</a>, <a href=\"https://profiles.wordpress.org/paulstonier\">Paul Stonier</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/pedromendonca\">Pedro Mendon&#231;a</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/pglewis\">pglewis</a>, <a href=\"https://profiles.wordpress.org/tyrannous\">Philipp Bammes</a>, <a href=\"https://profiles.wordpress.org/piersb\">piersb</a>, <a href=\"https://profiles.wordpress.org/wizzard_\">Pieter Daalder</a>, <a href=\"https://profiles.wordpress.org/pilou69\">pilou69</a>, <a href=\"https://profiles.wordpress.org/delawski\">Piotr Delawski</a>, <a href=\"https://profiles.wordpress.org/poena\">poena</a>, <a href=\"https://profiles.wordpress.org/postphotos\">postphotos</a>, <a href=\"https://profiles.wordpress.org/potbot\">potbot</a>, <a href=\"https://profiles.wordpress.org/prtksxna\">Prateek Saxena</a>, <a href=\"https://profiles.wordpress.org/pratikthink\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/presskopp\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/psealock\">psealock</a>, <a href=\"https://profiles.wordpress.org/ptasker\">ptasker</a>, <a href=\"https://profiles.wordpress.org/rachelmcr\">Rachel</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rahmohn\">Rahmohn</a>, <a href=\"https://profiles.wordpress.org/rahmon\">Rahmon</a>, <a href=\"https://profiles.wordpress.org/rahulsprajapati\">Rahul Prajapati</a>, <a href=\"https://profiles.wordpress.org/rakshans1\">rakshans1</a>, <a href=\"https://profiles.wordpress.org/ramonopoly\">ramonopoly</a>, <a href=\"https://profiles.wordpress.org/lamosty\">Rastislav Lamos</a>, <a href=\"https://profiles.wordpress.org/revgeorge\">revgeorge</a>, <a href=\"https://profiles.wordpress.org/youknowriad\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/richtabor\">Rich Tabor</a>, <a href=\"https://profiles.wordpress.org/richsalvucci\">richsalvucci</a>, <a href=\"https://profiles.wordpress.org/riddhiehta02\">Riddhi Mehta</a>, <a href=\"https://profiles.wordpress.org/rileybrook\">rileybrook</a>, <a href=\"https://profiles.wordpress.org/noisysocks\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/sanchothefat\">Robert O\'Rourke</a>, <a href=\"https://profiles.wordpress.org/robertsky\">robertsky</a>, <a href=\"https://profiles.wordpress.org/_dorsvenabili\">Rocio Valdivia</a>, <a href=\"https://profiles.wordpress.org/rohittm\">Rohit Motwani</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/ryo511\">ryo511</a>, <a href=\"https://profiles.wordpress.org/sagarprajapati\">Sagar Prajapati</a>, <a href=\"https://profiles.wordpress.org/samikeijonen\">Sami Keijonen</a>, <a href=\"https://profiles.wordpress.org/smyoon315\">Sang-Min Yoon</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/scottmweaver\">Scott Weaver</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sergioestevao\">SergioEstevao</a>, <a href=\"https://profiles.wordpress.org/azchughtai\">Shahjehan Ali</a>, <a href=\"https://profiles.wordpress.org/shaileesheth\">Shailee Sheth</a>, <a href=\"https://profiles.wordpress.org/sharaz\">Sharaz Shahid</a>, <a href=\"https://profiles.wordpress.org/giventofly76\">Shaun sc</a>, <a href=\"https://profiles.wordpress.org/shaunandrews\">shaunandrews</a>, <a href=\"https://profiles.wordpress.org/shooper\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/shenkj\">shenkj</a>, <a href=\"https://profiles.wordpress.org/sikander\">sikander</a>, <a href=\"https://profiles.wordpress.org/pross\">Simon Prosser</a>, <a href=\"https://profiles.wordpress.org/siriokun\">siriokun</a>, <a href=\"https://profiles.wordpress.org/sirjonathan\">sirjonathan</a>, <a href=\"https://profiles.wordpress.org/sirreal\">sirreal</a>, <a href=\"https://profiles.wordpress.org/sisanu\">Sisanu</a>, <a href=\"https://profiles.wordpress.org/skorasaurus\">skorasaurus</a>, <a href=\"https://profiles.wordpress.org/butimnoexpert\">Slushman</a>, <a href=\"https://profiles.wordpress.org/ssousa\">Sofia Sousa</a>, <a href=\"https://profiles.wordpress.org/somtijds\">SOMTIJDS</a>, <a href=\"https://profiles.wordpress.org/soean\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/spocke\">spocke</a>, <a href=\"https://profiles.wordpress.org/stagger-lee\">Stagger Lee</a>, <a href=\"https://profiles.wordpress.org/sstoqnov\">Stanimir Stoyanov</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevehenty\">Steve Henty</a>, <a href=\"https://profiles.wordpress.org/charlestonsw\">Store Locator Plus</a>, <a href=\"https://profiles.wordpress.org/strategio\">strategio</a>, <a href=\"https://profiles.wordpress.org/stuartfeldt\">stuartfeldt</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/tacrapo\">tacrapo</a>, <a href=\"https://profiles.wordpress.org/talldan\">talldan</a>, <a href=\"https://profiles.wordpress.org/tammie_l\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/themeroots\">ThemeRoots</a>, <a href=\"https://profiles.wordpress.org/tfrommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/hedgefield\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/timgardner\">timgardner</a>, <a href=\"https://profiles.wordpress.org/timmydcrawford\">Timmy Crawford</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tjnowell\">Tom J Nowell</a>, <a href=\"https://profiles.wordpress.org/tlxo\">Toni Laakso</a>, <a href=\"https://profiles.wordpress.org/skithund\">Toni Viemer&#246;</a>, <a href=\"https://profiles.wordpress.org/tobifjellner\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/toro_unit\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/torontodigits\">TorontoDigits</a>, <a href=\"https://profiles.wordpress.org/mirucon\">Toshihiro Kanai</a>, <a href=\"https://profiles.wordpress.org/itowhid06\">Towhidul Islam</a>, <a href=\"https://profiles.wordpress.org/travislopes\">Travis Lopes</a>, <a href=\"https://profiles.wordpress.org/truongwp\">truongwp</a>, <a href=\"https://profiles.wordpress.org/tjfunke001\">Tunji Ayoola</a>, <a href=\"https://profiles.wordpress.org/twoelevenjay\">twoelevenjay</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/vishalkakadiya\">Vishal Kakadiya</a>, <a href=\"https://profiles.wordpress.org/vtrpldn\">Vitor Paladini</a>, <a href=\"https://profiles.wordpress.org/volodymyrkolesnykov\">volodymyrkolesnykov</a>, <a href=\"https://profiles.wordpress.org/walterebert\">Walter Ebert</a>, <a href=\"https://profiles.wordpress.org/warmarks\">warmarks</a>, <a href=\"https://profiles.wordpress.org/webmandesign\">WebMan Design &#124; Oliver Juhas</a>, <a href=\"https://profiles.wordpress.org/websupporter\">websupporter</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton\">williampatton</a>, <a href=\"https://profiles.wordpress.org/willybahuaud\">Willy Bahuaud</a>, <a href=\"https://profiles.wordpress.org/yahil\">Yahil Madakiya</a>, <a href=\"https://profiles.wordpress.org/yingles\">yingles</a>, <a href=\"https://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/fierevere\">Yui</a>, <a href=\"https://profiles.wordpress.org/youthkee\">Yusuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/ze3kr\">ze3kr</a>, <a href=\"https://profiles.wordpress.org/zebulan\">zebulan</a>, <a href=\"https://profiles.wordpress.org/ziyaddin\">Ziyaddin Sadigov</a>, and <a href=\"https://profiles.wordpress.org/mypacecreator\">のむらけい (Kei Nomura)</a>.\n\n\n\n<p>Finally, thanks to all the community translators who worked on WordPress 5.0. Their efforts bring WordPress 5.0 fully translated to 37 languages at release time, with more on the way.</p>\n\n\n\n<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>\n\n\n\n<p>Thanks for choosing WordPress!</p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6328\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordPress 5.0 RC3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/2018/12/wordpress-5-0-rc3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Dec 2018 07:07:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6322\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:388:\"The third release candidate for WordPress 5.0 is now available! WordPress 5.0 will be released on December 6, 2018. This is a big release and needs&#160;your&#160;help—if you haven’t tried 5.0 yet, now is the time! To test WordPress 5.0, you can use the&#160;WordPress Beta Tester&#160;plugin or you can&#160;download the release candidate here&#160;(zip). For details about [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2791:\"\n<p>The third release candidate for WordPress 5.0 is now available!</p>\n\n\n\n<p><strong>WordPress 5.0 will be released on </strong><a href=\"https://make.wordpress.org/core/2018/12/04/new-5-0-target-date/\"><strong>December 6, 2018</strong></a>. This is a big release and needs&nbsp;<em>your</em>&nbsp;help—if you haven’t tried 5.0 yet, now is the time!</p>\n\n\n\n<p>To test WordPress 5.0, you can use the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-RC3.zip\">download the release candidate here</a>&nbsp;(zip).</p>\n\n\n\n<p>For details about what to expect in WordPress 5.0, please see the&nbsp;<a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-release-candidate/\">first release candidate post</a>.</p>\n\n\n\n<p>This release candidate includes a fix for some scripts not loading on subdirectory installs (<a href=\"https://core.trac.wordpress.org/ticket/45469\">#45469</a>), and user locale settings not being loaded in the block editor (<a href=\"https://core.trac.wordpress.org/ticket/45465\">#45465</a>). Twenty Nineteen has also had a couple of minor tweaks.</p>\n\n\n\n<h2>Plugin and Theme Developers</h2>\n\n\n\n<p>Please test your plugins and themes against WordPress 5.0 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme to 5.0. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>&nbsp;so we can figure those out before the final release. An in-depth field guide to developer-focused changes is coming soon on the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>. In the meantime, you can review the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5.0+dev-notes/\">developer notes for 5.0</a>.</p>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p>If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<p><em>WordPress Five Point Oh<br>Is just a few days away!<br>Nearly party time!</em> <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6322\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:33:\"\n		\n		\n		\n		\n				\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"The Month in WordPress: November 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2018/12/the-month-in-wordpress-november-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Dec 2018 17:43:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6318\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:345:\"WordPress 5.0 is almost ready for release, including an all-new content editing experience. Volunteers all across the project are gearing up for the launch and making sure everything is ready. Read on to find out what&#8217;s been happening and how you can get involved. WordPress 5.0 Close to Launch The release date for WordPress 5.0 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6593:\"\n<p>WordPress 5.0 is almost ready for release, including an all-new content editing experience. Volunteers all across the project are gearing up for the launch and making sure everything is ready. Read on to find out what&#8217;s been happening and how you can get involved.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>WordPress 5.0 Close to Launch</h2>\n\n\n\n<p>The release date for WordPress 5.0 has not yet been set, but the second release candidate (RC) <a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-rc2/\">is now available</a>. The final release date will be determined based on feedback and testing of this RC. The Core development team has been posting <a href=\"https://make.wordpress.org/core/2018/12/03/5-0-gutenberg-status-update-dec-3/\">daily updates</a> on the progress of their work on v5.0, with the number of open issues for this release decreasing every day.<br></p>\n\n\n\n<p>The primary feature of this release is <a href=\"https://wordpress.org/gutenberg/\">the new editor</a> that will become the default WordPress experience going forward. A number of people have been seeking more direct feedback from the release leads about the progress of this release, which <a href=\'https://profiles.wordpress.org/matt/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>matt</a> has facilitated by hosting <a href=\"https://make.wordpress.org/core/2018/11/29/gutenberg-5-0-listening-office-hours/\">one-to-one discussions</a> with anyone in the community who wanted to talk with him about it. He has also published <a href=\"https://ma.tt/2018/11/a-gutenberg-faq/\">an extended FAQ</a> covering many of the questions people have been asking.<br></p>\n\n\n\n<p>Alongside the development of the new editor, the Mobile team has been working hard to bring the WordPress mobile apps up to speed. They plan to make a beta version available <a href=\"https://make.wordpress.org/mobile/2018/11/15/gutenberg-in-the-apps-what-to-expect/\">in February 2019</a>.<br></p>\n\n\n\n<p>Want to get involved in developing WordPress Core in 5.0 and beyond? Follow <a href=\"https://make.wordpress.org/core\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<h2>New WordPress Support Platform Goes Live</h2>\n\n\n\n<p>WordPress user documentation has long been hosted on the <a href=\"https://codex.wordpress.org/\">WordPress Codex</a>, but for the past couple of years an ambitious project has been underway to move that content to a freshly-built WordPress-based platform. This project, named “HelpHub,” is now live and <a href=\"https://wordpress.org/support/\">the official home of WordPress Support</a>.<br></p>\n\n\n\n<p>There is still plenty of content that needs to be migrated from the Codex to HelpHub, but the initial move is done and the platform is ready to have all WordPress’ user documentation moved across. HelpHub will be the first place for support, encouraging users to find solutions for themselves before posting in the <a href=\"https://wordpress.org/support/forums/\">forums</a>.<br></p>\n\n\n\n<p>Want to get involved in populating HelpHub with content, or with its future development? Follow <a href=\"https://make.wordpress.org/docs/\">the Documentation team blog</a> and join the #docs channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<h2>Spanish WordPress Community Pushes Translations Forward</h2>\n\n\n\n<p>The WordPress community in Spain has been hard at work making sure as much of the WordPress project as possible is available in Spanish. <a href=\"https://es.wordpress.org/2018/11/07/logros-equipo-traducciones-wordpress-espana/\">They have recently translated more of the project than ever</a> — including WordPress Core, WordPress.org, the mobile apps and the top 120 plugins in the Directory.<br></p>\n\n\n\n<p>This achievement has largely been possible due to the fact that <a href=\"https://make.wordpress.org/polyglots/teams/?locale=es_ES\">the Spanish translation team</a> has over 2,500 individuals contributing to it, making it the largest translation team across the whole project. <br></p>\n\n\n\n<p>Want to get involved in translating WordPress into your local language? You can <a href=\"https://translate.wordpress.org/\">jump straight into translations</a>, follow <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team blog</a> and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>Further Reading:</h2>\n\n\n\n<ul><li>All volunteer teams have checked in with their <a href=\"https://wordpress.org/news/2018/11/quarterly-updates-q3-2018/\">latest quarterly updates</a>.</li><li>The WordPress Support Team <a href=\"https://make.wordpress.org/support/2018/11/new-volunteer-orientation-for-wp-support-contributors-dec-9/\">is hosting an orientation</a> for new Support volunteers on December 9.</li><li><a href=\"https://2018.us.wordcamp.org/tickets/\">Tickets are now available</a> to watch the WordCamp US livestream for free.</li><li>WordPress Core <a href=\"https://core.trac.wordpress.org/ticket/45287\">has switched to a WP-CLI command</a> for generating localization files.</li><li>WordPress Coding Standards v1.2.0 <a href=\"https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/releases/tag/1.2.0\">has been released</a> with some really useful improvements.</li><li>The first ever <a href=\"https://2019.nordic.wordcamp.org/\">WordCamp Nordic</a> is taking place on March 7-8, 2019 with ticket sales now open.</li><li>The WordCamp Incubator program is going very well this year — <a href=\"https://make.wordpress.org/community/2018/11/27/wordcamp-incubator-2018-update-thread-november-edition/\">you can see the latest updates here</a>.</li><li>The Mobile Team is looking for testers for the upcoming v11.3 release of the WordPress mobile apps on <a href=\"https://make.wordpress.org/mobile/2018/11/21/call-for-testing-wordpress-for-android-11-3/\">Android</a> and <a href=\"https://make.wordpress.org/mobile/2018/11/21/call-for-testing-wordpress-for-ios-11-3/\">iOS</a>.</li><li>The WordCamp Europe team is looking for local communities to <a href=\"https://2019.europe.wordcamp.org/2018/11/29/call-for-host-city/\">apply to be the host city</a> for the 2020 event.</li></ul>\n\n\n\n<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em><br></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6318\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordPress 5.0 RC2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/2018/11/wordpress-5-0-rc2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Nov 2018 23:16:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6287\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:332:\"The second release candidate for WordPress 5.0 is now available! This is an important milestone, as we near the release of WordPress 5.0. A final release date will be announced soon, based on feedback from this release candidate. Things are appearing very stable and we hope to announce a date soon. This is a big release [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3296:\"\n<p>The second release candidate for WordPress 5.0 is now available!</p>\n\n\n\n<p>This is an important milestone, as we near the release of WordPress 5.0. A final release date will be announced soon, based on feedback from this release candidate. Things are appearing very stable and we hope to announce a date soon. This is a big release and needs <em>your</em> help—if you haven’t tried 5.0 yet, now is the time! </p>\n\n\n\n<p>To test WordPress 5.0, you can use the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-RC2.zip\">download the release candidate here</a>&nbsp;(zip).</p>\n\n\n\n<p>For details about what to expect in WordPress 5.0, please see the <a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-release-candidate/\">previous release candidate post</a>.</p>\n\n\n\n<h2>Significant changes</h2>\n\n\n\n<ul><li>We stopped rendering&nbsp;<em>AdminNotices</em>&nbsp;compatibility component, as this previous attempt at backward compatibility was bringing in numerous incompatible banners and notices from plugins.</li><li>An update to the parser to better deal with malformed HTML that could cause a loop. We&#8217;re only aware of this in the wild being triggered once in the <a href=\"https://gutenstats.blog/\">over a million posts</a> made with Gutenberg, but it caused a loop so we wanted to fix for RC2.</li></ul>\n\n\n\n<h2>Cosmetic and minor changes in RC2</h2>\n\n\n\n<ul><li>Accessibility: Simplify sidebar tabs&nbsp;aria-labels.</li><li>Make the&nbsp;Image&nbsp;Link URL field readonly.</li><li>Internationalization: Merge&nbsp;similar text strings that differed only in capitalization.</li><li>CSS: Improve block preview&nbsp;styling.</li><li>CSS: Fix&nbsp;visual issues&nbsp;with&nbsp;Button&nbsp;block text wrap.</li><li>Fix&nbsp;getSelectedBlockClientId selector.</li><li>Fix&nbsp;Classic&nbsp;block&nbsp;not showing galleries on a grid.</li><li>Fix an issue where the block toolbar&nbsp;would cause an image to jump&nbsp;downwards when the&nbsp;<em>wide</em>&nbsp;or&nbsp;<em>full</em>&nbsp;alignments were activated.</li><li>Move editor specific styles&nbsp;from style.scss to editor.scss in&nbsp;Cover&nbsp;block.</li><li>Fix modals&nbsp;in Microsoft Edge browser.</li><li>Fix Microsoft IE11 focus loss&nbsp;after TinyMCE init.&nbsp;Add&nbsp;IE check.</li><li>Fix Microsoft IE11 input when mounting TinyMCE.</li><li>Change @package names&nbsp;to WordPress.</li></ul>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<pre class=\"wp-block-verse\"><em>RC bittersweet.<br>We welcome in Gutenberg,<br>Vale Gutenbeard.</em></pre>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6287\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 5.0 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2018/11/wordpress-5-0-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 23 Nov 2018 09:46:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6257\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:323:\"The first release candidate for WordPress 5.0 is now available! This is an important milestone, as we near the release of WordPress 5.0.&#160;The WordPress 5.0 release date has shifted from the 27th to give more time for the RC to be fully tested. A final release date will be announced soon, based on feedback on [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matias Ventura\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6009:\"\n<p>The first release candidate for WordPress 5.0 is now available!</p>\n\n\n\n<p>This is an important milestone, as we near the release of WordPress 5.0.&nbsp;<strong>The WordPress 5.0 release date has shifted from the 27th to give more time for the RC to be fully tested</strong>. A final release date will be announced soon, based on feedback on the RC. This is a big release and needs <em>your</em> help—if you haven’t tried 5.0 yet, now is the time!&nbsp;</p>\n\n\n\n<p>To test WordPress 5.0, you can use the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-RC1.zip\">download the release candidate here</a>&nbsp;(zip).</p>\n\n\n\n<h2>What&#8217;s in WordPress 5.0?</h2>\n\n\n\n<figure class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?resize=632%2C316&#038;ssl=1\" alt=\"Screenshot of the new block editor interface.\" class=\"wp-image-6271\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?resize=1024%2C512&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?resize=300%2C150&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?resize=768%2C384&amp;ssl=1 768w, https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?w=1264&amp;ssl=1 1264w, https://i1.wp.com/wordpress.org/news/files/2018/11/Gutenberg-3.png?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /><figcaption>The new block-based post editor.</figcaption></figure>\n\n\n\n<p>WordPress 5.0 introduces the <a href=\"https://wordpress.org/gutenberg/\">new block-based post editor</a>. This is the first step toward an exciting new future with a streamlined editing experience across your site. You’ll have more flexibility with how content is displayed, whether you are building your first site, revamping your blog, or write code for a living.</p>\n\n\n\n<p>The block editor is&nbsp;<a href=\"https://gutenstats.blog/\">used on over a million sites</a>, we think it&#8217;s ready to be used on all WordPress sites. We do understand that some sites might need some extra time, though. If that&#8217;s you, please install the <a href=\"https://wordpress.org/plugins/classic-editor/\">Classic Editor plugin</a>, you&#8217;ll continue to use the classic post editor when you upgrade to WordPress 5.0.</p>\n\n\n\n<p>Twenty Nineteen is WordPress&#8217; new default theme, it&nbsp;features custom styles for the blocks available by default in 5.0.&nbsp;Twenty Nineteen is designed to work for a wide variety of use cases. Whether you’re running a photo blog, launching a new business, or supporting a non-profit, Twenty Nineteen is flexible enough to fit your needs.</p>\n\n\n\n<p>The block editor is a big change, but that&#8217;s not all. We&#8217;ve made some smaller changes as well,&nbsp; including:</p>\n\n\n\n<ul><li>All of the previous default themes, from Twenty Ten through to Twenty Seventeen, have been updated to support the block editor.</li><li>You can improve the accessibility of the content you write, now that <a href=\"https://core.trac.wordpress.org/ticket/30421\">simple ARIA labels</a>&nbsp;can be saved in posts and pages.</li><li>WordPress 5.0 officially supports the upcoming PHP 7.3 release: if you&#8217;re using an older version, we encourage you to <a href=\"https://wordpress.org/support/upgrade-php/\">upgrade PHP</a>&nbsp;on your site.</li><li>Developers can now add translatable strings directly to your JavaScript code, using the new <a href=\"https://make.wordpress.org/core/2018/11/09/new-javascript-i18n-support-in-wordpress/\">JavaScript language packs</a>.</li></ul>\n\n\n\n<p>You can read more about the fixes and changes since  Beta 5 <a href=\"https://make.wordpress.org/core/2018/11/20/whats-new-in-gutenberg-20th-november/\">in the last update post</a>.</p>\n\n\n\n<p>For more details about what’s new in version 5.0, check out the&nbsp;<a href=\"https://wordpress.org/news/2018/10/wordpress-5-0-beta-1/\">Beta 1</a>,&nbsp;<a href=\"https://wordpress.org/news/2018/10/wordpress-5-0-beta-2/\">Beta 2</a>,&nbsp;<a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-beta-3/\">Beta 3</a>, <a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-beta-4/\">Beta 4</a> and&nbsp;<a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-beta-5/\">Beta 5</a>&nbsp;blog posts.</p>\n\n\n\n<h2>Plugin and Theme Developers</h2>\n\n\n\n<p>Please test your plugins and themes against WordPress 5.0 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme to 5.0. If you find compatibility problems, please be sure to post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a> so we can figure those out before the final release. An in-depth field guide to developer-focused changes is coming soon on the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>. In the meantime, you can review the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5.0+dev-notes/\">developer notes for 5.0</a>.</p>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p><strong><em>If you think you’ve found a bug</em></strong><em>, you can post to the&nbsp;</em><a href=\"https://wordpress.org/support/forum/alphabeta\"><em>Alpha/Beta area</em></a><em>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;</em><a href=\"https://make.wordpress.org/core/reports/\"><em>file one on WordPress Trac</em></a><em>, where you can also find&nbsp;</em><a href=\"https://core.trac.wordpress.org/tickets/major\"><em>a list of known bugs</em></a><em>.</em></p>\n\n\n\n<p style=\"background-color:#f9f4e8\" class=\"has-background has-medium-font-size\"><em>Ruedan los bloques<br>Contando vivos cuentos<br>Que se despiertan</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6257\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.0 Beta 5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2018/11/wordpress-5-0-beta-5/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 16 Nov 2018 01:09:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6250\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:360:\"WordPress 5.0 Beta 5 is now available! This software is still in development,&#160;so we don’t recommend you run it on a production site. Consider setting up a test site to play with the new version. There are two ways to test this WordPress 5.0 Beta: try the&#160;WordPress Beta Tester&#160;plugin (you’ll want “bleeding edge nightlies”), or [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Jonathan Desrosiers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4738:\"\n<p>WordPress 5.0 Beta 5 is now available!</p>\n\n\n\n<p><strong>This software is still in development,</strong>&nbsp;so we don’t recommend you run it on a production site. Consider setting up a test site to play with the new version.</p>\n\n\n\n<p>There are two ways to test this WordPress 5.0 Beta: try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (you’ll want “bleeding edge nightlies”), or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-beta5.zip\">download the beta here</a>&nbsp;(zip).</p>\n\n\n\n<p><strong>Reminder: the WordPress 5.0 release date has changed</strong>. It is now scheduled for release on&nbsp;<a href=\"https://make.wordpress.org/core/5-0/\">November 27</a>, and we need your help to get there. Here are some of the big issues that we’ve fixed since Beta 4:</p>\n\n\n\n<h2>Block Editor</h2>\n\n\n\n<p>The block editor has been updated to match the <a href=\"https://make.wordpress.org/core/2018/11/15/whats-new-in-gutenberg-15th-november-2/\">Gutenberg 4.4 release</a>, the major changes  include:</p>\n\n\n\n<ul><li>&nbsp;A <a href=\"https://github.com/WordPress/gutenberg/pull/11874\">permalink panel has been added to the document sidebar</a> to make it easier to find.</li><li>Editor document panels can now be <a href=\"https://github.com/WordPress/gutenberg/pull/11802\">programmatically removed</a>.</li><li>The uploading indicator for images and galleries has been replaced with a&nbsp;<a href=\"https://github.com/WordPress/gutenberg/pull/11876\">spinner and faded out image</a>.</li><li>The text and code editing blocks will now <a href=\"https://github.com/WordPress/gutenberg/pull/11750\">use the full width of the editor</a>.</li><li>Image handling has been improved. Images now  take up the right amount of space for <a href=\"https://github.com/WordPress/gutenberg/pull/11846\">themes with wider editors</a> (like Twenty Nineteen).<br></li><li>Hover styles are now <a href=\"https://github.com/WordPress/gutenberg/pull/10333\">correctly disabled for mobile devices</a>.</li><li>The i18n module has been refactored to benefit from <a href=\"https://github.com/WordPress/gutenberg/pull/11493\">significant performance gains</a>.</li></ul>\n\n\n\n<p>Additionally, there have been some pesky bugs fixed:</p>\n\n\n\n<ul><li>Better handling for <a href=\"https://github.com/WordPress/gutenberg/pull/11590\">links without an href</a> attribute, which were showing as <code>undefined</code>.</li><li>Japanese text (double byte characters) are <a href=\"https://github.com/WordPress/gutenberg/pull/11908\">now usable in the list block</a>.</li><li>Better handling for different text encodings (e.g. emoji) within a block <a href=\"https://github.com/WordPress/gutenberg/pull/11771\">in block validation</a>.</li></ul>\n\n\n\n<p>A full list of changes can be found in the <a href=\"https://make.wordpress.org/core/2018/11/15/whats-new-in-gutenberg-15th-november-2/\">Gutenberg 4.4 release post</a>.<br></p>\n\n\n\n<h2>PHP 7.3 Support</h2>\n\n\n\n<p>The final known PHP 7.3 compatibility issue has been fixed. You can brush up on what you need to know about PHP 7.3 and WordPress by checking out the <a href=\"https://make.wordpress.org/core/2018/10/15/wordpress-and-php-7-3/\">developer note on the Make WordPress Core blog</a>.<br></p>\n\n\n\n<h2>Twenty Nineteen</h2>\n\n\n\n<p>Work on making Twenty Nineteen ready for prime time continues on its <a href=\"https://github.com/WordPress/twentynineteen\">GitHub repository</a>. This update includes <a href=\"https://core.trac.wordpress.org/changeset/43904\">a host of tweaks and bug fixes</a>, including:</p>\n\n\n\n<ul><li>Add <code>.button</code> class support.</li><li>Fix editor font-weights for headings.</li><li>Improve support for sticky toolbars in the editor.</li><li>Improve text-selection custom colors for better contrast and legibility.</li><li>Fix editor to prevent Gutenberg&#8217;s meta boxes area from overlapping the content.</li></ul>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p><strong><em>If you think you’ve found a bug</em></strong><em>, you can post to the&nbsp;</em><a href=\"https://wordpress.org/support/forum/alphabeta\"><em>Alpha/Beta area</em></a><em>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;</em><a href=\"https://make.wordpress.org/core/reports/\"><em>file one on WordPress Trac</em></a><em>, where you can also find&nbsp;</em><a href=\"https://core.trac.wordpress.org/tickets/major\"><em>a list of known bugs</em></a><em>.</em></p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<p></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6250\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.0 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2018/11/wordpress-5-0-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 13 Nov 2018 01:27:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6241\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:359:\"WordPress 5.0 Beta 4 is now available! This software is still in development,&#160;so we don’t recommend you run it on a production site. Consider setting up a test site to play with the new version. There are two ways to test the WordPress 5.0 Beta: try the&#160;WordPress Beta Tester&#160;plugin (you’ll want “bleeding edge nightlies”), or [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3700:\"\n<p>WordPress 5.0 Beta 4 is now available!</p>\n\n\n\n<p><strong>This software is still in development,</strong>&nbsp;so we don’t recommend you run it on a production site. Consider setting up a test site to play with the new version.</p>\n\n\n\n<p>There are two ways to test the WordPress 5.0 Beta: try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (you’ll want “bleeding edge nightlies”), or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-beta4.zip\">download the beta here</a>&nbsp;(zip).</p>\n\n\n\n<p><strong>The WordPress 5.0 release date has changed</strong>, it is now scheduled for release on&nbsp;<a href=\"https://make.wordpress.org/core/5-0/\">November 27</a>, and we need your help to get there. Here are some of the big issues that we’ve fixed since Beta 3:</p>\n\n\n\n<h2>Block Editor</h2>\n\n\n\n<p>The block editor has been updated to match the <a href=\"https://make.wordpress.org/core/2018/11/12/whats-new-in-gutenberg-12th-november/\">Gutenberg 4.3 release</a>, the major changes  include:</p>\n\n\n\n<ul><li>An <a href=\"https://github.com/WordPress/gutenberg/pull/7718\">Annotations API</a>, allowing plugins to add  contextual data as you write.</li><li>More consistent keyboard navigation between blocks, as well as back-and-forth between different areas of the interface.</li><li>Improved accessibility, with additional  labelling and speech announcements.</li></ul>\n\n\n\n<p>Additionally, there have been some bugs fixed that popped up in beta 3:</p>\n\n\n\n<ul><li>Better support for plugins that have more advanced meta box usage.</li><li>Script concatenation is now supported.</li><li>Ajax calls could occasionally cause PHP errors.</li></ul>\n\n\n\n<h2>Internationalisation</h2>\n\n\n\n<p>We&#8217;ve added an API for translating your plugin and theme strings in JavaScript files! The block editor is now using this, and you can start using it, too. Check out the <a href=\"https://make.wordpress.org/core/2018/11/09/new-javascript-i18n-support-in-wordpress/\">developer note</a>&nbsp;to get started.</p>\n\n\n\n<h2>Twenty Nineteen</h2>\n\n\n\n<p>Twenty Nineteen is being polished over on its <a href=\"https://github.com/WordPress/twentynineteen\">GitHub repository</a>. This update includes <a href=\"https://core.trac.wordpress.org/changeset/43892\">a host of tweaks and bug fixes</a>, including:</p>\n\n\n\n<ul><li>Menus now  properly support keyboard and touch interactions.</li><li>A footer menu has been added for secondary page links.</li><li>Improved backwards compatibility with older versions of WordPress.</li></ul>\n\n\n\n<h2>Default Themes</h2>\n\n\n\n<p>All of the older default themes—from Twenty Ten through to Twenty Seventeen—have polished  styling in the block editor.</p>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p><strong><em>If you think you’ve found a bug</em></strong><em>, you can post to the&nbsp;</em><a href=\"https://wordpress.org/support/forum/alphabeta\"><em>Alpha/Beta area</em></a><em>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;</em><a href=\"https://make.wordpress.org/core/reports/\"><em>file one on WordPress Trac</em></a><em>, where you can also find&nbsp;</em><a href=\"https://core.trac.wordpress.org/tickets/major\"><em>a list of known bugs</em></a><em>.</em></p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<p><em>International-<br>isation is a word with<br>many syllables.</em></p>\n\n\n\n<p><em>Meta boxes are<br>the original style block.<br>Old is new again.</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6241\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sun, 06 Jan 2019 20:01:48 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Wed, 19 Dec 2018 23:49:49 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(140, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1546848109', 'no'),
(141, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1546804909', 'no'),
(142, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1546848110', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(143, '_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9', 'a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"\n\n\n\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"\n	\n	\n	\n	\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"WPTavern: Beaver Builder Doubles Down on Serving Power Users in Response to Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86569\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"https://wptavern.com/beaver-builder-doubles-down-on-serving-power-users-in-response-to-gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3074:\"<p>At WordCamp US I had the opportunity to chat with <a href=\"https://www.wpbeaverbuilder.com/\">Beaver Builder</a> co-founder Robby McCullough about how the page builder is navigating the Gutenberg era. The proliferation of blocks for the new editor has made it easy for non-technical WordPress users to add things like pricing tables, maps, tabs, accordions, and other UI elements. Future iterations of Gutenberg will soon tackle layouts. These improvements to core will radically change how page builder products are marketed to WordPress users.</p>\n\n\n\n<p>&#8220;One of the decisions we made in response to the news of Gutenberg early on is that we wanted to double down on our professional power users,&#8221; McCullough said. &#8220;It took us a long time in our growth as a business to figure out who our customers were. We realized there were two distinct camps: one that was like a do-it-yourselfer type, someone who maybe had a small business or a hobby website who wanted to use WordPress but wasn&#8217;t familiar with writing code. The other was more of a freelancer &#8211; maybe a one or two person agency, people who were building lots of websites and had development and frontend skills. We see that as the space where we want to live now. We&#8217;re hoping to continue solving problems and making the experience better for folks with a few more skills in their tool belts.&#8221;</p>\n\n\n\n<p>Following up with McCullough later, he said that applying this new direction to Beaver Builder is already translating into the features they are prioritizing for the plugin.</p>\n\n\n\n<p>&#8220;For example, in our latest major release, we added percent, em, rem, and viewport-based units for things like font sizes, margins, and padding,&#8221; McCullough said. &#8220;Without a basic understanding of CSS, this feature wouldn&#8217;t be too helpful. We also added dozens of pre-built row templates. So, instead of creating single-page designs, our goal was to create a modular system of rows that can be mixed and matched to build out sites. We&#8217;re working to build features that better enable folks who build lots of websites.&#8221;</p>\n\n\n\n<p>In the interview below we discussed the current integration between Gutenberg and Beaver Builder. McCullough said his team is considering bringing blocks into Beaver Builder or bringing Beaver Builder content into Gutenberg; both are possibilities. His team has been waiting to see how quickly the community adopts Gutenberg before making any major decisions.</p>\n\n\n\n<p>&#8220;My hope is that there&#8217;s still going to be a place for page builders, Beaver Builder and everyone in this space, to have a little bit more agility,&#8221; McCullough said. &#8220;We can see Gutenberg kind of be like Instagram in that it&#8217;s going to appeal to a mass audience. We like to live in the Photoshop space where you&#8217;re going to get a lot of fine-tuned controls, solving problems and creating features that are going to help people build websites every day.&#8221;</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Jan 2019 20:20:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: WP Storybook: A Handy Reference for WordPress React UI Components\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86604\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"https://wptavern.com/wp-storybook-a-handy-reference-for-wordpress-react-ui-components\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1553:\"<p><a href=\"https://lubus.in/\">LUBUS</a>, a web design agency in Mumbai, has published a site called <a href=\"https://wp-storybook.netlify.com/\">WP Storybook</a> that offers an interactive way to explore various WordPress React components. It allows developers to browse and search UI components and see a live preview of the component next to example source code. </p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n<a href=\"https://cloudup.com/cpA4-xaPukn\"><img src=\"https://i0.wp.com/cldup.com/yCZSRiLkVv.gif?resize=627%2C297&ssl=1\" alt=\"Wp storybook\" width=\"627\" height=\"297\" /></a>\n</div>\n\n\n\n<p>WP Storybook lets you view different states for various UI components and even test them on different viewports. The development team at LUBUS is adding more as they discover them while building projects with Gutenberg using reusable components. Their goal in publishing the project is to help developers work faster by making components easier to discover and reference.</p>\n\n\n\n<p>LUBUS&#8217; roadmap for WP Storybook includes the following:</p>\n\n\n\n<ul><li>Add as many possible components and cases as possible</li><li>Capability to view and copy the example source</li><li>Playground to test out various props and options using knobs addon</li><li>Categorize components into groups for better discoverability</li><li>Recipe stories showcasing composing of various components</li></ul>\n\n\n\n<p>If you want to contribute to WP Storybook or log an issue, the code is open source (MIT license) on <a href=\"https://github.com/lubusIN/wp-storybook\">GitHub</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jan 2019 23:51:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: WordPress.com Launches New “Do Anything” Marketing Campaign\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86590\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wptavern.com/wordpress-com-launches-new-do-anything-marketing-campaign\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4698:\"<img />Hilde Lysiak reports on local news in her community on her WordPress.com-powered <a href=\"https://orangestreetnews.com/\" target=\"_blank\" rel=\"noreferrer noopener\">Orange Street News</a> website\n\n\n\n<p>WordPress.com is kicking off 2019 with a new national marketing campaign that features 14 entrepreneurs, writers, and non-profit organizations who are using the platform to make a big difference for their communities. The campaign is focused around the question: &#8220;What Would You Do If You Could Do Anything?&#8221; </p>\n\n\n\n<p>WordPress.com published its inaugural <a href=\"https://en.blog.wordpress.com/2019/01/03/introducing-the-2019-anything-is-possible-list/\">‘Anything Is Possible’ List</a>, which includes 10 mini-documentaries ranging from 1 minute to 1:44. A few of the stories highlighted include Congolese-American sisters operating a successful hair salon in NYC, a 12-year-old journalist running her own online publication, a blogger who went viral and published her own book, and a non-profit fighting misinformation and extremist narratives. Each is presented more in depth on a new <a href=\"https://wordpress.com/do-anything/\">Do Anything</a> campaign site that was launched today.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<p>Do Anything is WordPress.com&#8217;s first large-scale national brand campaign. It will debut TV, print, and digital advertising spots in The New Yorker and on TV networks, including The History Channel, CNN, and National Geographic. WordPress.com will also be running ads on podcasts, including The Daily and NPR. The new 30-second TV ad was created by <a href=\"http://interestingdevelopment.com/\" target=\"_blank\" rel=\"noreferrer noopener\">Interesting Development</a>, an agency based in New York.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<p>Much like gym memberships, WordPress.com tends to see more action at the beginning of a new year with 20% more sites are created in January than the average, according to Mark Armstrong at Automattic. The timing for the campaign is aimed at tapping into the motivation that millions of users have for starting a new business or blog at this time of year.</p>\n\n\n\n<p>In 2016, Automattic started <a href=\"https://ma.tt/2016/01/marketing-at-automattic/\">hiring for more marketing positions</a> as an answer to Wix, Weebly, Squarespace, Web.com, EIG, and Godaddy, competitors that Matt Mullenweg identified as having spent over $350M in advertising that year. In 2017, the company created <a href=\"https://design.blog/2017/05/18/how-a-detroit-hackathon-turned-into-wordpress-coms-first-ever-tv-spots/\">five commercials</a>, its first ever TV spots, as part of a series called &#8220;Free to be.&#8221; Many found the commercials to be confusing and the <a href=\"https://wptavern.com/wordpress-coms-tv-commercials-are-confusing\">messaging wasn&#8217;t clear</a>.</p>\n\n\n\n<p>By contrast, the 2019 &#8220;Do Anything&#8221; campaign is much better at demonstrating what people can do with WordPress.  &#8220;As we share new work with the world we realize that some things will hit and some things will miss,&#8221; Automattic’s SVP of Brand, Michelle Broderick said. The company has continued to evolve its marketing based on feedback. This particular campaign was directly inspired by the people who are making things happen with WordPress.</p>\n\n\n\n<p>&#8220;We were inspired by the people who use WordPress to imagine a better world,&#8221; Broderick said. &#8220;We saw everyone from bloggers to business owners to scientists to politicians using WordPress to share their story.&#8221;<br /></p>\n\n\n\n<p>The new TV spot is an improvement over previous campaigns in terms of communicating a clear message, but it doesn&#8217;t carry the same authenticity as the mini-documentaries. Each one is relatable and inspiring in telling the stories of people who have already answered the question &#8220;What would you do if you could do anything?&#8221; Many of those who were featured have carried on with their dreams through perseverance, despite tragedy and struggle along the way. The documentaries are more poignant than the TV spot, which has the added constraint of having to capture the viewer&#8217;s attention with a shorter amount of time. </p>\n\n\n\n<p>The &#8220;Do Anything&#8221; campaign as a whole is a good representation of the power of WordPress and should also help boost name recognition for the software in general. Broderick said Automattic is expecting tens of millions of impressions across TV, print, digital, and podcasts. The campaign is aimed at the American market but Armstrong said they hope to branch out into international markets in the future.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jan 2019 20:05:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"HeroPress: YOU Make The Difference\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2672\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"https://heropress.com/essays/you-make-the-difference/#utm_source=rss&utm_medium=rss&utm_campaign=you-make-the-difference\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10124:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/01/010219-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: WordPress still attracts the same types of people. Those who are brave, who are kind, who are looking to the future.\" /><blockquote><p>“A place is only as good as the people you know in it. It&#8217;s the people that make the place.”</p>\n<p>― Pittacus Lore, I Am Number Four</p></blockquote>\n<p>This quote is a large part of the space WordPress holds within me.</p>\n<p>Coming from a career in Civil Engineering and a background of Industrial Technology WordPress as a software drew me as a tool. It was a means to an end. I wasn’t blogging, I wasn’t looking to create an online voice, I was looking to build something and I needed a tool.</p>\n<p>I was good at learning software, had used over a dozen very complicated systems by that point in my life, so I found WordPress and started learning it too.</p>\n<p>A very melodramatic discovery story of WordPress for a HeroPress piece, I know.</p>\n<p>The truth is I probably wouldn’t have stuck around were it not for the people. The story has evolved for me over the years but that’s the beginning. The beginnings are usually far less romantic than the endings in any story.</p>\n<p>So why was I looking for a tool? Well, that’s a bit better of a story.</p>\n<h3>Looking For A Tool</h3>\n<p>I’ll prep you with the fact that I was driven, opinionated, blunt, and defensive. I had spent my college years and first years in my chosen career in a male-dominated industry. I learned how to navigate and thrive and took a job at a very large Engineering firm. About a year in I was granted a fantastic opportunity to work on a small startup team that was doing amazing work in 3D scanning.</p>\n<p>Being a startup team demanded that we produce more and more work to determine the viability of the investment the firm was making in my boss’s plans. As we worked on landing deals that required overnight travel and training that required days away it brought to the surface a reality that wasn’t so good for me. As the only woman on the team, I doubled the travel budget. They needed two of everything for me since I couldn’t bunk up with my male coworkers.</p>\n<p>The next months were a perfect storm of events. I made an opinionated comment to a division supervisor that was above my pay grade which enhanced my visibility as a problem. Then I got pregnant.</p>\n<blockquote><p>You can’t walk around 3D scanning a PVC manufacturing facility while with child. They also don’t make maternity coveralls.</p></blockquote>\n<p>I was officially dead weight. I lost the pregnancy and became depressed, anxious. It was easy for them to let me go then, I had stopped being productive. I found out a couple weeks after losing my job I was pregnant again. Talk about a whirlwind.</p>\n<p>My husband was in the process of changing careers from Retail to Healthcare and maternity leave is not something you like to bring up on an interview, so I decided to find something to do from home. I started a local family newsletter and decided to create an online marketplace for moms who craft out of their homes, like a local Etsy. This is where my search for a tool began.</p>\n<h3>Starting Again</h3>\n<p>A few months later, with no WordPress experience other than what I managed to rake together while I was learning and building, I got a job at WPMUDEV doing product support. I needed the extra cash so my other projects took a backseat and I was soon completely engulfed. Through that job, I came to learn about the ecosystem that was WordPress. I had no idea that there was a place that existed outside of the corporate universe that could exist without sexist politics, hierarchy, and status quo. It was mind-blowing.</p>\n<p>I was so hungry for people to interact with after being in such a team-oriented environment for so long. I loved working with others and I felt very alone until I found this great group of people. And oh what joy when I found it! I was a new mom at home with a baby trying to learn how to handle that new space in my life. My husband had completed a successful career change and we had moved. I had another baby. I met my friend Mason and we started a business together. I lost another pregnancy.</p>\n<blockquote><p>In the space of two short years, my life had completely turned upside down and landed me in the place that would help me survive it all.</p></blockquote>\n<p>You see, without the people, I wouldn’t have made it. I wouldn’t have been able to navigate the overwhelming waters that surrounded me outside of my day to day work. The people who befriended me, who were kind to me, who made jokes with me, who valued my contribution and intelligence without ever having set eyes on me, those were the people who kept me sane. They let me see I didn’t need to be defensive, that I didn’t have to be sorry about being opinionated, that I was different and that I should lean into that.</p>\n<p>When I left product support to work with Mason at, what was formerly called, WP Valet it was yet another major shift in my life. The product space was so different than the agency space and I quickly adapted to the new pace. There was a rush of excitement while learning new things and applying skills that had laid dormant for some time. My father was a Navy man and an entrepreneur and shaped so much of how I applied myself, now I was in a place to push myself even further and define my own path. I was spoiled by my first interactions at WP Valet with developers like Zé Fontainhas and Mario Peshev. The whole thing was thrilling!</p>\n<h3>And Then I Went To WordCamp</h3>\n<p>My first WordCamp was WordCamp Miami 2013. It was probably the first time I’d traveled alone in some time and I was meeting my work family for the first time. On top of that, I was in MIAMI, so it was bound to be a great trip. I got to meet David Bisset and Lisa Sabin Wilson that year, and so many other wonderful people. I was on cloud 9, each and every personality was inspiring to me, all so different than what my former colleagues and field specialists were like. To top it off I walked into my first talk at a WordCamp, Pippin Wilson was talking about how developers should share code. I was beside myself, sharing your code and supporting each other? Not cutthroat over projects and billable hours?! I was swooning over the idea of ‘community’ and what I had stumbled into.</p>\n<blockquote><p>Needless to say, I left 100% hooked on my path. WordPress was my life from that time on.</p></blockquote>\n<p>We as people have long-tailed stories that weave and zigzag and turn back on themselves. We are products of ALL the things going on in our lives at any given moment. Without the personal struggles and the professional push, I would not have been able to value the community as much as I do. The overlapping of personal and professional trials and successes are what gives depth to our experiences. Their overlapping is what colors the story of our lives.</p>\n<p>Fast forward a few years through a cross-state move, speaking selections, the birth of another child, a company expansion, another pregnancy loss, a company rebranding, a company restructuring, a return to school for Yoga training, and all the other things life throws in your path with family and work and here I sit typing my story at my counter while my middle child hums ‘Mamma Mia’ next to me. I am forever grateful for the life that I’ve been able to live through a whole new career in WordPress.</p>\n<h3>You Make The Difference</h3>\n<p>I am grateful for every soul I have met. I had the privilege to work with and become friendly with some of the nicest and most genuine people I will ever meet online and face to face. The ecosystem of WP has changed a lot over the years as most ecosystems do, but it still attracts the same types of people. Those who are brave, who are kind, who are looking to the future. My world is so much bigger because of all you. Thank You  <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>\n<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: YOU Make The Difference\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=YOU%20Make%20The%20Difference&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fyou-make-the-difference%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: YOU Make The Difference\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fyou-make-the-difference%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fyou-make-the-difference%2F&title=YOU+Make+The+Difference\" rel=\"nofollow\" target=\"_blank\" title=\"Share: YOU Make The Difference\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/you-make-the-difference/&media=https://heropress.com/wp-content/uploads/2020/01/010219-min-150x150.jpg&description=YOU Make The Difference\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: YOU Make The Difference\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/you-make-the-difference/\" title=\"YOU Make The Difference\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/you-make-the-difference/\">YOU Make The Difference</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 Jan 2019 20:15:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Kimberly Lipari\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"Matt: Democratize Publishing, Revisited\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48797\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://ma.tt/2018/12/democratize-publishing-revisited/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1674:\"<p>During my <a href=\"https://www.youtube.com/watch?v=v2aNNlC8TUE\">State of the Word Q&amp;A</a> I received some blogging homework from <a href=\"https://torumiki.com/\">Toru Miki</a>, a WordPress contributor based in Tokyo. He asked me to revisit the WordPress mission, “Democratize Publishing,” and reflect on what that mission means to me today. So here you go, Toru: <br /></p>\n\n\n\n<p>For many years, my definition of “Democratize Publishing” has been simply to help make the web a more open place. That foundation begins with the software itself, as outlined by the <a href=\"https://ma.tt/2014/01/four-freedoms/\">Four Freedoms</a>: <br /></p>\n\n\n\n<p>0. The freedom to run the program, for any purpose.</p>\n\n\n\n<p>1. The freedom to study how the program works, and change it so it does your computing as you wish.</p>\n\n\n\n<p>2. The freedom to redistribute copies so you can help your neighbor.</p>\n\n\n\n<p>3. The freedom to distribute copies of your modified versions, giving the community a chance to benefit from your changes.<br /></p>\n\n\n\n<p>In 2018, the mission of “Democratize Publishing” to me means that people of all backgrounds, interests, and abilities should be able to access Free-as-in-speech software that empowers them to express themselves on the open web and to own their content.<br /></p>\n\n\n\n<p>But as Toru noted in the original question, “Democratize Publishing” has come to mean many things to many people in the WordPress community. That’s one reason I like it. The WordPress mission is not just for one person to define. <br /></p>\n\n\n\n<p>So I’d like to ask everyone: What does “Democratize Publishing” mean to you? &nbsp;<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Dec 2018 00:06:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Matt: Sponcon Posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48788\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ma.tt/2018/12/sponcon-posts/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:422:\"<p>I found <a href=\"https://www.theatlantic.com/technology/archive/2018/12/influencers-are-faking-brand-deals/578401/\">this post by Taylor Lorenz</a> describing how aspiring influencers are posting fake, unpaid sponsored content to raise their status or hoping to nab a real sponsorship <a href=\"https://www.theatlantic.com/technology/archive/2018/12/influencers-are-faking-brand-deals/578401/\">is totally bananas</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 24 Dec 2018 16:08:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress Designers Explore Ideas for Moving Navigation to a Block Interface\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86518\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"https://wptavern.com/wordpress-designers-explore-ideas-for-moving-navigation-to-a-block-interface\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5176:\"<p>Creating a block for navigation menus is one of the <a href=\"https://make.wordpress.org/core/2018/12/08/9-priorities-for-2019/\">nine projects</a> Matt Mullenweg identified for 2019 that will make a big impact for WordPress users. It&#8217;s also one of the most challenging from a UI perspective. At WordCamp US&#8217; contributor day, the design team <a href=\"https://make.wordpress.org/design/2018/12/18/exploring-a-nav-block-at-wordcamp-us/\">explored ideas for what a navigation block might look like in the new editor</a>.</p>\n\n\n\n<img />\n\n\n\n<p>The team&#8217;s designs for a navigation block are still in the rough sketches stage, but it&#8217;s interesting to see different approaches as the project develops.</p>\n\n\n\n<p>&#8220;If the Nav block could live in a container block (columns perhaps), then the settings for it could be tweaked in the sidebar,&#8221; XWP designer Joshua Wold said. &#8220;A further problem comes up when you try to figure out how much of the design of the nav should be controlled by the theme vs the Gutenberg editor.&#8221;</p>\n\n\n\n<p>This is an important question  that will need to be answered in the near future &#8211; not only for navigation but also more broadly for the future of the role of themes in WordPress. We will be exploring this in more depth in future posts.</p>\n\n\n\n<p>Designer Mel Choyce and Riad Benguella (one of the leads for Gutenberg phase 2), are currently soliciting ideas from the wider WordPress community about how the project should tackle the upcoming customization focus.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">You care about WordPress and you don\'t have the time to contribute day to day, I\'d love to hear your thoughts to get some inspiration about Phase 2 of Gutenberg, Site building, Customization&#8230; A tweet, a blog post, whatever works best for you. <a href=\"https://twitter.com/hashtag/gutenideas?src=hash&ref_src=twsrc%5Etfw\">#gutenideas</a> <a href=\"https://t.co/Y7tod5DoB2\">https://t.co/Y7tod5DoB2</a></p>&mdash; Riad Benguella (@riadbenguella) <a href=\"https://twitter.com/riadbenguella/status/1075458929579167745?ref_src=twsrc%5Etfw\">December 19, 2018</a></blockquote>\n</div>\n\n\n\n<p>One of the chief complaints about the first phase of the Gutenberg project was the <a href=\"https://make.wordpress.org/core/2018/10/05/gutenberg-phase-2-leads/#comment-34092\">lack of public discussion</a> about the goals and the process of creating the editor. The Gutenberg team&#8217;s willingness to collate ideas across multiple mediums demonstrates a strong effort to seek out more diverse perspectives for phase 2. Ideas have already started rolling in.  </p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Riffing on something <a href=\"https://twitter.com/photomatt?ref_src=twsrc%5Etfw\">@photomatt</a> said at <a href=\"https://twitter.com/hashtag/SOTW?src=hash&ref_src=twsrc%5Etfw\">#SOTW</a> <a href=\"https://twitter.com/hashtag/WCUS?src=hash&ref_src=twsrc%5Etfw\">#WCUS</a>: To map out the future of themes / <a href=\"https://twitter.com/hashtag/Gutenberg?src=hash&ref_src=twsrc%5Etfw\">#Gutenberg</a> 2.0 / <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> Next, maybe ship a Block Zen Garden type thing and asking designers / devs to create solutions, then work backwards to find a UI / UX to make that possible.</p>&mdash; Morten i Norge <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f1f8-1f1ef.png\" alt=\"🇸🇯\" class=\"wp-smiley\" /><img src=\"https://s.w.org/images/core/emoji/11/72x72/1f328.png\" alt=\"🌨\" class=\"wp-smiley\" /><img src=\"https://s.w.org/images/core/emoji/11/72x72/1f976.png\" alt=\"🥶\" class=\"wp-smiley\" /> (@mor10) <a href=\"https://twitter.com/mor10/status/1073664020471660544?ref_src=twsrc%5Etfw\">December 14, 2018</a></blockquote>\n</div>\n\n\n\n<p>&#8220;Rather than starting with the back-end UI, we can start with the front-end result and build a UI to make the building of that front-end possible without messing up the accessibility and resilience of the root HTML document,&#8221; Morten Rand-Hendricksen said. &#8220;At the root of this would be CSS Grid as the main layout module to allow drag-and-drop style block layouts without making changes to the HTML source order.&#8221;</p>\n\n\n\n<p>Many of the ideas that are coming in so far relate more broadly to site customization. These include <a href=\"http://theme.tips/blog/2018/12/21/random-thoughts-about-gutenizer-phase-2/\">questions about what role the Customizer will play</a> and requests for features like creating <a href=\"https://twitter.com/alihs707/status/1075640228470243329\">custom widths on the fly</a> and the <a href=\"https://twitter.com/alihs707/status/1075640228470243329\">ability to drag content across columns.</a> If you have ideas about how navigation can be implemented in a block, take some time before the end of the year and drop your comments on the <a href=\"https://make.wordpress.org/design/2018/12/18/exploring-a-nav-block-at-wordcamp-us/\">make/design post</a> or write your own post and leave a link for others to share feedback.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Dec 2018 23:52:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Seneca on Friendship\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48764\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://ma.tt/2018/12/seneca-on-friendship/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:705:\"<blockquote class=\"wp-block-quote\"><p>But nothing delights the mind so much as fond and loyal friendship. What a blessing it is to have hearts that are ready and willing to receive all your secrets in safety, with whom you are less afraid to share knowledge of something than keep it to yourself, whose conversation soothes your distress, whose advice helps you make up your mind, whose cheerfulness dissolves your sorrow, whose very appearance cheers you up!</p></blockquote>\n\n\n\n<p>You can read <em>On Tranquility of Mind</em> <a href=\"https://en.wikisource.org/wiki/Of_Peace_of_Mind\">online for free here</a> or I enjoyed <a href=\"https://www.amazon.com/dp/B00BCU07LO\">this edition from Penguin</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Dec 2018 20:55:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: 9 Year Old Shares his Journey Learning React\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86488\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wptavern.com/9-year-old-shares-her-journey-learning-react\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:819:\"<p>If learning React is among your New Year&#8217;s goals, here&#8217;s some inspiration from nine-year-old Revel Carlberg West. The video below is a recording of his presentation at the <a href=\"https://www.meetup.com/ReactNYC/\">React NYC</a> meetup. West describes how he learned basic HTML, CSS, and JavaScript and then moved on to learn React using the <a href=\"https://codesandbox.io/\">CodeSandbox</a> online code editor. He also gives a live demo of <a href=\"https://reactjs.org/docs/hooks-intro.html\">React Hooks</a> in action, a new feature that Sophie Alpert and Dan Abramov introduced at React Conf 2018. The code for West&#8217;s traffic light demo is <a href=\"https://codesandbox.io/s/xlw615w7ow\">available on CodeSandbox</a> if you want to follow along.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Dec 2018 19:59:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WordPress 5.0.2 Released with Performance Gains of 330% for Block-Heavy Posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86510\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"https://wptavern.com/wordpress-5-0-2-released-with-performance-gains-of-330-for-block-heavy-posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1544:\"<p><a href=\"https://wordpress.org/news/2018/12/wordpress-5-0-2-maintenance-release/\">WordPress 5.0.2</a>, the of first of two rapid releases following 5.0, is now available. Sites with automatic background updates enabled should already be on the latest version. </p>\n\n\n\n<p>This release addresses performance issues, one of the chief complaints for users who have adopted the block editor. It brings 45 improvements to the editor, with 14 of those related to performance and 31 bug fixes. According to Gary Pendergast, &#8220;the cumulated performance gains make it 330% faster for a post with 200 blocks.&#8221;</p>\n\n\n\n<p>This maintenance release also fixes 17 editor-related bugs in the default WordPress themes as well as internationalization issues related to script loading.</p>\n\n\n\n<p>Overall, 5.0.2 updates have gone smoothly, with the exception of a few conflicts with a handful of plugins. Most notably, WooCommerce store administrators found that the <a href=\"https://github.com/woocommerce/woocommerce/issues/22271\">Orders tab had disappeared</a> after their sites updated. WooCommerce has fixed the issue in a quick patch release (version 3.5.3) that was pushed out this morning.</p>\n\n\n\n<p>NextGEN Gallery creator Erick Danzer also reported <a href=\"https://wordpress.slack.com/archives/C02RQBWTW/p1545334477273500\">a minor issue with the Classic block</a> that prevents users from editing galleries via the placeholder the plugin had added. A fix for that issue should be forthcoming in an update to the plugin.<br /></p>\n\n\n\n<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Dec 2018 21:14:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: Gutenberg-Inspired Jenga Game “Gutenblox” Now Available for Sale\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86500\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://wptavern.com/gutenberg-inspired-jenga-game-gutenblox-now-available-for-sale\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1691:\"<div class=\"wp-block-image\"><img />photo credit: <a href=\"https://xwp.co/\">XWP</a></div>\n\n\n\n<p>XWP&#8217;s Gutenberg-inspired Jenga sets were arguably the most innovative swag at WordCamp US this year, but there weren&#8217;t enough to go around. Gutenblox, fondly dubbed &#8220;the Other Block Building Interface,&#8221; is now available on its own website where anyone can buy a set.</p>\n\n\n\n<p>The <a href=\"https://gutenblox.fun\">Gutenblox.fun</a> store is running on <a href=\"https://wordpress.org/plugins/bigcommerce/\">BigCommerce</a> with the new <a href=\"https://wordpress.org/themes/twentynineteen/\">Twenty Nineteen</a> theme active. It includes the rules of the game, cleverly adapted to the concept of Gutenblox:</p>\n\n\n\n<blockquote class=\"wp-block-quote\"><p>Blocks treat Paragraphs, Headings, Media, etc. all as components that strung together make up the tower. Replacing the traditional concept of board games, Gutenblox is designed with progressive enhancement, meaning as new blocks are added to the top of the tower, they are backward compatible with all legacy content (although the legacy structure may become unstable as new blocks are added on).</p><p>We hope to offer rich value to players who will start with the foundation of a stable, accessible, and secure architecture, and then use a simple drag-and-drop method for modification.</p></blockquote>\n\n\n\n<p>If you&#8217;re looking for a last-minute holiday gift or birthday gift for a friend who loves WordPress, Gutenblox is fun option. It also helps support a good cause. XWP is donating all profits from the sales of the game to the <a href=\"https://wordpressfoundation.org/\">WordPress Foundation</a>. </p>\n\n\n\n<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Dec 2018 17:02:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: Introduction to the WPGraphQL Project with Jason Bahl and Ryan Kanner\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86483\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://wptavern.com/introduction-to-the-wpgraphql-project-with-jason-bahl-and-ryan-kanner\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1187:\"<p>At WordCamp US 2018 I had the chance to sit down with <a href=\"https://twitter.com/jasonbahl\">Jason Bahl</a> and <a href=\"https://twitter.com/CodeProKid\">Ryan Kanner</a>, both engineers at Digital First Media in Denver, Colorado, and contributors to the <a href=\"https://www.wpgraphql.com/\">WPGraphQL</a> project. WPGraphQL is an open source plugin that provides an extendable GraphQL schema and API for any WordPress site.</p>\n\n\n\n<p>Bahl, who created and maintains the project, also gave a lightning talk at WCUS on <a href=\"https://2018.us.wordcamp.org/session/gutenberg-graphql-and-building-blocks/\">using GraphQL with Gutenberg</a> to improve the performance of custom blocks, as well as the developer experience of building them.</p>\n\n\n\n<p>In our interview, Bahl and Kanner offer a general overview of the differences between GraphQL and REST. They explained how Digital First Media improved performance for the company&#8217;s publications by switching from REST to GraphQL. We also discussed how Gutenberg is a great use case for GraphQL and whether the project is something that could someday be included in WordPress core.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Dec 2018 04:00:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"Dev Blog: WordPress 5.0.2 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2018/12/wordpress-5-0-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4589:\"<p>WordPress 5.0.2 is now available!</p>\n\n\n\n<p>5.0.2 is a maintenance release that addresses 73 bugs. The primary focus of this release was performance improvements in the block editor: the cumulated performance gains make it 330% faster for a post with 200 blocks.</p>\n\n\n\n<p>Here are a few of the additional highlights:</p>\n\n\n\n<ul><li>45 total Block Editor improvements are included (14 performance enhancements &amp; 31 bug fixes).</li><li><a href=\"https://core.trac.wordpress.org/query?component=Bundled+Theme&milestone=5.0.2&col=id&col=summary&col=milestone&col=owner&col=type&col=status&col=priority&order=priority\">17 Block Editor related bugs</a> have been fixed across all of the bundled themes.</li><li>Some <a href=\"https://core.trac.wordpress.org/query?component=I18N&milestone=5.0.2&col=id&col=summary&col=status&col=owner&col=type&col=priority&col=milestone&order=priority\">internationalization (i18n) issues</a> related to script loading have also been fixed.</li></ul>\n\n\n\n<p>For a full list of changes, please consult the <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=5.0.2&group=component\">list of tickets on Trac</a> or the <a href=\"https://core.trac.wordpress.org/log/branches/5.0?action=stop_on_copy&mode=stop_on_copy&rev=44339&stop_rev=44183&limit=100&sfp_email=&sfph_mail=\">changelog</a>.</p>\n\n\n\n<p>You can <a href=\"https://wordpress.org/download/\">download WordPress 5.0.2</a> or visit Dashboard → Updates and click <em>Update Now</em>. Sites that support automatic background updates have already started to update automatically.</p>\n\n\n\n<p>Thank you to everyone who contributed to WordPress 5.0.2:</p>\n\n\n\n<p><a href=\"https://profiles.wordpress.org/babaevan/\">Alexander Babaev</a>, <a href=\"https://profiles.wordpress.org/akirk/\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/allancole/\">allancole</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/atimmer/\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/jdtrower/\">David Trower</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/edpittol/\">Eduardo Pittol</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/greg-raven/\">Greg Raven</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">gziolo</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">herregroen</a>, <a href=\"https://profiles.wordpress.org/icaleb/\">iCaleb</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/khleomix/\">khleomix</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">kjellr</a>, <a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff&nbsp;Paul</a>, <a href=\"https://profiles.wordpress.org/mihaivalentin/\">mihaivalentin</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/more/\"></a><a href=\"https://profiles.wordpress.org/mmaumio/\">Muntasir Mahmud</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pratikthink/\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/richtabor/\">Rich Tabor</a>, <a href=\"https://profiles.wordpress.org/strategio/\">strategio</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/torontodigits/\">TorontoDigits</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich/\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/volodymyrkolesnykov/\">volodymyrkolesnykov</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/ze3kr/\">ze3kr</a>, and <a href=\"https://profiles.wordpress.org/mypacecreator/\">のむらけい</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 23:47:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"WPTavern: Happy Developers, Happy Ecosystem: The Intangible Impact of WordPress’ Minimum PHP Version Bump\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86464\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://wptavern.com/happy-developers-happy-ecosystem-the-intangible-impact-of-wordpress-minimum-php-version-bump\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6401:\"<div class=\"wp-block-image\">\n<img />\n</div>\n<p>The following is a guest post by <a href=\"https://twitter.com/ChrisVanPatten\">Chris Van Patten</a>, founder of <a href=\"https://tomodomo.co\">Tomodomo</a>, a digital agency for magazine publishers. </p>\n<hr class=\"wp-block-separator\" />\n<p>For years, WordPress has been ever-so-slightly behind the times on PHP version support&#8230;to put it kindly.</p>\n<p>However, WordPress&#8217; legendary support for PHP versions back to 5.2 — versions long unsupported by the PHP project itself — wasn&#8217;t born out of a &#8220;we hate developers&#8221; strategy (although you&#8217;d be forgiven for thinking so given the reaction that policy often gets from developers). Instead, it was a genuinely noble and pragmatic effort to make WordPress, and thus publishing on the web, as widely available as possible.</p>\n<p>Despite the reaction from many developers (and security-minded sysadmins), that strategy worked: WordPress <a href=\"https://w3techs.com/technologies/overview/content_management/all\" rel=\"noopener\" target=\"_blank\">powers over 30% of the web</a>, and a <a href=\"https://wordpress.org/about/stats/\" rel=\"noopener\" target=\"_blank\">significant chunk of those installations are on unsupported PHP versions</a>. For those users, it&#8217;s not that they don&#8217;t care that they are on an unsupported version of PHP; they just don&#8217;t know, or don&#8217;t know how to solve the problem.</p>\n<p>But the winds of progress are blowing, and in 2019 WordPress is planning to make a change. Assuming everything goes according to plan, PHP 5.6 will become the minimum supported version in the first half of the year, and the minimum version will be bumped again to PHP 7 in the second half of 2019.</p>\n<p>There are obvious benefits here from a security perspective. The oldest versions of PHP supported by WordPress today stopped receiving official security updates ages ago (PHP 5.2 hit EOL, or &#8220;end-of-life,&#8221; nearly 8 years ago). The speed improvements will be tremendous as well, particularly in PHP 7. Speaking from my own experience, I have several sites that once needed aggressive caching to prevent server overload. Since PHP 7, they run faster than ever, without caching of any kind.</p>\n<p>Speed and security are the two most-cited reasons (and the most measurable reasons) for bumping the minimum version, but there are also other less tangible benefits that will filter well beyond WordPress core development.</p>\n<h3>Simplified support</h3>\n<p>While plugin developers have never been obligated to support all the versions of PHP that WordPress core does, many still chose to do so. That&#8217;s understandable: it could be tough to explain to a user why they can install WordPress in a certain development environment but couldn&#8217;t install a certain plugin.</p>\n<p>For plugins that tried to match core&#8217;s backward compatibility support, that means testing and supporting up to nine versions of PHP: 5.2 through 5.6, and 7.0 through 7.3. (There was no PHP 6. I won&#8217;t bother explaining the <a href=\"https://ma.ttias.be/php6-missing-version-number/\" rel=\"noopener\" target=\"_blank\">boring reasons why</a>.)</p>\n<p>By pushing to 5.6, and eventually some version of PHP 7+, that cuts the number of versions that developers will feel compelled to support in half. In some way, Core will likely continue to support these old versions (through security backports to old versions of WordPress, for instance) but plugin developers can be assured that they don&#8217;t need to — and don&#8217;t need to feel any semblance of guilt about it either.</p>\n<h3>Happier developers</h3>\n<p>Even developers who are excited about the WordPress platform as a whole are likely to admit that it&#8217;s maybe not the most exciting code-base in the world. Over the past few years, I&#8217;ve seen a number of examples of developers who once limited themselves to WordPress now stretching into other frameworks and languages: Laravel, JavaScript, and Go are all popular new homes for WordPress expats.</p>\n<p>Bumping the minimum version won&#8217;t change that apathy or exodus overnight, but it will give developers something to feel excited about. Modern PHP versions (especially PHP 7) offer genuinely cool new language features that make it easy to write performant, well-designed, and interesting code. I would even argue that it makes it fun. Modern PHP contains plenty of <a href=\"https://en.wikipedia.org/wiki/Syntactic_sugar\" rel=\"noopener\" target=\"_blank\">syntactic sugar</a>, and while you shouldn&#8217;t base your diet on sugar it certainly makes for a nice treat.</p>\n<p>Again, it is unlikely that core will start adopting these new language features on day one. The real benefit is that developers will feel empowered and secure in their decisions to start using these new capabilities, and will start to build plugins and themes that can borrow ideas from best practices in the broader PHP community.</p>\n<h3>Celebrating the intangible</h3>\n<p>While the measurable justifications for changing the minimum PHP version are certainly compelling, I think it&#8217;s also important to acknowledge these intangibles and indeed celebrate them. Bumping these versions will create a ripple effect across the ecosystem that will make developers more comfortable with writing modern code. It will reduce support and QA loads for companies that no longer need to support 9 different versions of PHP. It will make WordPress core a more attractive place to contribute.</p>\n<p>Gutenberg, and all the modern tooling and architecture it brought, has already reinvigorated developers across the ecosystem and brought a huge number of new core contributors (<a href=\"https://wptavern.com/contributing-to-gutenberg-a-new-contributors-experience\" rel=\"noopener\" target=\"_blank\">myself among them</a>). Embracing modern PHP is another step forward, and with other changes on the horizon (such as a <a href=\"https://make.wordpress.org/core/2018/12/09/on-wordpress-git/\" rel=\"noopener\" target=\"_blank\">move from SVN to Git</a>, coding standards changes, and projects like <a href=\"https://www.wptide.org/\" rel=\"noopener\" target=\"_blank\">Tide</a> which embrace new languages and architectures) I hope that 2019 will be the year WordPress delivers not only a best-in-class user experience, but a best-in-class developer experience too.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Dec 2018 17:57:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Chris Van Patten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Gutenberg for Writers: How to Configure the Editor for Fewer Distractions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86427\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/gutenberg-for-writers-how-to-configure-the-editor-for-fewer-distractions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4740:\"<img />photo credit: <a href=\"https://stocksnap.io/photo/8Y0EDX4VP9\">Green Chameleon</a>\n\n\n\n<p>For a long time I could not compose posts with the Gutenberg editor. I tested each release of the plugin throughout its journey into WordPress 5.0, but found it too distracting for my basic needs. It seemed better suited for building a brochure website, not for someone who uses WordPress primarily for writing. </p>\n\n\n\n<p>This is the first thing you see on a vanilla install of WordPress when you go to the &#8220;Add New&#8221; post page:</p>\n\n\n\n<div class=\"wp-block-image\"><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/09/Screen-Shot-2018-12-17-at-10.14.35-AM.png?ssl=1\"><img /></a></div>\n\n\n\n<p>Although it may not be immediately evident, the new editor actually has some built-in controls for improving the writing experience. They are tucked away behind the vertical ellipsis menu at the top of the screen. Here&#8217;s how to configure Gutenberg for writing:</p>\n\n\n\n<h3>Step 1: Hide the Settings Sidebar</h3>\n\n\n\n<p>The first step towards a more distraction-free writing experience is to hide the settings. Click the X at the top right of the screen.  If you&#8217;re trying to stay in the flow of writing, it&#8217;s not necessary to keep the block and document settings in view at all times. You can always toggle them on later when you&#8217;re finished getting your thoughts onto the screen.</p>\n\n\n\n<h3>Step 2: Turn on &#8220;Fullscreen Mode&#8221;</h3>\n\n\n\n<p>Many new and experienced WordPress users are not aware of Gutenberg&#8217;s &#8220;Fullscreen mode&#8221; that places the writing area in the center of the page and hides WordPress&#8217; admin menu sidebar.  This setting is a must for keeping distractions at bay. You can find it at the top right corner in the vertical ellipsis menu:</p>\n\n\n\n<img />\n\n\n\n<p>Once Fullscreen Mode is enabled, the writing area is greatly improved, with distractions removed from both sides of the content area. </p>\n\n\n\n<img />\n\n\n\n<h3>Step 3: Fix the Toolbar to the Top (optional)</h3>\n\n\n\n<p>The block toolbar popping in and out of view was the bane of my Gutenberg experience until they developed the &#8220;Top Toolbar&#8221; setting. By default, the block-level toolbar obscures part of the content above it (as seen in the image below) and an obtrusive blue outline follows your mouse as you move over the paragraphs you have already written.</p>\n\n\n\n<img />\n\n\n\n<p>The psychological affect of all these boxes popping in and out of view may be more taxing for some writers, so this step is optional. The &#8220;Top Toolbar&#8221; setting to hide the block-level toolbar, as well as the blue block outlines, is also inside the vertical ellipsis menu at the top. The best way to see the difference in the experience is to experiment with turning it on and off.</p>\n\n\n\n<p>Spotlight mode takes it one step further and greys out all the content except the current block, allowing writers to focus on one block at a time. When it is enabled, the blocks that are not being edited will partially fade away and no block outlines will be visible. </p>\n\n\n\n<img />Spotlight mode\n\n\n\n<p>Gutenberg still has a way to go before it can provide a truly distraction-free editing experience. None of the modes highlighted above will hide the metaboxes at the bottom or the menu bar at the top. They do, however, allow you to compose in an area without the block-level toolbar and sidebars getting in the way.</p>\n\n\n\n<p>My thoughts don&#8217;t always come out in full sentences and paragraphs. Sometimes they are scattered throughout a document in half sentences, single words, quotes, and fragments of quotes that I&#8217;m not certain I will use. How do I reconcile this with Gutenberg? Sometimes the Classic Block is a good option for a first draft that looks more like a pile of messy notes than a document of well-formed thoughts. Here&#8217;s what that looks like if you have never used it:</p>\n\n\n\n<img />Classic Block\n\n\n\n<p>Even with these settings available, some writers may still prefer to use a dedicated writing app instead of the WordPress editor. Fortunately, Gutenberg has very good support for copying and pasting from other applications.</p>\n\n\n\n<p>Top Toolbar, Spotlight, and Fullscreen modes are not the easiest features to discover but they can make a significant impact on your experience writing in the new editor. WordPress core may never provide a truly distraction-free writing experience, but that&#8217;s where the beauty of the plugin system comes into play. It gives developers the opportunity to create new and interesting approaches towards a better default writing experience. I hope to see some of those popping up in the directory as more users adopt Gutenberg.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Dec 2018 03:17:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: WordPress 5.0.2 to Bring Major Performance Improvements, Scheduled for December 19\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86358\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://wptavern.com/wordpress-5-0-2-to-bring-major-performance-improvements-scheduled-for-december-19\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3081:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2018/12/stopwatch.jpg?ssl=1\"><img /></a>Processed with VSCOcam with c1 preset</p>\n<p><a href=\"https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\" rel=\"noopener\" target=\"_blank\">WordPress 5.0.1</a> was released yesterday as a security release with fixes for seven vulnerabilities that were privately disclosed. It includes a few <a href=\"https://make.wordpress.org/core/2018/12/13/backwards-compatibility-breaks-in-5-0-1/\" rel=\"noopener\" target=\"_blank\">breaks in backwards compatibility</a> that plugin developers will want to review.</p>\n<p>WordPress 5.0.2 will be the first planned followup release to 5.0 and is now scheduled to be released December 19, 2018. Gary Pendergast posted a <a href=\"https://make.wordpress.org/core/2018/12/13/dev-chat-summary-december-12th/\" rel=\"noopener\" target=\"_blank\">summary</a> of this week&#8217;s dev chat that includes the schedule and scope for the upcoming release. It will include Gutenberg 4.7, Twenty Nineteen bug fixes, and a few PHP 7.3 compatibility fixes.</p>\n<p><a href=\"https://gschoppe.com/wordpress/benchmarking-gutenberg/\" rel=\"noopener\" target=\"_blank\">Slow performance</a> as compared to the classic editor has been a commonly-reported <a href=\"https://github.com/WordPress/gutenberg/issues/6466\" rel=\"noopener\" target=\"_blank\">issue</a> with Gutenberg. The project has a label for it on GitHub with <a href=\"https://github.com/WordPress/gutenberg/labels/%5BType%5D%20Performance\" rel=\"noopener\" target=\"_blank\">26 open issues</a>. 140 performance-related issues have already been closed so the team is making progress on speeding it up. 5.0.2 will bring major performance improvements to the editor, particularly for content that includes hundreds of blocks. </p>\n<p>&#8220;The cumulated performance gains are around 330% faster for a post with 200 blocks,&#8221; Matias Ventura said in an <a href=\"https://make.wordpress.org/core/2018/12/13/5-0-2-editor-performance-and-bug-fixes/\" rel=\"noopener\" target=\"_blank\">update</a> on the editor. &#8220;This might be even bigger for certain setups and plugin configurations — seeing the same test post be 540% faster with Yoast, for example.&#8221;</p>\n<p>These changes are already in version 4.7 of the Gutenberg plugin, which users can run alongside WordPress 5.0.1 to test the latest. </p>\n<p>RC 1 for 5.0.2 is planned for today and RC 2 (if necessary) is targeted for December 17. The official release is scheduled for December 19.</p>\n<p>Gary Pendergast also outlined the scope and schedule for WordPress 5.1, which will be led by Matt Mullenweg. Pendergast proposed a relatively short release cycle with an official release February 21, since there are already more than <a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=5.1\" rel=\"noopener\" target=\"_blank\">200 tickets fixed for 5.1</a>. Focuses for the release include the REST API (particularly authentication solutions), core JS, and core themes. Beta 1 is planned for January 10, with RC 1 following February 7. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Dec 2018 16:52:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPWeekly Episode 341 – Recap of WordCamp US 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=86395&preview=true&preview_id=86395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wptavern.com/wpweekly-episode-341-recap-of-wordcamp-us-2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1333:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I recap WordCamp US 2018. We discuss what&#8217;s new in WordPress 5.0.1 and when users can expect to see 5.0.2.</p>\n<p>We also chat about the new path that WordPress is on and where it may lead. John shares his perspective on what the atmosphere was like at the event and compares it to last year.</p>\n<p>Near the end of the show, we explain why the Question and Answer process at the end of the State of the Word will likely undergo changes.</p>\n<h2>Stories Discussed:</h2>\n<p><a href=\"https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\">WordPress 5.0.1 Security Release</a></p>\n<h2>WPWeekly Meta:</h2>\n<p><strong>Next Episode:</strong> Wednesday, December 19th 3:00 P.M. Eastern</p>\n<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>\n<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>\n<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>\n<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>\n<p><strong>Listen To Episode #341:</strong><br />\n</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Dec 2018 01:59:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: WordCamp US 2019 to be Held November 1-3 in St. Louis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86379\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/wordcamp-us-2019-to-be-held-november-1-3-in-st-louis\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4527:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/12/st-louis.jpg?ssl=1\"><img /></a>photo credit: <a href=\"https://commons.wikimedia.org/wiki/File:St_Louis_night_expblend.jpg\">Wikimedia Commons</a></p>\n<p>Dates for WordCamp US 2019 were <a href=\"https://wordpress.org/news/2018/12/wordcamp-us-2019-dates-announced/\" rel=\"noopener\" target=\"_blank\">announced</a> today, less than a week after wrapping up a successful camp in Nashville. Unlike all previous years held in December, next year&#8217;s event will take place November 1-3 in <a href=\"https://2018.us.wordcamp.org/2018/06/15/matt-mullenweg-announces-st-louis-as-wordcamp-us-2019-2020-host-city/\" rel=\"noopener\" target=\"_blank\">St. Louis, Missouri</a>. </p>\n<p>For the most part, community reactions to the new dates were positive. Early November dates place the event well ahead of the end of the year holidays that attendees had previously bemoaned.</p>\n<p>&#8220;I love this date set better than the previous one. It’s so much easier to attend/speak pre-Thanksgiving,&#8221; WordPress developer Mitch Cantor <a href=\"https://twitter.com/thatmitchcanter/status/1073307921851867136\" rel=\"noopener\" target=\"_blank\">said</a>.</p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/hashtag/WordCamp?src=hash&ref_src=twsrc%5Etfw\">#WordCamp</a> US, November 1-3, 2019. This is great news! December is always a mad dash to an arbitrary solstice-based finish line. Moving <a href=\"https://twitter.com/hashtag/WCUS?src=hash&ref_src=twsrc%5Etfw\">#WCUS</a> to November takes a huge load off! <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> <a href=\"https://t.co/WUToY3eiam\">https://t.co/WUToY3eiam</a></p>\n<p>&mdash; Morten Rand-Hendriksen (@mor10) <a href=\"https://twitter.com/mor10/status/1073308742488227840?ref_src=twsrc%5Etfw\">December 13, 2018</a></p></blockquote>\n<p></p>\n<p>There is always a conflict for some demographic of attendees. This year the hardest hit are parents of small children who will likely miss taking their kids trick-or-treating due to traveling on or before Halloween in order to make it to the event. WordCamp US is a family-friendly event but bringing children to a WordCamp can be extraordinarily challenging, even when the event includes childcare. (This particular event doesn&#8217;t.) For a few attendees, missing Halloween with their children is a deal-breaker. </p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">Exactly what I was thinking. I\'d have to fly in on Halloween, no way I\'m missing Halloween with my 2 year old.</p>\n<p>&mdash; Katie Thompson (@katietdesign) <a href=\"https://twitter.com/katietdesign/status/1073341329021775875?ref_src=twsrc%5Etfw\">December 13, 2018</a></p></blockquote>\n<p></p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">That’s a good point! <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f640.png\" alt=\"🙀\" class=\"wp-smiley\" /></p>\n<p>&mdash; Tessa Kriesel (@tessak22) <a href=\"https://twitter.com/tessak22/status/1073333517646467075?ref_src=twsrc%5Etfw\">December 13, 2018</a></p></blockquote>\n<p></p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">Though this one is something a lot of parents really enjoy spending with their small children especially in the US. We\'re not talking about national hotdog day here.</p>\n<p>&mdash; Patrick Garman (@pmgarman) <a href=\"https://twitter.com/pmgarman/status/1073317197194428421?ref_src=twsrc%5Etfw\">December 13, 2018</a></p></blockquote>\n<p></p>\n<p>One possible solution for the parents who feel they have to miss WordCamp US because of their kids, might be for the organizers to schedule the contributor day as the first day of the camp. That might enable people to fly in on an early morning flight and still get to experience part of the contributor day and all of the main event. </p>\n<p>In a community this large, with many other holidays and WordCamps already on the calendar, it&#8217;s difficult to find a date for WordCamp US that doesn&#8217;t have conflicts. This is a good problem for the community to have. Matt Mullenweg shared during the State of the Word that the community has experienced 50% year over year growth with more than 350K members in 687 meetup groups and more than 5,000 meetup events. With this rate of growth, the community can expect more regional and local camps to spring up in the coming years, which means more conflicts but also more options for getting together in the future.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Dec 2018 00:43:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: WordPress Plugin Directory Now Features a Curated Section for Block-Enabled Plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86331\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"https://wptavern.com/wordpress-plugin-directory-now-features-a-curated-section-for-block-enabled-plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4065:\"<p>If you visit the <a href=\"https://wordpress.org/plugins/\" target=\"_blank\" rel=\"noopener\">plugin directory</a>, you will notice a new section at the top featuring block-enabled plugins. WordPress 5.0 has been downloaded more than 8 million times, just one week after its release, and users are looking for blocks to extend the new editing experience. WordPress.org is highlighting plugins to push the block ecosystem forward and will soon be doing the same for themes.</p>\n<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/12/Screen-Shot-2018-12-13-at-9.35.13-AM.png?ssl=1\"><img /></a></p>\n<p>There are currently 94 blocks in the featured section. In a <a href=\"https://make.wordpress.org/plugins/2018/12/07/blocks-plugins-and-you/\" target=\"_blank\" rel=\"noopener\">post</a> on make.wordpress.org/plugins, Samuel (Otto) Wood invited developers to email the plugins team at plugins@wordpress.org if they have a block-enabled plugin that they want to be included. The basic requirements are a plugin that introduces or improves blocks.</p>\n<p>I asked Otto how they select from submissions. He said the plugins team is curating the list manually and adding those they think are good or interesting.</p>\n<p>&#8220;It&#8217;s not a high bar; if it has a neat block, we&#8217;ll add it for now,&#8221; Otto said. &#8220;We may raise the bar depending on how big the section gets, and the section is not final by any means. We&#8217;ll change the inclusions according to how it works out. The goal is to promote neat and cool integrations, but there aren&#8217;t a lot of those yet. It&#8217;s new.&#8221;</p>\n<p>Assigning a tag to block-enabled plugins that authors could opt into would eliminate the need for manual approval on the section, but Otto said they are currently handling it more like a showcase.</p>\n<p>&#8220;Letting the plugin authors just add a tag would reduce the available tags (it&#8217;s already limited to 5) as well as reducing the value of curation,&#8221; Otto said. &#8220;We may change that as well in the future, somehow. Nothing is set in stone right now, we just want to see people making cool blocks and see what happens with that.&#8221;</p>\n<p>A directory devoted entirely to blocks may also be coming to WordPress.org next year. In a recent post, Matt Mullenweg identified <a href=\"https://make.wordpress.org/core/2018/12/08/9-priorities-for-2019/\" rel=\"noopener\" target=\"_blank\">9 Projects for 2019</a>, including &#8220;building a WordPress.org directory for discovering blocks, and a way to seamlessly install them.&#8221; This is a much larger task and requires WordPress to answer a few questions: Will plugins continue to be the primary delivery mechanism for blocks? Or will WordPress.org implement a system where users can download JS-only blocks, similar to the Gutenberg Cloud project? </p>\n<p>Three months ago, Otto <a href=\"https://wptavern.com/gutenberg-cloud-a-cross-platform-community-library-for-custom-gutenberg-blocks#comment-260894\" rel=\"noopener\" target=\"_blank\">commented</a> on a post about Gutenberg Cloud, saying that js-only blocks are likely only suited to frontend enhancements.</p>\n<p>&#8220;I remain unconvinced that js-only blocks have a place which is meaningful other than the trivial layout based things that blocks can do,&#8221; Otto said. &#8220;Yes, you can build great looking blocks with JavaScript only, and since it’s an editor, that is a really big deal. But without any actual support on the backend to &#8216;do stuff of substance,&#8217; it is just visual glitter.&#8221;</p>\n<p>Offering JS-only blocks through WordPress.org might also complicate block discovery if users don&#8217;t know whether to look for blocks in a plugin or via the JS-only block delivery system. There are a lot of unknowns in the block era that will require WordPress to make some decisions. Meanwhile, the ecosystem of block-enabled plugins will continue expanding as more users adopt the new editor and especially as widgets and menus are ported to blocks in phase 2 of the Gutenberg project.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 21:32:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"Dev Blog: WordCamp US 2019 dates announced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6496\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2018/12/wordcamp-us-2019-dates-announced/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:705:\"<p>Save the date! <a href=\"https://2019.us.wordcamp.org/2018/12/12/wordcamp-us-2019-announcing-our-dates/\">The next WordCamp US</a> will be held on November 1-3, 2019, in beautiful <a href=\"https://2018.us.wordcamp.org/2018/06/15/matt-mullenweg-announces-st-louis-as-wordcamp-us-2019-2020-host-city/\">St Louis, Missouri</a>. One of our largest events of the year, WordCamp US is a great chance to connect with WordPress enthusiasts from around the world. This is also the event that features Matt Mullenweg&#8217;s annual <a href=\"https://www.youtube.com/watch?v=r5b-N2RmxS8\">State of the Word</a> address. </p>\n\n\n\n<p>We&#8217;d love to see you in St. Louis next year, so mark your calendar now!<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 19:47:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"WPTavern: Interview with Rachel Cherry: Automattic Pledges to Fund WPCampus’ Accessibility Audit of Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86293\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"https://wptavern.com/interview-with-rachel-cherry-automattic-pledges-to-fund-wpcampus-accessibility-audit-of-gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2477:\"<p>While at WordCamp US, I had the opportunity to catch up with <a href=\"https://wpcampus.org/\" rel=\"noopener\" target=\"_blank\">WPCampus</a> director Rachel Cherry, who is coordinating an audit on Gutenberg for the organization she leads. WPCampus <a href=\"https://wptavern.com/wpcampus-seeks-to-raise-30k-for-gutenberg-accessibility-audit\" rel=\"noopener\" target=\"_blank\">launched its crowdfunding campaign</a> at the end of November and more than $10K has come in towards the <a href=\"https://wpcampus.org/2018/11/fundraising-for-wpcampus-gutenberg-accessibility-audit/\" rel=\"noopener\" target=\"_blank\">$30K goal</a>.</p>\n<p>The day before WordPress 5.0 was released, WPCampus announced that Automattic has pledged to ensure WPCampus&#8217; accessibility audit of Gutenberg is fully funded. </p>\n<p>&#8220;I think that they [Automattic] see that it is important,&#8221; Cherry said. &#8220;Even when they said they weren&#8217;t going to do it, I don&#8217;t think it was ever &#8216;We&#8217;re never going to;&#8217; it was just &#8216;Not right now.&#8217; For us, we couldn&#8217;t necessarily wait for &#8216;maybe we&#8217;ll do it later,&#8217; so that&#8217;s why we jumped on it and got the ball rolling. I think they saw an opportunity where they could step in and have the means to move this along even further. They see the value and I think that&#8217;s why they wanted to jump in. They also saw all the community effort going on.&#8221;</p>\n<p>In the interview below, Cherry discusses how leaders in the WPCampus community rallied to get the audit in motion. The organization has received seven responses from vendors and is currently in the selection process. She also shared a little bit about her conversation with Matt Mullenweg during his community office hours and their discussion about how WordPress is used in higher education.</p>\n<p>Cherry&#8217;s strategy in advocating for accessibility is to focus on slicing through the confusion surrounding accessibility problems with an emphasis on education and communication. Although WordPress has set accessibility standards, the project has fallen short on enforcing them. In addition to putting automated accessibility testing in place for core, Cherry said she would also like to get more support for helping theme and plugin authors meet accessibility standards. This would help ensure that the code WordPress.org puts on the web is more accessible for those who are creating customized sites.</p>\n<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 04:29:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"Dev Blog: WordPress 5.0.1 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6498\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4797:\"<p>WordPress 5.0.1 is now available. This is a <strong>security release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>\n\n\n\n<p>Plugin authors are encouraged to <a href=\"https://make.wordpress.org/core/2018/12/13/backwards-compatibility-breaks-in-5-0-1/\">read the 5.0.1 developer notes</a> for information on backwards-compatibility.</p>\n\n\n\n<p>WordPress versions 5.0 and earlier are affected by the following bugs, which are fixed in version 5.0.1. Updated versions of WordPress 4.9 and older releases are also available, for users who have not yet updated to 5.0.</p>\n\n\n\n<ul><li><a href=\"https://ripstech.com\">Karim El Ouerghemmi</a> discovered that authors could alter meta data to delete files that they weren&#8217;t authorized to.</li><li>Simon Scannell of <a href=\"https://blog.ripstech.com\">RIPS Technologies</a> discovered that authors could create posts of unauthorized post types with specially crafted input.</li><li><a href=\"https://twitter.com/_s_n_t\">Sam Thomas</a> discovered that contributors could craft meta data in a way that resulted in PHP object injection. </li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> discovered that contributors could edit new comments from higher-privileged users, potentially leading to a cross-site scripting vulnerability.</li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> also discovered that specially crafted URL inputs could lead to a cross-site scripting vulnerability in some circumstances. WordPress itself was not affected, but plugins could be in some situations. </li><li><a href=\"https://yoast.com/\">Team Yoast</a> discovered that the user activation screen could be indexed by search engines in some uncommon configurations, leading to exposure of email addresses, and in some rare cases, default generated passwords.</li><li><a href=\"https://security-consulting.icu\">Tim Coen</a> and <a href=\"https://medium.com/websec\">Slavco</a> discovered that authors on Apache-hosted sites could upload specifically crafted files that bypass MIME verification, leading to a cross-site scripting vulnerability. </li></ul>\n\n\n\n<p>Thank you to all of the reporters for <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">privately disclosing the vulnerabilities</a>, which gave us time to fix them before WordPress sites could be attacked.</p>\n\n\n\n<p><a href=\"https://wordpress.org/download/\">Download WordPress 5.0.1</a>, or venture over to <code>Dashboard → Updates</code> and click <code>Update Now</code>. Sites that support automatic background updates are already beginning to update automatically.</p>\n\n\n\n<p>In addition to the security researchers mentioned above, thank you to everyone who contributed to WordPress 5.0.1:</p>\n\n\n\n<p><a href=\"https://profiles.wordpress.org/tellyworth\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/xknown\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron Campbell</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/vortfu\">Ben Bidner</a>, <a href=\"https://profiles.wordpress.org/barry\">Barry Abrahamson</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">Chris Christoff</a>, <a href=\"https://profiles.wordpress.org/darthhexx/\">David Newman</a>, <a href=\"https://profiles.wordpress.org/apokalyptik\">Demitrious Kelly</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/hnotess/\">Hannah Notess</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/herregroen\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/chanthaboune\">Josepha Haden</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/batmoo/\">Mo Jangda</a>, <a href=\"https://profiles.wordpress.org/nickdaugherty\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/SergeyBiryukov\">Sergey Biryukov</a>, and <a href=\"https://twitter.com/p_valentyn\">Valentyn Pylypchuk</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Dec 2018 03:13:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Ian Dunn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"Post Status: Interview with Matt Mullenweg on Gutenberg, WordPress, and the future\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=50403\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://poststatus.com/matt-mullenweg-on-gutenberg/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101863:\"<p>Welcome to the Post Status <a href=\"https://poststatus.com/category/draft\">Draft podcast</a>, which you can find <a href=\"https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008\">on iTunes</a>, <a href=\"https://play.google.com/music/m/Ih5egfxskgcec4qadr3f4zfpzzm?t=Post_Status__Draft_WordPress_Podcast\">Google Play</a>, <a href=\"http://www.stitcher.com/podcast/krogsgard/post-status-draft-wordpress-podcast\">Stitcher</a>, and <a href=\"http://simplecast.fm/podcasts/1061/rss\">via RSS</a> for your favorite podcatcher. Post Status Draft is hosted by Brian Krogsgard.</p>\n<p>In this episode, I am joined by <a href=\"https://ma.tt\">Matt Mullenweg</a>, the co-founder of WordPress and CEO of Automattic.</p>\n<p>Just after releasing WordPress 5.0, and on the heels of WordCamp US, Matt and I review the event, the release, and discuss how he thinks things went, what could have gone better, and what he sees ahead.</p>\n<p>We also dig into WooCommerce, various plans around core development processes, Automattic, and more. I hope you enjoy.</p>\n<p></p>\n<p>And an audio version.</p>\n<p></p>\n<p>Full transcript is coming soon.</p>\n<h3>Episode Links</h3>\n<ul>\n<li><a href=\"https://ma.tt/\">Matt&#8217;s blog</a></li>\n<li><a href=\"https://automattic.com\">Automattic</a></li>\n<li>WordCamp US <a href=\"https://ma.tt/2018/12/state-of-the-word-2018/\">State of the Word</a></li>\n<li>Post Status&#8217;s <a href=\"https://poststatus.com/state-of-the-word-2018/\">coverage of WCUS</a></li>\n<li><a href=\"https://grief.com/the-five-stages-of-grief/\">5 Stages of Grief</a></li>\n</ul>\n<h3>Sponsor: iThemes</h3>\n<p><a href=\"https://ithemes.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">iThemes</a> makes great WordPress plugins, themes and training to help take the guesswork out of building, maintaining and securing WordPress websites. I talk to iThemes CEO Cory Miller during the break to hear about what they are working on, and excited about for the coming year.</p>\n<p>Thanks to <a href=\"https://ithemes.com/?utm_source=post_status&utm_medium=banner&utm_campaign=ps_ads\">iThemes</a> for being a Post Status partner.</p>\n<p>&nbsp;</p>\n<h3>Full Transcript</h3>\n<div class=\"transcript\">\n<p>Brian Krogsgard: Hello and welcome to Post Status Draft. I hope you enjoy this interview with Matt Mullenweg. It lasts for a while, but I think that it&#8217;s worth catching the whole thing. We cover a whole bunch of topics. I want to thank iThemes for being our partner for this episode. iThemes has been in the WordPress space for so, so long and they make many great products, whether you&#8217;re looking to secure your website, manage your plugins and themes and so much more. Go to iThemes.com to learn more and thanks so much to the team at iThemes for being a Post Status partner. Now here&#8217;s the show. So hello and welcome to Post Status Draft. Fresh off of the release of WordPress 5.0 and WordCamp US, I&#8217;m here with Matt Mullenweg, the co-founder of WordPress. Hey Matt.Matt Mullenweg: Howdy, howdy. It&#8217;s good to see everyone again.</p>\n<p>Brian Krogsgard: Yeah, it&#8217;s great to see you. You look comfortable. You must be somewhere that is something like home.</p>\n<p>Matt Mullenweg: Yeah, I&#8217;m in actually New York City this week. I had a few meetings after the WordCamp and it&#8217;s also just one of my favorite cities to be especially this time of year. The lights and everything around Christmas time are just gorgeous, so it&#8217;s fun.</p>\n<p>Brian Krogsgard: Yeah. I&#8217;ve never been to New York City in the Christmas season, but it&#8217;s one of those bucket list type of things. So let&#8217;s start off with just how are you feeling post-release, post-event? How do you feel like things went overall?</p>\n<p>Matt Mullenweg: Super energized. I&#8217;d say like day before the release was pretty nervewracking, but it went better than I think almost anyone hoped, including myself. There was a great energy at WordCamp of we were able to kind of &#8230; I think instead of arguing about whether we should do a release or not, should it be Thursday or Tuesday or next month or never, or all these sorts of different options, everyone would say, &#8220;Okay, it happens. The world didn&#8217;t end and what can we do next to make things better?&#8221; That kind of making things better conversation is where I find the WordPress community is most productive. It&#8217;s where you can really get all sorts of different ideas and you can really get to the point where it does make things better for our users.</p>\n<p>Brian Krogsgard: Yeah. And I tend to think generally people cool down when they&#8217;re in person versus when they&#8217;re online. So all the energy, the pent-up energy from working through all the things that have to do with the release over the course of two years and it finally comes on you, sometimes it just feels good to get it out at the end of the day. You let those bygones be bygones.</p>\n<p>Brian Krogsgard: I felt like it was actually a pretty drama-free release and event. I didn&#8217;t see any major bugs come across. I asked some of the big hosts and some of the big plugin companies, I was like, &#8220;What are you all seeing? Are you seeing a bunch of stuff come through?&#8221; And I didn&#8217;t get much. Have you heard much feedback in terms of, are there a lot of bugs coming up? Are there are a lot of issues or has it been fairly smooth?</p>\n<p>Matt Mullenweg: Well, what I&#8217;ve been telling you all year, that it would be anticlimactic, I was half right. The software was anticlimactic. Everything around the software was pretty intense.</p>\n<p>Brian Krogsgard: Very climactic, yeah.</p>\n<p>Matt Mullenweg: But yeah, I actually didn&#8217;t realize it before I got on for State of the Word, but host site GoDaddy, others have already upgraded over a million sites. They&#8217;re seeing normal support loads, things like that. It&#8217;s like I said, ultimately what drives a release day is, is the software ready? And the software was ready and all the inputs, all the data, all the sort of normal things we look at were there. It was just one of these things where the people, we didn&#8217;t seem ready and that&#8217;s much harder to navigate. Sometimes getting it out there helps a lot, but it&#8217;s one thing that I&#8217;ve seen throughout my entire professional software career is the longer you go between releases the harder they are. I&#8217;ve seen this in small teams, big teams, public, private, inside automatic, outside, whatever it is. If you can get to where you&#8217;re releasing more frequently, it just removes a ton of stress and burden on each individual release and I think makes for ultimately a much better process for everyone involved.</p>\n<p>Brian Krogsgard: Yeah, and I want to dig into more about the process. I was really surprised. I don&#8217;t think I saw a single person share your old blog post about the version 1.0 and the importance of shipping 1.0. Maybe we&#8217;re just getting really old. So referencing a blog post that&#8217;s that many years old is harder now. But yeah, I&#8217;ve been in the camp for a while now that it just seemed like you&#8217;ve got to get it out there. I felt like we always had an advantage in the WordPress landscape and this is one of the things I was worried about when you announced the big feature release style. Here are our three goals and we&#8217;re going to make the releases strategic to that. We had the benefit of iteration when we had the regular releases. So overall do you feel like the tradeoff of losing the regular major releases was worth it in order to get the big thing shipped?</p>\n<p>Brian Krogsgard: I think of like Drupal, the struggles and the boundaries they had going from 6.0 to 7.0 to 8.0 and it was almost like a whole new thing. This was really our first time, in a really long time at least, maybe ever, that you feel like you update and it&#8217;s in some ways a whole new thing, and it was a long release cycle that led up to that. So do you think that tradeoff was worth it or do you think there was a tradeoff? Is my assumption a poor one?</p>\n<p>Matt Mullenweg: Well, there was in that we didn&#8217;t do a major release for a year. We did slip some things that would previously be in major releases in the minor releases, in the 4.9.X kind of releases, so that helped. That&#8217;s a good question. I think that in 2019 we can do both. So we can keep some really super rapid public iteration and the feature plugins, and who knows, I&#8217;d actually love to see a few more kind of areas of WordPress that we want to innovate in or expand in, take more of this plugin approach. And then we also have a lot of great stuff in the hopper for some major releases. I think we&#8217;ll be able to do &#8230; there was a lot of talk at contributor day as we were looking at it.</p>\n<p>Matt Mullenweg: It actually slipped my mind that we did that whole code reformatting and JavaScript reorganization in trunk, and that&#8217;s not in 5.0, right? Because we branched off 4.9.8 to make it as stable and as few changes as possible. So we&#8217;ve got actually, I think there&#8217;s another 200 patches already in trunk that weren&#8217;t in 5.0. So we&#8217;ve just got a lot of good stuff already in there, including the whole reorganization that you kind of put that together plus maybe ServeHappy and the white screen protection and some really cool stuff that&#8217;s kind of more like small stuff. That could be a 5.1 right there. I could see that going in the beta January, RC in February.</p>\n<p>Brian Krogsgard: Yeah, talk about ServeHappy. I mean, for I don&#8217;t know, five, six, seven years, people have wanted, demanded PHP upgrades and it was a footnote in this state of the word.</p>\n<p>Matt Mullenweg: I should have done it as one more thing.</p>\n<p>Brian Krogsgard: One more thing, yeah. Had to really get all the developers on your team for that one. So you made a commitment to in 2019 have a staggered upgrade process to mandate certain versions of PHP. Remind me if I&#8217;m incorrect, 5.6 in the Spring and 7.0 next winter. Is that basically the timeline?</p>\n<p>Matt Mullenweg: Yeah, that&#8217;s the idea and we&#8217;re just going to go through. And again this is, just like with Gutenberg, it&#8217;s not about changing a version number or something. It&#8217;s really about bringing the whole community along for the ride, so we need to scan all the plugins. For 5.6, I think we&#8217;ll actually be able to update them or send patches to maintainers, even update and maintain plugins, because those changes are pretty easy. Seven is tougher and I think that is, we&#8217;re targeting December for that. I could see that slipping, just depending on whether host in the meantime and everyone else is able to get there, but even getting to 5.6 opens up a ton of possibilities, including with things like OAuth and GraphQL and namespaces, and there&#8217;s some pretty cool features. 5.6 is ancient at this point. It had a lot of improvements over 5.2.</p>\n<p>Brian Krogsgard: And a lot-</p>\n<p>Matt Mullenweg: And we still have a lot of folks on these older versions, so part of the reason we&#8217;re giving ourselves time as well is to, if we can run some analytics to figure out which host these old sites are on Ron and reach out to them, try to work with them.</p>\n<p>Brian Krogsgard: Do you think a part of the reason why you even think this is possible, for a long time, I mean, people were running WordPress across a huge spectrum of versions of PHP. Do you think part of the reason why you even think this possible is the hosting relationships that had been made between the community and the hosting companies over the past few years? Because that&#8217;s something that I&#8217;ve felt like has been quite significant. The efforts that, if you look at the big ones, the GoDaddy and the Bluehosts of the world, the amount of commitment they&#8217;re giving to the community, do you think that&#8217;s a big part of it? And how hard is the long tail going to be to capture, do you think?</p>\n<p>Matt Mullenweg: That&#8217;s a big question. First, I&#8217;ll say that the improvement of hosts, particularly the big ones in becoming kind of like WordPress first, providing a really first-class WordPress experience from security updates, everything, it&#8217;s probably been the biggest change in the WordPress ecosystem over the past five years. And I have huge admiration for them because they&#8217;re doing this for millions of sites, thousands of support folks. They&#8217;re really moving some really, steering some really large ships and the results have been fantastic. We got, I think it was up to 68% of our WordPress was on 4.9 by the time 5.0 come out.</p>\n<p>Brian Krogsgard: Yeah, that&#8217;s great.</p>\n<p>Matt Mullenweg: But in terms of what&#8217;s going to make the PHP upgrading easier, it&#8217;s really a combination of everything, including time, including some of this white screen protection stuff that we&#8217;re doing. If we can back port that, you know we still backport to 3.7 all of our security updates?</p>\n<p>Brian Krogsgard: Mm-hmm (affirmative).</p>\n<p>Matt Mullenweg: Which is kind of wild.</p>\n<p>Brian Krogsgard: It is. It&#8217;s great for security of the Web broadly, but it&#8217;s quite something.</p>\n<p>Matt Mullenweg: Yeah, if we can do that for some of this, maybe we can put some of this white screen upgrade protection into those old versions, so that way we can kind of protect people who might be doing plugin and theme or core updates from breaking their site in programmatic way. Um, it&#8217;s also the work that&#8217;s gone into updates. We know we migrated to a new data center this year for WordPress.org It&#8217;s like, I forget the exact or something like five or 10 times more powerful than the old one.</p>\n<p>Brian Krogsgard: Wow.</p>\n<p>Matt Mullenweg: Almost no one noticed. But you notice that there&#8217;s no more 503s when we run the updates, and things can go faster. This means we can do auto updates better, which means that we&#8217;ll be able to do opt-in for core and plugin and theme auto updates and then maybe move that to opt-out 2020. These are all just things that have been going on that represent thousands of hours of work from hundreds of people that set the stage so we can do stuff. It&#8217;s part of the reason I think that we will be able to move a lot faster in 2019. We had to stop core ,essentially freeze it for Gutenberg, because we were building a new foundation and you can&#8217;t build the house on top while you&#8217;re also pouring the concrete, right? Things will sink. They&#8217;ll get off center. I&#8217;ve never built a house so I don&#8217;t know this analogy all the way, but now we&#8217;ve got the foundation. We&#8217;ve got this framework and things being built on top of that framework. We&#8217;re already starting to see the benefits to things like keyboard navigation and accessibility when they&#8217;re built using Gutenberg fields that already have this kind of baked in.</p>\n<p>Matt Mullenweg: So I think that we have the opportunity to do just a massive upgrade not just of the editor but of every single plugin, every single theme, every single person&#8217;s experience with WordPress because think about it. No one just runs core. Cool if we do Gutenberg in core? Ultimately it doesn&#8217;t matter. Everyone&#8217;s got five, 10, 20 different plugins. They&#8217;ve got their theme which might implement who knows how many additional features baked into the theme? Probably dozens, if you think about all the customization options, that&#8217;s all going to be able to be reimagined now and already is. We see some of this, over 100 themes in the plugin directory. You might have noticed we put the Gutenberg-ready plugins at the very top, even above featured. We&#8217;re really trying to get everyone on this train.</p>\n<p>Brian Krogsgard: Do you think there was a messaging gap in a trying to get across the idea that Gutenberg is a foundation rather than a window dressing or wallpaper or whatever other nonstructural housing component we want to compare it to?</p>\n<p>Matt Mullenweg: Well, I think it&#8217;s easy to say that there was a messaging gap and that communication could have been 10 times better or whatever, because there are obviously some people who wren&#8217;t on board and still aren&#8217;t on board. So now, is there anything that could have gotten everyone 100 percent?</p>\n<p>Brian Krogsgard: No.</p>\n<p>Matt Mullenweg: I don&#8217;t know, but I think we will always strive to do better. And ultimately, I mean, one of the things that made me pretty confident about the release wasn&#8217;t that Gutenberg is perfect. It&#8217;s not. By the way, it&#8217;s still not right for a ton of people, but that&#8217;s okay. You know WordPress, unlike almost every other SaaS service or software use gives you control. And the fact that we have classic editor as a first party supported official thing and that anyone for whatever reason, literally any reason, can still use the old experience instead. That&#8217;s what I meant when I said 5.0 was going to be anticlimactic, not that it meant Gutenberg was perfect or ready for everyone, but that forever was not wordy. They&#8217;re just a click or two away before or after the release from having the experience that they used to.</p>\n<p>Brian Krogsgard: Yeah, one of the things I like to remind myself of is that neither was TinyMCE perfect or right for everyone.</p>\n<p>Matt Mullenweg: Well, no.</p>\n<p>Brian Krogsgard: And that&#8217;s why it was being replaced. So I think sometimes we do have to look at what are we trying to replace and what do we have right now? Is that worth getting out into the world and iterating on?</p>\n<p>Matt Mullenweg: Did you see those user tests videos?</p>\n<p>Brian Krogsgard: I did. Unfortunately my wife said, &#8220;Do you want to go see the Harlem Globetrotters?&#8221; And I was like, &#8220;Absolutely.&#8221; And I didn&#8217;t have WordCamp US on my calendar yet.</p>\n<p>Matt Mullenweg: Oh, don&#8217;t worry, don&#8217;t worry.</p>\n<p>Brian Krogsgard: So we double booked, so I re-watched the whole State of the Word, including the user tests, the Q and A, the whole thing, and it was pretty amazing seeing those user tests. I&#8217;ve seen people do user tests before. They&#8217;re often really terrible.</p>\n<p>Matt Mullenweg: Painful.</p>\n<p>Brian Krogsgard: That&#8217;s why for years I&#8217;ve tried to make my own message that we need to continually support things that make WordPress easier to use, so I think that was a good thing to highlight in the State of the Word.</p>\n<p>Matt Mullenweg: And by the way, I probably would&#8217;ve picked the Harlem Globetrotters over me as well, so o need to apologize.</p>\n<p>Brian Krogsgard: It was the first one I&#8217;ve missed since like 2012.</p>\n<p>Matt Mullenweg: That&#8217;s awesome. That&#8217;s great. I&#8217;m an average live experience. The Harlem Globetrotters are amazing live.</p>\n<p>Brian Krogsgard: They are.</p>\n<p>Matt Mullenweg: You can always catch State of the Word on vide later.</p>\n<p>Brian Krogsgard: They are. I may as well use the opportunity too to thank [David Bisset 00:15:39], because he did a fantastic job with both tweeting things and just generally keeping people that follow along with Post Status up to date and it turned out to be a good outlet for him because twitter banned his personal account because they thought that he was tweeting so much.</p>\n<p>Matt Mullenweg: Wasn&#8217;t that wild?</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: I know. That guy is a national treasure of WordPress.</p>\n<p>Brian Krogsgard: He is. He is. If there was a community spirit award, he should win it.</p>\n<p>Matt Mullenweg: Absolutely.</p>\n<p>Brian Krogsgard: So he stood up to ask a question during the State of the Word and unfortunately ran out of time, so I would-</p>\n<p>Matt Mullenweg: Right, I felt so bad that we didn&#8217;t get to &#8230; There were a lot of people in line, but just some of those earlier questions were a bit longer and I could tell the room was starting to, like I think we were already like an hour 45. We were pretty far into it, so &#8230;</p>\n<p>Brian Krogsgard: Yeah, and maybe we&#8217;ve put a 30-second clock next year for people to ask a question.</p>\n<p>Matt Mullenweg: I&#8217;ve been thinking about that, like there were some definitely things in the room this year, like it was very dark in the audience so it was a little harder to see. I think that also subdued people. There was a little more distance between the stage and the people which looked a little more theatrical, but I think also made the audience a bit more disconnected. And even, there was a funny thing. You saw the spotlight on the question askers?</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: It was so bright and at an angle that it was shining in the eyes of everyone sitting next to them. So after the first or second question there, there was a huge hole in the audience next to the mic because we were just getting like it had this crazy spotlight on it. I think we can figure out some different ways of doing lighting or doing the questions in the future that might be a bit a bit easier.</p>\n<p>Brian Krogsgard: Well, you&#8217;ll have that opportunity in St Louis, right, for the next two years.</p>\n<p>Matt Mullenweg: Woo hoo, St. Louis. I&#8217;m very excited about that.</p>\n<p>Brian Krogsgard: Yeah, I&#8217;m excited about that too. I haven&#8217;t been there in a long time, and what David-</p>\n<p>Matt Mullenweg: I love that we&#8217;re doing the opposite of Amazon. They had the opportunity to pick any city in America and they go to D.C. and New York.</p>\n<p>Brian Krogsgard: I know.</p>\n<p>Matt Mullenweg: They&#8217;re both amazing places, but not really shining a light on places that don&#8217;t get as much love already.</p>\n<p>Brian Krogsgard: Yeah, I think my-</p>\n<p>Matt Mullenweg: And we&#8217;ve had Philly, Nashville and now St. Louis, I really dig the WordCamp US thing.</p>\n<p>Brian Krogsgard: Yeah. I have feeling that Amazon may have been including some political reasoning and in their strategy for that, but that&#8217;s okay. WordPress doesn&#8217;t have to do that. We can go wherever we want.</p>\n<p>Matt Mullenweg: We can go to Canada, which was one of the questions, which I thought was kind of cool.</p>\n<p>Brian Krogsgard: Including Canada, which was a good question. I actually had that brought up to me before WordCamp about the U.S./Europe thing and whether we can learn from that and have WordCamp Americas or something.</p>\n<p>Matt Mullenweg: Yeah, what&#8217;s your thought on Central America in that equation?</p>\n<p>Brian Krogsgard: Yeah, I mean I think that there&#8217;s a lot of cultural differences, but I think anything Americas, there&#8217;s some common themes of people that work hard, people that explored many centuries ago. So I don&#8217;t know, I&#8217;m probably not the best person to answer that type of question, but &#8230;</p>\n<p>Matt Mullenweg: I&#8217;ve been thinking about it a lot, like what are the logical divisions and because we do have some rules in the WordCamp world around like what could be &#8230; I&#8217;d love to see a WordCamp Asia, for example. Asia is obviously geographically, culturally and language-wise, incredibly diverse.</p>\n<p>Brian Krogsgard: Right, I think the lingual differentiation would be a challenge, so I don&#8217;t know what the best regions would be but perhaps-</p>\n<p>Matt Mullenweg: But then look in Europe.</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: It has a ton of languages [inaudible 00:19:08] English.</p>\n<p>Brian Krogsgard: I always envy friends in Europe because they all speak like five languages plus, and some of them speak better English than I do.</p>\n<p>Matt Mullenweg: Oh, for sure. Have you ever seen a map of the lower 48 overlaid over Europe?</p>\n<p>Brian Krogsgard: Yeah, it&#8217;s very, very similar in size, so-</p>\n<p>Matt Mullenweg: Yeah, it&#8217;s actually, you forget how large actually the lower 48 of the U.S. is that it covers kind of like into Europe, pretty far into Russia and Turkey and Middle East.</p>\n<p>Brian Krogsgard: Yeah. We think of Alabama and Houston or Birmingham, Alabama and Houston, Texas as pretty close, but that could be different countries if we were in Europe with different languages and culture. It&#8217;s a reminder of the diversity in our space and how serving different cultures and people from different backgrounds is extremely important. All right, so David&#8217;s question was, what are the dates for WordCamp next year? Do we have any idea?</p>\n<p>Matt Mullenweg: Oh, I think we know them. I&#8217;ll put them out later. They&#8217;ll be in a blog post or something.</p>\n<p>Brian Krogsgard: Okay, he will be disappointed again.</p>\n<p>Matt Mullenweg: Well just, I don&#8217;t know if I could tell you the day of the week of my birthday or something. I&#8217;m pretty bad at dates.</p>\n<p>Brian Krogsgard: No, that&#8217;s fine.</p>\n<p>Matt Mullenweg: As you might guess from-</p>\n<p>Brian Krogsgard: Is it going to be in December again, though?</p>\n<p>Matt Mullenweg: I believe so. Don&#8217;t hold me to anything there. I will officially find something.</p>\n<p>Brian Krogsgard: But late in the year still.</p>\n<p>Matt Mullenweg: Yeah, yeah, so I think that we&#8217;ll put up like a placeholder site for 2019, and there will definitely be some tweets and some official stuff saying the dates.</p>\n<p>Brian Krogsgard: Okay.</p>\n<p>Matt Mullenweg: But to your earlier point, I actually feel what you just described of going between countries in Europe, I feel that when I&#8217;m, excuse me, on the East Coast of America because I can actually drive eight or 10 hours and still be in Texas. I can drive two hours over here and cross through three different states. And that was one of the points that I tried to make. This was actually I think one of my weaker Q&amp;As. I had two answers that were two of the worst answers I&#8217;ve given probably the past few years, and one was what people heard me say, which I wasn&#8217;t trying to say, to Morton&#8217;s thing.</p>\n<p>Matt Mullenweg: Which I was trying to make the point that in a distributed organization or where we have people working across things, you can read into someone&#8217;s language and it might not be their first language, so it&#8217;s really good to give the benefit of the doubt and realize that we&#8217;re not all speaking our native tongue. And so things might come across as harsh or worse or rude or things, when it&#8217;s just not at all. It&#8217;s certainly not the intention of the person to communicate that way. And the other was the answer, I think it was Birgit&#8217;s question about being hired to work on things.</p>\n<p>Brian Krogsgard: Yeah, corporate sponsorship for WordPress work.</p>\n<p>Matt Mullenweg: Yeah, neither &#8230; I think my brain was just a little fried by the end of the day.</p>\n<p>Brian Krogsgard: So what would you adjust in terms of, I think that question was around how to &#8230; I was actually with you with Morton, that I didn&#8217;t notice the issue. It seemed like you were pretty clearly speaking about broader communication things, not specifically with his communication, which is-</p>\n<p>Matt Mullenweg: I would never make fun of Morton&#8217;s or anyone&#8217;s skills speaking another language.</p>\n<p>Brian Krogsgard: Yeah, and that one was pretty clear to me. But the one about corporate sponsorship, do you think there&#8217;s a place for &#8230; How do you encourage independent work on the WordPress community, nonprofit side of things? Is there a place or a way that that can be done without corporate sponsorship? Because I know, I mean I&#8217;m self-employed and I can personally understand if I suddenly gave 10 or 20 hours a week or whatever amount of time to the core project in a non-revenue generating way that would be felt. So is there a way that that can be done, or do you think corporate sponsorship of community work is really the only way to go about it right now?</p>\n<p>Matt Mullenweg: Well, let me take a second crack at this one. First and foremost, I never want to downplay the contributions of people doing it in their spare time.</p>\n<p>Brian Krogsgard: Yeah, and it is, I mean it&#8217;s astonishing and I could be that person, too. I don&#8217;t choose to be that person in this stage of my life, but yeah, it&#8217;s amazing what people are doing completely outside of work time.</p>\n<p>Matt Mullenweg: Yeah, and I also don&#8217;t want to understate how big an impact on the WordPress project, two to four hours a week out of the 168 can have a really huge impact on some big areas. Even a single hour a week, if put in the right place, can move mountains. And WordPress was largely built by volunteers and people doing it in their spare time, and I worry to say, to ever get to a point where we&#8217;re saying we only value people who are doing it full time, or it&#8217;s only possible to make a change if you&#8217;re doing it full time. So that&#8217;s one point I was trying to make, that let&#8217;s never downplay the value that people can do with just a little bit of contributions. Five for the Future is just two hours a week in a work week, right?</p>\n<p>Brian Krogsgard: Right, yeah, and that was the question [Daniel Bock Huber 00:24:12] had was if you had plans or iterations that you thought would be good for Five for the Future?</p>\n<p>Matt Mullenweg: Oh, for sure. The second is that the WordPress Foundation is not designed to be an employment entity. Now, there&#8217;s no employees. There&#8217;s no HR. There&#8217;s no benefits. There&#8217;s no payroll. There&#8217;s no anything, and going from zero to one there is actually a pretty big thing. It is designed to give grants. We can give money to other organizations. By the way, I think that there&#8217;s also a big opportunity for other nonprofits to be part of this. There&#8217;s no reason to say only for-profit corporations can sponsor people that work on WordPress. I would love to see more nonprofits that by the way have a lot more expertise in some of the areas that we want more contributions in, including design, accessibility, privacy, internationalization.</p>\n<p>Matt Mullenweg: These things, there&#8217;s full nonprofits dedicated to that have often sometimes very large staffs and pretty large budgets, journalism. These I think are really fruitful areas, and in fact one of the things that, I don&#8217;t know if you saw Morton&#8217;s talk, a lot of people I thought misread it. Maybe I misread it as well. When he was talking about open governance, my take was that he was talking about getting WordPress a seat at the table, and discussing these regulation changes and et cetera happening. I think the example last year was, there was this meeting at 10 Downing Street. Who was there? Was WordPress represented?</p>\n<p>Matt Mullenweg: And he started talking about the Web Foundation, and I began thinking. I was like, &#8220;Wow, well, WordPress only represents a third of Websites, and not even, really. It&#8217;s a third of the top 10 million. Another foundation like the Web Foundation actually might be a better vehicle to try to advocate on the open Web as a whole, versus just the people who happen to be using a single CMS.</p>\n<p>Brian Krogsgard: Yeah, and I don&#8217;t want to speak for him in terms of which audience he was trying to, or which group he was trying to represent in terms of within WordPress, or WordPress within the broader Web. I do think that there are often questions about governance of WordPress. You have long been the central vision of the project, and then delegated the execution of that vision to many other people who then lead this project, which is massive at this point. One of the things I&#8217;ve always asked you for several years now was, how many people do you have directly reporting to you?</p>\n<p>Brian Krogsgard: Because one of the things I find to be important is under this model, where your vision is required, then if you&#8217;re spread out so thin it requires these sprints to focus towards WordPress, rather than always being able to have kind of a constant flow, even if it&#8217;s a minority of your time, going towards that, establishing that vision for WordPress. So, how have you evolved in that regard? I know you&#8217;re-</p>\n<p>Matt Mullenweg: What was the number last time you asked me?</p>\n<p>Brian Krogsgard: It was high.</p>\n<p>Matt Mullenweg: What is high? There was one point it was like 26 or something.</p>\n<p>Brian Krogsgard: Yeah, it was in the 20s. It was in the 20s last year I think when we talked about it.</p>\n<p>Matt Mullenweg: Yeah, it&#8217;s under half that now.</p>\n<p>Brian Krogsgard: That&#8217;s great.</p>\n<p>Matt Mullenweg: So, that&#8217;s been really good. There&#8217;s been a lot more leaders, but I would actually argue the point that WordPress has always been sort of my vision being set, or even my direct leadership. There was a good four or five years there where the leadership structure, because we&#8217;ve experimented with lots of different, we don&#8217;t call it governance, but essentially leadership structures in WordPress. For a while, we had kind of the &#8230; It wasn&#8217;t a committee approach, but essentially like the lead developers consensus approach. We did that for a few years.</p>\n<p>Matt Mullenweg: Even from the beginning it wasn&#8217;t just me. It was me and Mike Little, so it&#8217;s never been solo. Then we went to where the release lead was the final decider, including over me, so that was probably, I don&#8217;t know, 3.9 to 4.7 maybe, that including could overrule me as project lead for what was in the release or not, and that was to try to give a little more autonomy and flexibility to release leads. But the big change was a few years ago I said, &#8220;Okay, I&#8217;m going to take back over core WordPress development,&#8221; and that was to try to provide a &#8230; Try to make some of these big changes happen. So right now it is much more of a benevolent dictator model, although both of those words are questionable. But, I don&#8217;t see that as the permanent forever structure, you know? [crosstalk 00:28:54]-</p>\n<p>Brian Krogsgard: One problem with that is-</p>\n<p>Matt Mullenweg: I don&#8217;t know if I can sustain this forever. I mean, this is a pretty intense period and we&#8217;re doing some pretty intense work, and I&#8217;ll need a break at some point, too.</p>\n<p>Brian Krogsgard: Yeah, and how do you, or do you think there&#8217;s merit in opening that up in some way to certainly have more community input, but sometimes that&#8217;s not good, you know? Sometimes the central vision idea can be more productive, but when you bring that into open source software versus running a company, maybe there&#8217;s different consequences. So have you given any thought to what does WordPress look like after this phase in terms of a governance structure?</p>\n<p>Matt Mullenweg: It&#8217;s hard, because I haven&#8217;t seen any models where anything resembling voting works, you know?</p>\n<p>Brian Krogsgard: Yeah, for running software, you mean.</p>\n<p>Matt Mullenweg: Yeah, and for choosing a direction. It&#8217;s not that many models for consumer-facing software. There&#8217;s some for server-facing software, where sort of like a committee approach works, you know? It seldom creates great user experiences. You kind of want, I&#8217;m not saying it always has to be me, but what I want is a strong, opinionated, thoughtful leader doing, setting a bold direction, taking experiments and being willing to fail, comfortable with failure, is I think what you need to create great software.</p>\n<p>Brian Krogsgard: So how do you-</p>\n<p>Matt Mullenweg: And that&#8217;s tough, and by the way, we&#8217;ve had lots of those leaders in the history of WordPress, and I think that&#8217;s been the success. It&#8217;s not just because I&#8217;m doing anything.</p>\n<p>Brian Krogsgard: Sure.</p>\n<p>Matt Mullenweg: It&#8217;s that we have lots of folks and we have, as a community including myself, invested that authority and power in them, and that trust. It doesn&#8217;t mean that it&#8217;s always been right, like we&#8217;ve definitely done things that we might undo later or that were mistakes, but the ability to make those mistakes is what you need for an innovative organization. When you look at any organization, private or public, it&#8217;s too afraid to fail, that&#8217;s when you get this kind of incrementalism. That&#8217;s when you get this kind of fear of change. That&#8217;s when you essentially stagnate, and if you were to point to any place that software goes poorly, whether that&#8217;s in government or companies that don&#8217;t innovate or get disrupted by smaller upstarts, anything, it&#8217;s because one of those happened or probably all of those things happened. They got too successful and then they were afraid to fail, because it was too embarrassing and they had too much to lose, and then they stagnate.</p>\n<p>Brian Krogsgard: All right, we&#8217;re here to take a quick break and I want to thank our partner, iThemes, long-time supporter of Post Status. I&#8217;ve got Cory Miller on with me to talk about what they&#8217;ve got going on. Hey, Cory.</p>\n<p>Cory Miller: Hey, Brian, thanks for having me on.</p>\n<p>Brian Krogsgard: Yeah, it&#8217;s my pleasure and I appreciate your support over the years. I was hoping that you could just tell me maybe what&#8217;s a big success iThemes had in 2018, and what you&#8217;re looking forward to next year?</p>\n<p>Cory Miller: Yeah, as you know in January of 2018 now we were acquired. iThemes was acquired by a great hosting company named Liquid Web, so this year has been spent integrating. We are almost done with the first round of integrations for our key product, iTheme Sync, which promotes site management for freelancers and agency WordPress Websites, BackupBuddy, our long-time popular plugin, and securities. So we&#8217;re almost done with the final round of that. You know in any transition there&#8217;s always bumps, but it&#8217;s been a really good ride so far.</p>\n<p>Brian Krogsgard: Yeah, have you been getting good feedback from LiquidWeb customers so far, or I guess are you looking forward to seeing iThemes products more integrated with LiquidWeb&#8217;s stuff?</p>\n<p>Cory Miller: Very much so. We saw hosting as the future for WordPress. All of the big hosting companies making significant investments in WordPress, and this was a way to join forces with a great hosting company and for our products, our team, to live on into the future doing really good things in WordPress.</p>\n<p>Brian Krogsgard: Cool, and iThemes products are still available outside of LiquidWeb as well. You can use them on any host that you choose, or a naked VPS if you want help managing a server that you want to pull all the lever, you can still do that but you can use all the iThemes tools to help you manage the day, and [inaudible 00:33:31] out of your WordPress Website. I&#8217;m really excited for you guys and what you have going on, and look forward to hearing more as next year comes along. Thanks for being on real quick, and if people want to learn more about what you&#8217;ve got going on, where do they go?</p>\n<p>Cory Miller: iThemes.com, best place to click some links and see if we are offering something that you&#8217;re in need of. We&#8217;d be happy to serve you.</p>\n<p>Brian Krogsgard: Awesome, well, thanks for being such a big part of the WordPress community these last 10 years plus, and a partner of Post Status for as long as Post Status has existed.</p>\n<p>Cory Miller: Yeah, we love Post Status. Keep doing what you&#8217;re doing, Brian. Thank you.</p>\n<p>Brian Krogsgard: Thanks, buddy. Bye. We&#8217;ve got another question from Ant in regards to giving people a seat at the table in a governance structure, which was seeking an update on the growth council, whether that was productive this last year, whether it happened. How can it happen going forward? I don&#8217;t know anything about what&#8217;s happened in the last year, so what have you learned there, and what&#8217;s happened?</p>\n<p>Matt Mullenweg: Yeah, so we created these two growth councils, one consumer one and one enterprise one, and we did these monthly meetings, video chats. And my goal with creating it was one, to bring some people together, so there are direct competitors in these meetings. It&#8217;s enterprise agencies that are bidding on the same clients. It&#8217;s Web posts that are advertising on the same key words and everything. And so you&#8217;d have like that as part of the discussion, and one of the goals also was to produce, improve essentially the WordPress experience.</p>\n<p>Matt Mullenweg: Some parts were successful, some parts weren&#8217;t, so I was amazed and humbled by how people came together. I think it really showed something I&#8217;ve tried to demonstrate with Automatic in the past, that you can both compete and work together for a greater good. People were both able, because it was a safe space, they were able to share things that were going on in their companies, things they were hearing from clients that they couldn&#8217;t talk about publicly, things they were seeing, experiences, in a safe space that generated some amazing discussions. I&#8217;ll also say selfishly that I learned a ton being part of these meetings, so it was really, really valuable for me.</p>\n<p>Brian Krogsgard: And that&#8217;s about how their organizations work and what&#8217;s important to them, or what kind of stuff?</p>\n<p>Matt Mullenweg: And the people they&#8217;re talking to, whether that&#8217;s consumers, kind of the more mass market side particularly with Web posts, but also with people doing trainings, people building small Websites, which is my kind of mental model was like, if it&#8217;s people spending under $100,000 a year for a site that&#8217;s the consumer group. If it&#8217;s over $100,000 a year, that&#8217;s the enterprise group. Not exact, but that was kind of like a rough mental model. And on the enterprise side, what are they seeing? It was so interesting as well, like most of the big agencies started building sites with Gutenberg kind of like February, March, and were launching them over the summer. Now at this point, they&#8217;re basically building everything. They&#8217;ve been building everything new with Gutenberg for the better part of a year.</p>\n<p>Brian Krogsgard: Yeah, I actually spoke with Tom Wilmot from Human Made and Jake Goldman from 10up both, and they&#8217;ve both expressed that they had an early embrace of Gutenberg and seen success with it. Somebody was telling me, I think it might have been Tom, that they showed off a demo of Gutenberg and instantly blew some Adobe experience manager style feature out of the water. Some company had spent gargantuan sums of money on the alternative experience, and they did a couple customizations with Gutenberg over the course of a couple weeks and showed them this as a prototype. It was already far superior to what their competition was putting forward, so from those-</p>\n<p>Matt Mullenweg: There&#8217;s got to be so much of that.</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: At Gutenberg, people have written bad versions of what Gutenberg is, including myself, for five years now. And now we&#8217;ve got this standard we can all build on. I actually had it right here. Human Made had this really cool white paper. I don&#8217;t know if you&#8217;ve seen this.</p>\n<p>Brian Krogsgard: Nice, yeah, they printed it.</p>\n<p>Matt Mullenweg: It&#8217;s glossy, it&#8217;s pretty &#8230; I mean, these are the types of things that for enterprises are really important. PDFs, white papers, case studies, and enterprise section of WordPress.org, important for that user group. For a consumer, a lot of things that that team talked about was the importance of talking about different use cases and allowing users to self-segment over the job they want to get done, and having some guides for that, some recommended plugins, essentially hand-holding them through the process of it.</p>\n<p>Matt Mullenweg: So I talked about what was successful about the councils. I&#8217;ll tell you what didn&#8217;t go as I hoped, producing things. I think because it was all often the CEOs of their companies or kind of the head folks, it was difficult for them to get time other than the meetings, in between the meetings, to just do work to produce for example a new enterprise section of WordPress.org. So actually on Saturday morning, I officially dissolved the councils.</p>\n<p>Brian Krogsgard: Okay.</p>\n<p>Matt Mullenweg: What I told the folks was, we&#8217;re not going to schedule out these meetings for the rest of the year. I left the Slack channels up so people could keep chatting if they want, and of course I said if anyone wants to keep meeting on their own, they&#8217;re happy to, or to continue the projects, and both groups said they would like to. The enterprise group wants to get the enterprise subsection of WordPress.org out. The consumer group wants to continue shipping some things, but it was a year and we didn&#8217;t ship these things, that honestly probably any &#8230; It could have happened within a month or two if it had had a lot of focus from any of the people involved. It illustrated to me actually the difficulty of a committee approach.</p>\n<p>Brian Krogsgard: Yeah, it makes me think of-</p>\n<p>Matt Mullenweg: One of the things that came up was the enterprise. We did drinks on Saturday as a kind of ending thing. It was a combined consumer and enterprise, and one of the things is they were like, &#8220;Hey, if you had just chosen one person to be in charge of this, that person could have said, &#8216;You do this, you do this, you do this,&#8217; it would have shipped probably pretty quickly.&#8221; But because no one knew who was in charge and who could tell other people to do things, I think it was Jake who said, &#8220;I&#8217;m not sure if I can tell Tom, &#8216;You need to finish this page,&#8217; or &#8216;You didn&#8217;t edit it.\'&#8221; Who&#8217;s in charge? And so that&#8217;s I think unintentionally illustrated an alternative group and management style that, because if it wasn&#8217;t adjusted and set up correctly, which is my responsibility, my fault, and not getting the results that we wanted. So, great experiment though, and I&#8217;m really, really glad we did it.</p>\n<p>Brian Krogsgard: Yeah, I wonder, you see movies or you see a senate hearing or something, and you have the primary people at the center table and then you have all their deputies on the outside. They&#8217;re still in a safe space, but they&#8217;re the people that actually go out and do things afterwards. It&#8217;s not like the senator or the CEO on that council necessarily that&#8217;s implementing, but they bring other people from their organization in to help the implementation component.</p>\n<p>Matt Mullenweg: I was kind of hoping more of that would happen. It&#8217;s true, some people on the councils were contributing individually, and some lead larger organizations so they can shepherd a lot of resources as well. So, I think there&#8217;s some of both that&#8217;s needed in the WordPress world. Yoast and myself are probably good examples, Yoast the person, not the company, of a leader who&#8217;s really passionate about areas, who also brings along a lot of their company to work on it.</p>\n<p>Brian Krogsgard: Yeah, they have a lot of manpower there.</p>\n<p>Matt Mullenweg: Oh, yeah.</p>\n<p>Brian Krogsgard: That they&#8217;ve got dedicated to core.</p>\n<p>Matt Mullenweg: Person power.</p>\n<p>Brian Krogsgard: Person power, thank you.</p>\n<p>Matt Mullenweg: Yoast had an incredible effect on Gutenberg and the 5.0 release, even though they&#8217;re smaller than all of the hosts, all of everything else. I think it&#8217;s a great example of Five for the Future.</p>\n<p>Brian Krogsgard: So I have one more process question, and then I want to dig into phases two through four, but Darren Ethier I think is how I pronounce his last name, he asked what were your thoughts process-wise on using GitHub for probably the most ambitious-sized project yet with WordPress from a feature plugin or feature point of view? Do you think it was encouraging enough to potentially start moving off track in SVN? I do know there was a make WordPress post that was about this, but I&#8217;m curious your personal experience, whether you liked being in GitHub day to day or using Git in the process, or if you missed track in terms of that development?</p>\n<p>Matt Mullenweg: I mean, I&#8217;m an early adopter of GitHub. My user name is literally the letter M, to show you how early it was, and I really like it. I think it&#8217;s a great product. Having kind of a parallel process, where I&#8217;ve now been involved pretty heavily in something on TRACK, involved pretty heavily on something on GitHub, there&#8217;s pluses and minuses. I wouldn&#8217;t say either is a panacea. The thing that actually makes the real difference is much more your engineering management. It&#8217;s your triage. It&#8217;s your process. It&#8217;s the testing. On both GitHub and TRACK, we made mistakes and had tickets that sat for weeks without anyone responding to them.</p>\n<p>Matt Mullenweg: That doesn&#8217;t have to do with the software. It has to do with the people, and I do worry the distraction of effort and time that switching source control and issue trackers and just also all the work that needs to be done to migrate all the tooling at the same time, if it would distract us from what&#8217;s actually most important in 2019, which is to tighten up some of our loose parts of the software. So that&#8217;s the only reason I&#8217;m hesitant to commit to saying that we&#8217;re going to do anything, particularly in 2019.</p>\n<p>Matt Mullenweg: Also, I am a big fan of GitLab, obviously. I see a lot of, I noticed a lot of comments on Helen&#8217;s post for actually advocating for GitLab. All of these things are getting better pretty rapidly. GitHub was slow for a while, and now they&#8217;re really picking it up. Time is kind of on our side if we switch later, because whatever we switch to will be six or 12 months better than it is today, and probably provide perhaps more of a compelling step function and user experience than is currently there, which is yes, I totally agree the interfaces are more modern and there&#8217;s better tools, and I do strongly prefer Git for branching and all these other things. There&#8217;s almost nothing you could tell me about either way that is an argument I haven&#8217;t heard or made myself. But it&#8217;s more just about a community focus thing, and what is the issues most urgently impacting WordPress users, both current and potential, today?</p>\n<p>Brian Krogsgard: I like what you say there in terms of the urgency factor, because I think I agree with you. Personally, if I were to do something to try to actually make code changes in SVN, I would always have to go remind myself, how do I patch something, and do I have the tools on my modern MacBook to do so? Whereas by &#8230; Go ahead.</p>\n<p>Matt Mullenweg: I was just going to say, we&#8217;ve built a lot of bridges between them as well. WordPress is synced to Git. You can do things both ways. We have tools for migrating patches between them. We&#8217;ve got official GitHub for WordPress. There&#8217;s a lot of stuff out there, but there is a point when I really want to focus on the developer experience and really invest some serious, serious time into that, but we&#8217;ve got to get the user experience right first.</p>\n<p>Brian Krogsgard: Yeah, I think I&#8217;m with you in terms of that priority, but long-term bringing on new people to be comfortable developing on the software, most people in their day to day are in GitHub or in Git more broadly, so even the self-hosted Git version or GitFlow I think in the long run would be good, but I like what you said there about the urgency component.</p>\n<p>Matt Mullenweg: Well, that&#8217;s one of the things I was looking at a lot, because that is one of the I think better arguments for using something centralized like GitHub, is that a lot of people have GitHub accounts.</p>\n<p>Brian Krogsgard: Mm-hmm (affirmative).</p>\n<p>Matt Mullenweg: Basically there was a while, I&#8217;ve reviewed probably over 10,000 engineering applications for Automatic. Every single one of them has a GitHub link. There&#8217;s definitely something to be said for that. I didn&#8217;t notice that big a difference in type or number of contributions, so it is a barrier to entry to make a WordPress.org account. It doesn&#8217;t appear to be the most salient factor in determining whether people submit patches or are active in TRACK or not-</p>\n<p>Brian Krogsgard: Interesting.</p>\n<p>Matt Mullenweg: Active in [inaudible 00:46:57] TRACK or not.</p>\n<p>Brian Krogsgard: I&#8217;d be curious how that ends up working if it was officially there, but nevertheless let&#8217;s move on to-</p>\n<p>Matt Mullenweg: Well, just look at the numbers, because Gutenberg was as official as anything, and the numbers of contributors to that versus the number of contributors that we have in any given core release, kind of similar. I think that the hard part is actually deciding that you&#8217;re going to dive into the code. The hard part is saying like, &#8220;I&#8217;m going to take this code. I&#8217;m going to figure out the problem and then submit the patch.&#8221; And once you&#8217;ve been through that, making an account one place or another, I think it&#8217;s probably something you&#8217;ll do one way or another.</p>\n<p>Brian Krogsgard: So phase one of Gutenberg mostly complete, or at least out the door, and you&#8217;re going to be iterating on this every two weeks like you told me before. Let&#8217;s talk about phase two through four, and let&#8217;s start with just why do you think that the order that you established things in is the right order? Why do you think this is the right direction, I guess, overall?</p>\n<p>Matt Mullenweg: Yeah, some of it is sequential and some of it is not. Are you familiar with the Kubler Ross Five Stages of Grief?</p>\n<p>Brian Krogsgard: No, I&#8217;m not.</p>\n<p>Matt Mullenweg: It&#8217;s like anger, denial, depression, acceptance. You&#8217;ve probably seen these before.</p>\n<p>Brian Krogsgard: Yeah, I&#8217;ve seen this in terms of markets. It&#8217;s the same stages of grief are identified in market cycles, so like in the stock market it&#8217;s a very similar thing, but I didn&#8217;t know it was called that.</p>\n<p>Matt Mullenweg: I don&#8217;t have one on my desk, but I actually have some glasses that I often use for drinks that have little markers on them, and it actually has the five stages.</p>\n<p>Brian Krogsgard: Nice.</p>\n<p>Matt Mullenweg: We could put that in the show notes for the podcast, a link to those.</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: A common misperception, I ended up actually reading one of her books called On Grief and Grieving, and it was actually finished posthumously, so she actually passed away in the process of it. This is I think Elizabeth Kubler Ross, or I forget the exact name, but amazing book. Good to read even if you&#8217;re not going to go through grief or grieving, because we all do at some point. One of the most fascinating things I took from that book was people think of those stages as sequential, and actually they can happen out of order, and they can happen simultaneously. In fact, you can go through anger and denial and acceptance and everything all in the same kind of 10-minute period.</p>\n<p>Matt Mullenweg: That was a really fascinating insight to me just of the human condition, because we are often more complex and less sequential than sometimes our simplified systems would like to say, or we&#8217;d like to think. Development is the same way. Phase one is not stopping where phase two is starting, and I think bits of phases one through four have already happened and will continue to happen as we go through it. It&#8217;s just more about priorities. We&#8217;ve gotten the editor experience to the point where I think it&#8217;s pretty darn decent, especially for new users. Now people, if you look at people who started using WordPress in a post-Gutenberg world, of which there are now hundreds of thousands, so they&#8217;ve only known Gutenberg. This is that example of the support person who said, &#8220;Bring me back the simple editor,&#8221; and they meant Gutenberg?</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: What is the new barrier that they&#8217;re running into? What&#8217;s the new wall they&#8217;re hitting? It&#8217;s the rest of the site. It&#8217;s customization. It&#8217;s widgets.</p>\n<p>Brian Krogsgard: So for those that don&#8217;t have these phases locked down in their brain, phase two is customizing outside of the post content itself as the next point of emphasis. So this could be widgets, menus and miscellaneous content. David posted a funny picture on Twitter where you looked like you were in deep thought during the State of the Word and he said, &#8220;I wonder what Matt&#8217;s thinking about right now?&#8221; You said it was probably the process of transporting menus to Gutenberg.</p>\n<p>Matt Mullenweg: Oh, yeah.</p>\n<p>Brian Krogsgard: Moving, I feel like this is something that&#8217;s happened every few years [crosstalk 00:51:12] in WordPress, it&#8217;s like the old menu system, then the new menu system, then the customizer menu system. Now we&#8217;re talking about menus here, and also not calling it menus but reshaping to navigation.</p>\n<p>Matt Mullenweg: And navigation block, I think is probably a good way to put it.</p>\n<p>Brian Krogsgard: Yeah, it seems like we&#8217;ve got some debt in regards to spending time on things that then we don&#8217;t use for a super long time, so how can we do the Gutenberg way of site customization and content and try to be efficient and long-lasting with that effort?</p>\n<p>Matt Mullenweg: Well, I mean first we&#8217;ll start doing it in plugins, in the Gutenberg plugin actually, just like we did for the editor. And so we can have, one of the reasons Gutenberg is where it is is because we did do a lot of user testing along the way, and it wasn&#8217;t just testing mock-ups or ideas. We had the actual working plugin on actual working WordPress sites so they could run. That makes a world of difference, so we&#8217;ll be able to do that for the customize, replacing widgets.PHP, piece of cake. That&#8217;s just taking over the page. The customizer is a little trickier, but we can do it because all of Gutenberg was designed to be responsive.</p>\n<p>Matt Mullenweg: Essentially, the customizer side bar is very similar to a mobile view, a narrow screen. It&#8217;s kind of like instead of a wide version, it&#8217;s a narrow version of that interface, so I think we can slip in there. Mainly it just requires a lot of rethinking, and there are some tough concepts that currently blocks don&#8217;t have, like the idea of widget visibility, which is [crosstalk 00:52:49].</p>\n<p>Brian Krogsgard: Yeah, I was about to say conditionality, or like show it here but not there. That&#8217;s one of the experiences that seems like it could get really confusing, because someone&#8217;s on a post and they change a sidebar, and therefore they think they changed it just there but they changed it everywhere, vice-versa. There&#8217;s a lot of UX things that seem like they could get complicated.</p>\n<p>Matt Mullenweg: Yeah, so we&#8217;ve got to figure that out, to be honest. I don&#8217;t have the answer right now. We&#8217;ve got to experiment and test our way into what works there, because there are some powerful and complex concepts that I think we can maintain, but just make a lot more intuitive and also make not so in people&#8217;s face. So if they don&#8217;t need to have widgets or blocks that only show up on the sidebar of search pages, it&#8217;s not kind of in their face and making them think about things. It&#8217;s that whole thing, making it more powerful and more intuitive at the same time.</p>\n<p>Matt Mullenweg: But currently, blocks don&#8217;t have a concept of that, but if we solve it for sidebars, widget areas, whatever you want to call it, perhaps we could solve that for blocks everywhere they&#8217;re used. Showing different headers on different pages is not something that is currently supported by most themes on different types of templates, but why not? That would actually be pretty cool, different footers on different types of pages. I could easily imagine different types of sites that would do this.</p>\n<p>Matt Mullenweg: It also raised a good point, which is kind of what has always been one of my bugaboos about front end editing, is that when I&#8217;m writing, I want to focus. I don&#8217;t want to see my header and footer and sidebar and all this other stuff, much less edit them. I think, I mean I&#8217;ve always talked about zooming in and zooming out, Gutenberg essentially being like a new 3D interface for WordPress. I think we want to make it very easy to kind of zoom in and out, including focus on one single area or even one single block, if you really want to work within that.</p>\n<p>Brian Krogsgard: And that means in some ways potentially front end editing too, right? When I think about Gutenberg, the one beef I have with writing in WordPress is all the other stuff beyond the editor. Whether it&#8217;s TinyMCE or Gutenberg, I write mostly text and a few images. I&#8217;m not doing a lot of page layout, and I love the tools that Gutenberg&#8217;s brought in. For instance, you brought up some of Nick Hamze&#8217;s blocks. I talk to Nick sometimes, and he&#8217;s got so much creativity and I love that it empowers that. But for 90% of the things I&#8217;m going to do, I&#8217;m just writing. A clear, focused writing area is what I like, so I actually just don&#8217;t like the fact that I can go into the appearance editor and the plug in screen. Those are all one click away, rather than just saying, &#8220;Here&#8217;s the page.&#8221;</p>\n<p>Brian Krogsgard: The best Gutenberg interact I&#8217;ve had yet was actually WordPress.org/Gutenberg, because I was experiencing Gutenberg. It&#8217;s a live demo of Gutenberg. I was able to experience Gutenberg, and none of the other stuff was there. It was just a column of content, and I really enjoyed that, so is that a part, a way that you think we can focus on how to get to writing and not worrying about everything else?</p>\n<p>Matt Mullenweg: We can support both. I mean, you currently have a version of this in Gutenberg where it can show the menu or not, or you can go to the mode which is my preference mode, where Gutenberg takes over the whole screen so you don&#8217;t have a sidebar menu there, even minimized. I actually strongly prefer that.</p>\n<p>Brian Krogsgard: See, I didn&#8217;t even know that. I&#8217;ve missed that.</p>\n<p>Matt Mullenweg: Oh, yeah, yeah, so go in Gutenberg to the top right, the dots. I&#8217;m trying to think exactly where it is. Are you opening your WordPress as well?</p>\n<p>Brian Krogsgard: I am.</p>\n<p>Matt Mullenweg: We&#8217;ll go through this together.</p>\n<p>Brian Krogsgard: I might take over my screen share here, but that&#8217;s okay.</p>\n<p>Matt Mullenweg: Oh yeah, do you want me to screen share?</p>\n<p>Brian Krogsgard: No, I mean I&#8217;m recording us.</p>\n<p>Matt Mullenweg: Oh, got you, got you.</p>\n<p>Brian Krogsgard: So people, this might end up on YouTube or something.</p>\n<p>Matt Mullenweg: So in the three dots, there is three kind of options there.</p>\n<p>Brian Krogsgard: Oh, yeah.</p>\n<p>Matt Mullenweg: Tool bar, spotlight mode and full screen mode. I actually am in full screen mode. I strongly, strongly prefer it.</p>\n<p>Brian Krogsgard: Neat.</p>\n<p>Matt Mullenweg: Top tool bar I don&#8217;t think is that useful, but they know that. This was basically, there was a huge kind of fight earlier. If you look at Yoast&#8217;s original post about the plan for Gutenberg, there alternative UI is basically all about the top tool bar. Then spotlight mode I also don&#8217;t love, but some people really like it. It kind of grays out the other blocks and then makes the current block you&#8217;re in more visually prominent.</p>\n<p>Brian Krogsgard: Cool, and for anyone that happens to be watching this, I just popped it up onto the screen where you can see exactly where that is, so that&#8217;s really cool. I learn new things every day.</p>\n<p>Matt Mullenweg: Yeah, and so even this menu, like I&#8217;m looking at this menu right now. Do you have it open?</p>\n<p>Brian Krogsgard: I do.</p>\n<p>Matt Mullenweg: I want to talk through some things that could be really improved here. So for example, originally we didn&#8217;t have this descriptive text under each of these three views.</p>\n<p>Brian Krogsgard: Mm-hmm (affirmative).</p>\n<p>Matt Mullenweg: Well one, the text should be views, not view, and I think that there is, we can improve that text. Under editor, I don&#8217;t know if visual versus code is actually very intuitive, and two, under code editor, I think it&#8217;s a beautiful place to expose that you can actually go into the code editor on a per-block basis, so just a little bit of text there that says, &#8220;Hey, also per block you can go into this.&#8221; Manageable reusable blocks needs the square and the little pointy thing that shows that that&#8217;s going to take you out of Gutenberg, and I think it does open a new window.</p>\n<p>Matt Mullenweg: And I think that we should put some sort of star or cool icon next to keyboard shortcuts, because once you learn those, you are off to the races. So just a good example that as far as we&#8217;ve come with Gutenberg, you can look at a single screen and immediately think of four or five things that are very improvable and that are certainly worth testing and getting out there.</p>\n<p>Brian Krogsgard: Yeah, that&#8217;s neat.</p>\n<p>Matt Mullenweg: I always joke I&#8217;m the unhappiest WordPress user in the world. It&#8217;s hard for me to look at anything in WordPress and not see all the things that could be made better, and just be terribly impatient to get them better as soon as possible.</p>\n<p>Brian Krogsgard: So, speaking of impatient, you&#8217;re going to have to &#8230; Well, you might be able to work on some of these things at the same time but also there is a phase, a priority, and number three was about collaborative editing. For me, I think of this not even necessarily like me and you might collaborate on a post, but sometimes I want to collaborate with myself. My favorite tool from Automatic that you guys have built is probably Simplenote, because it&#8217;s like the only to-do app-ish thing, and it&#8217;s very unstructured, but it&#8217;s the only to-do app type of thing that I&#8217;ve ever really used in depth, because it&#8217;s really easy to open. It&#8217;s really easy to start writing, and it&#8217;s instantly on my phone. So for me, collaborative editing in some ways is just this simple process back and forth.</p>\n<p>Matt Mullenweg: Across devices.</p>\n<p>Brian Krogsgard: Yeah, across devices.</p>\n<p>Matt Mullenweg: Totally.</p>\n<p>Brian Krogsgard: Because I do a lot of stuff through my phone, but your collaborative editing is much more than just cross-device. It&#8217;s also cross-individual, and people building things together. Why do you think that&#8217;s an important thing to be in core WordPress experiences?</p>\n<p>Matt Mullenweg: Hmm, that&#8217;s a good example of something that there&#8217;s not a bajillion people asking for right now. But just like post revisions, which is one of my favorite things I&#8217;ve forced to be in WordPress that I think is really fundamental to have the entire system works, this-</p>\n<p>Brian Krogsgard: Yeah, a lot of people have been saved by revisions.</p>\n<p>Matt Mullenweg: Yeah, I think this idea that when you&#8217;re editing in a post, the post is almost like an object and people from different devices, different things, can all come and be simultaneously working on that same object, is a mental model that is technically extraordinarily difficult. But if you get it right, it&#8217;s just a magical user experience. Even simple stuff, like do you remember when Netflix started saving where you&#8217;d watched up to across devices?</p>\n<p>Brian Krogsgard: Mm-hmm (affirmative), yeah, that&#8217;s great.</p>\n<p>Matt Mullenweg: Magical, and it&#8217;s so simple.</p>\n<p>Brian Krogsgard: Yeah, I use that a good bit. We use that a good bit with our son, because the easiest way for him to be happy in a car is to have somebody&#8217;s phone. You can pull up Super Wings or whatever, right where he left off, so yeah, I do agree. And even when Google Docs came out with that, it was revolutionary in a way but people didn&#8217;t realize how much it would transform the way they write documents, so &#8230;</p>\n<p>Matt Mullenweg: Totally, and we&#8217;ve got, the Web now supports technologies like WebRTC, that will perhaps enable us to do this even without centralized service, which is super cool, too. Because before, I was &#8230; Conspiracy theorists won&#8217;t believe this but I was actually really disappointed that it looked like the only way we could do this was in Jetpack. Now, it looks like we&#8217;ll actually be able to do this in a much more distributed fashion.</p>\n<p>Brian Krogsgard: Interesting. Funny enough, I didn&#8217;t even think about that conspiracy theory and everything. As delightful as that sounds to think about, I didn&#8217;t consider the centralization aspect of it.</p>\n<p>Matt Mullenweg: Yeah, so it&#8217;s definitely, there&#8217;s some stuff out there that&#8217;s possible. By the way, there might still be something where Jetpack can enhance it, or maybe we use Simperium, which is the engine behind Simplenote, to do something even fancier, but we can do a lot without that. But this also requires us to rethink our user flows around what versions, what it means to edit something. Because right now, you and I can kind of be on different paths, and we can save each other and merge over each other. And what is the relationship between what&#8217;s on the edit screen versus what&#8217;s live? That also is going to apply now to the entire site, so maybe what you and I are working on together is the new version of Post Status, and you&#8217;re changing the typography and I&#8217;m moving the widgets around and things like that, and then we&#8217;re setting that to go live at 12:00 pm on a Tuesday.</p>\n<p>Brian Krogsgard: Yeah, that&#8217;s really cool. Another element of that that is a quirk in WordPress I guess, but you could publish a post and now I want to update it, but I don&#8217;t want to update it right now, but I want to save what I&#8217;ve updated.</p>\n<p>Matt Mullenweg: Mm-hmm (affirmative).</p>\n<p>Brian Krogsgard: Right now it&#8217;s either, it&#8217;s all about your current session. Once it&#8217;s published, you either update it or those changes are basically gone. You don&#8217;t kind of save a draft of an update, so a work flow like this would inherently basically have to solve a problem like that, so that would be nice.</p>\n<p>Matt Mullenweg: Basically, we&#8217;re going to reimplement Git in the post-content table, in the WP Post table.</p>\n<p>Brian Krogsgard: Yeah, that sounds like no problem.</p>\n<p>Matt Mullenweg: Piece of cake.</p>\n<p>Brian Krogsgard: Yeah, on that note, do you think there are underlying architectural changes that WordPress is going to have to go through to enable both this experience, because this is Gutenberg, but also I mean you&#8217;re probably faced with some of the problems that a tool like WooCommerce has in terms of scalability and being the right tool for the job for that next level of application. These aren&#8217;t blogs anymore, but we basically have the same data base, the same data base structure. You can extend it. You can change things, but do you think there&#8217;s rethinking that needs to be done in that regard?</p>\n<p>Matt Mullenweg: Sure, and I actually think that [inaudible 01:04:12] is I think we have the opportunity to readdress and in a very backwards compatible way provide a path for people to upgrade some data structures, some things that have been hanging around for a while. An obvious one is widgets are a serialized array. Now we can move that to being JSON. There&#8217;s the native structure, data structure that Gutenberg uses behind the scenes. For some reason, we have to store this as like HTML plus comments, we can just store it in the native data format, which is pretty cool.</p>\n<p>Matt Mullenweg: By the way, as we increase the MySQL version, we can actually query and get things out as JSON objects directly from MySQL. We don&#8217;t have to take them in and out of strings, so there&#8217;s just some clean-up, some fun stuff we can do. When we get higher PHP versions, we can name spacing doing different things. J-Trip&#8217;s been talking about doing some pretty cool composer stuff. All of this is, we&#8217;re getting the user part back on track and so that also means we can start to invest a lot more in that developer experience, which I think is crucial. Also I feel, I have a ton of empathy for, I actually for better or worse, I interact every day a lot more with developers than I do with users, so I really try to get out of my way to interact with users, but you can imagine the gripes and pains of developers is something that is more of my daily experience.</p>\n<p>Brian Krogsgard: So we&#8217;ll have time to talk about all these phases over the next few years, but quickly what do you see in terms of the number of sites where having a multilingual setup, and this is around the focus of phase four, how often are you encountering Websites like that, and how much do you think that this being a part of the WordPress experience would be empowering for people to actually support more languages and more language versions of their site?</p>\n<p>Matt Mullenweg: I think it would be a really big fundamental concept. The Web is global. English or single language is actually I think a small minority. People who speak one language is a small minority of the seven billion people in the world. This is obviously very prevalent in places like Quebec, where there&#8217;s officially French and English, and of course all over Europe. This is why I get the question every year for Camp Europe. I am monolingual, ashamedly so.</p>\n<p>Brian Krogsgard: Yeah.</p>\n<p>Matt Mullenweg: But the world is polyglots, and that&#8217;s why I named the mailing list WP Polyglots, not WP translate or WP anything, when I set that up almost 15 years ago now. Even for monolinguists like me, I got someone contacted me the other day saying, &#8220;Hey, can I translate this Gutenberg FAQ into Japanese? Do I have your permission to?&#8221; And they put it on a different site. How cool would it have been if I just could have said, &#8220;Hey, by the way, collaboration and work flow, here, you now have access to make this post into Japanese,&#8221; and now at the top it&#8217;ll have a little link to it, to the Japanese version, and there will be sort of a neural structure in a canonical place for the MA.TT version of the Gutenberg FAQ translated to Japanese by this volunteer, where anyone in the world could live. And by the way-</p>\n<p>Brian Krogsgard: I was about to say, what if it was permissionless, like just if someone wants to make something on my site in other languages, do it. As small as Post Status is, I&#8217;ve had people that want to recreate the members side in Dutch or something.</p>\n<p>Matt Mullenweg: Cool.</p>\n<p>Brian Krogsgard: I&#8217;m like, I can&#8217;t do that, but that sounds amazing if you want to do that. But I&#8217;d be totally down if the structure was there for it to say, translate this post, and it&#8217;s almost like forking software, or almost the way language packs and plugins work. You don&#8217;t have to be responsible for every language pack if you&#8217;re the plug in author. Someone can just come and do it, and I think that&#8217;d be really cool for posts.</p>\n<p>Matt Mullenweg: That would be so cool, and by the way, layer that in with other plugins. Layer that in with membership, so you only allow members to translate things, or layer that in with one I&#8217;d love to re-evaluate which is [Blickey 01:08:23]. So there is public revision history and sort of moderated submissions, so maybe I have, maybe my colleague [Nalco 01:08:34] can moderate Japanese translations, but maybe she doesn&#8217;t have time to translate every single one of my posts herself. But when people submit one, she could take a few minutes to just read it through and make sure they&#8217;re not having [crosstalk 01:08:47].</p>\n<p>Brian Krogsgard: Yeah, translate my post and make it sound completely different.</p>\n<p>Matt Mullenweg: Yeah, I think it&#8217;s actually WordPress.com.</p>\n<p>Brian Krogsgard: Assuming good intent is part of the thing there.</p>\n<p>Matt Mullenweg: Do you remember the Happy Birthday incident?</p>\n<p>Brian Krogsgard: I don&#8217;t.</p>\n<p>Matt Mullenweg: Someone, because when we opened up kind of like more totally community translations on WordPress.com and made it easy for anyone to do it, someone changed where it said comments, like leave a comment, into Happy Birthday! I forget what language it was, Italian, so all Italian sites under every single post would say Happy Birthday!</p>\n<p>Brian Krogsgard: Just Happy Birthday!</p>\n<p>Matt Mullenweg: Which I think is kind of like the most brilliant, if you&#8217;re going to troll or vandalize us, that was a really lovely way to do it.</p>\n<p>Brian Krogsgard: Yeah, we could probably learn some things from Wikipedia&#8217;s own editorial flows and how to implement something like that. I do think that would be really neat. Do you think that still leaves room for other plugins that are doing various multilingual things? Does it leave room for them, or do you think it kind of eats them up and makes that business model go away? Because there&#8217;s been some good-sized businesses in that realm.</p>\n<p>Matt Mullenweg: It leaves room for them 100%. In fact, I think it increases them a ton. Same thing with page builders. If you look at where the business model is for a lot of these translation plugins are going, they&#8217;re actually helping you do the translation. That makes total sense. If I&#8217;m a business, I might want my site in five languages. If I can click a button and just say, &#8220;Hey, I&#8217;ll pay you $1,000,&#8221; and by the way the plugins can be in the middle of that or there can sort of be an API for that. I mean, this is kind of incredible, but the downside of them is very similar to page builders, which is each kind of has its own way to do the data and the storage.</p>\n<p>Matt Mullenweg: Some put it all in post content. Some put it in custom post type. Some put it in meta fields. Some put it in separate tables, so you essentially have actually each of the possible ways you could kind of logically do this exists. So now, if I&#8217;m building a plugin that wants to work with multilingual versions of the site, how do I do it? There&#8217;s no common foundation. Exact same issue we had with blocks. There were blocks on WordPress for years now, but every single visual composer and Beaver Builder and Elementor and Avada and Divi, they all did blocks in a different way.</p>\n<p>Brian Krogsgard: Matt, there&#8217;s like 100 business questions I want to ask you but we&#8217;re over an hour already, so I will-</p>\n<p>Matt Mullenweg: Can we take a few more minutes, like maybe wrap it in like, say 10?</p>\n<p>Brian Krogsgard: Yeah, sure. If you&#8217;re down, I&#8217;m down.</p>\n<p>Matt Mullenweg: You&#8217;re one of my favorite people to talk to.</p>\n<p>Brian Krogsgard: Well, I appreciate it. I love talking to you as well, and I appreciate your openness.</p>\n<p>Matt Mullenweg: Between you all, honestly you all and the Tavern folks, these are so much fun. I actually listen to a lot of these podcasts. It&#8217;s really enjoyable for me, so I appreciate you doing it. My ask of you for 2019 is, I&#8217;d love to see a bit most Post Status on the scene, you know?</p>\n<p>Brian Krogsgard: Yeah, that&#8217;s a task for myself as well, so I did a relatively personal update recently.</p>\n<p>Matt Mullenweg: I saw that.</p>\n<p>Brian Krogsgard: One of the things that I&#8217;ve struggled with is I haven&#8217;t been in the thick of things in about four years, so I&#8217;m actually not spoiled, but I&#8217;m doing some part-time work actually being in WordPress, and back into doing stuff.</p>\n<p>Matt Mullenweg: Cool.</p>\n<p>Brian Krogsgard: It&#8217;s actually on the product side, not the service side. I&#8217;ve worked in an agency. This is going to give me a chance to do some part-time work on the product in SaaS side of things, so I&#8217;m excited about that. I know from history, when I&#8217;m working hard on something, whether it&#8217;s building my own site or working in the industry, it gives me much more to say, so I&#8217;m excited about being inspired by working within our space more, and within the experience more. Because it&#8217;s been four years of not doing that, and over those years I&#8217;ve tried to rely on other people to have a voice more as I felt like mine was fading. Kind of like what you were saying, you&#8217;re around developers all the time and not, like you want to be around more users. I was looking at the industry a lot, and not being in the industry I felt made it more difficult to have good things to say.</p>\n<p>Matt Mullenweg: Although I would say the outside perspective is really valuable as well.</p>\n<p>Brian Krogsgard: Yeah, I think at least for a season I need, it&#8217;ll be really beneficial for me.</p>\n<p>Matt Mullenweg: I can&#8217;t wait to see, and by the way, as a member of the Post Status community, include us along for the ride. I&#8217;m sure after that personal update you got a ton of people contacting you [crosstalk 01:13:14].</p>\n<p>Brian Krogsgard: I did, which I was very thankful for.</p>\n<p>Matt Mullenweg: It&#8217;s one of those things, I think what was beautiful about that is you opened up about the struggle, not just about the good stuff. It&#8217;s really scary to be vulnerable like that, publicly. It was scary of me to put the things we learned and did wrong in the State of the Word, right? I just wanted to talk about all the good stuff, but it&#8217;s like it&#8217;s important for us to talk about what I messed up on. People help when they see that.</p>\n<p>Brian Krogsgard: Yeah, that was very-</p>\n<p>Matt Mullenweg: And I think the most valuable thing you built is like overall a pretty positive community that cares about WordPress deeply, so that&#8217;s awesome.</p>\n<p>Brian Krogsgard: Yeah, and thank you, and I was very appreciative of the various responses that I got between feedback and ideas and job offers. But I&#8217;m excited to do some work within the space, and you know actually it did give me, it was beneficial because I got my head kind of out of the space a little bit, which I needed. I&#8217;ve been thinking about WordPress a whole lot since 2010, with basically no break, and I can&#8217;t imagine how you feel at times. But for me to still have a focus on WordPress but at least spend part of my week thinking about other things, doing other things, it gave me some personal benefits I think, and allowed me to look at WordPress things with a bigger picture. So I&#8217;m excited for 2019 and I think it&#8217;ll be a lot of fun. Now for you, just-</p>\n<p>Matt Mullenweg: Well, I often tell people if you&#8217;re ever feeling not inspired or burnt out, go to a museum. Watch a show. All of my best ideas for WordPress have always come from the intersection of different fields, different areas, and I think that&#8217;s true of most great art, most great software, most great anything. So if you can get out there and keep, the WordPress stuff or whatever you&#8217;re working on will be in the back of your mind anyway, so if you can kind of focus on something else for a little while, actually really it&#8217;s fun.</p>\n<p>Brian Krogsgard: It is.</p>\n<p>Matt Mullenweg: I can&#8217;t wait to see what you do. As always, let me know if I can ever be of help.</p>\n<p>Brian Krogsgard: Well, thank you very much. So a couple of business-y things. One is, what&#8217;s your biggest product right now, from an Automatic perspective? Are you guys seeing a lot of growth in the WooCommerce space, or is dot com still the main revenue driver? What are you seeing there?</p>\n<p>Matt Mullenweg: Sure, let me just think through what I can say publicly.</p>\n<p>Brian Krogsgard: When are you filing your S-1, Matt?</p>\n<p>Matt Mullenweg: Yeah, we make the same joke in Automatic that they made at Apple, which is we&#8217;re a ship that leaks from the top.</p>\n<p>Brian Krogsgard: Hey, I have to commend you, as someone who doesn&#8217;t like it but I can appreciate that this is the case. You guys are pretty good about being tight-lipped on the leaky boat side of things, so it&#8217;s a tight ship. I don&#8217;t get near as many of the leaks as I would like out of Automatic.</p>\n<p>Matt Mullenweg: Well, I think a big part of that is just most of what we do is in the open. If you want to see the pricing tests we&#8217;re running on the new blogger and e-commerce plan that we just launched on WordPress.com, it&#8217;s in the Calypso GitHub so you can see which prices we&#8217;re charging which people, and how the test is going, and what percentage it&#8217;s going out to. Kind of, it&#8217;s all out there. WordPress.com is still the largest, and it&#8217;s still growing like a weed. I think in 2018 WooCommerce will actually grow faster in a year over year percentage, which is kind of what I started saying. We&#8217;re starting to see what I predicted when we actually first brought WooCommerce in, which is that the e-commerce opportunity has the potential to be bigger than all of the rest of Automatic&#8217;s businesses combined.</p>\n<p>Brian Krogsgard: Yeah, what&#8217;s Shopify, like eight billion plus market cap, maybe 15? I don&#8217;t know. I think they doubled their size in 2018.</p>\n<p>Matt Mullenweg: Yeah, market cap is just vagaries of the market, but revenue, they&#8217;ll be about a billion dollars this year. So I think it&#8217;s always good to look at kind of, when sort of comparing companies, look at the revenue not just the market cap.</p>\n<p>Brian Krogsgard: Sure.</p>\n<p>Matt Mullenweg: So they&#8217;ll be at a billion dollars and still growing at a really, really good rate. Now, the other reality is that nothing that we do is completely disconnected. A lot of the WooCommerce growth and increasing user experience is sort of amplified, I think, because we&#8217;ve been doing it in Jetpack, which is also amplified by running Jetpack code on WordPress.com and having that sort of stream of new users that are coming there, and so we see the problems that they&#8217;re having, and the struggles, or we build the infrastructure.</p>\n<p>Matt Mullenweg: You asked about data structures earlier. I think one thing that we&#8217;ll start to see a lot more of in WordPress, and actually a very common feature of Jetpack that people don&#8217;t know about, that the Jetpack business plan, you can have full Elasticsearch version of your site. So there are certain use cases for which I don&#8217;t think MySQL is the best medium with which to address or query your data, and Elasticsearch is pretty much the cat&#8217;s meow. So the fact that we can in real time, create real time Elasticsearch indexes for every single Jetpack business site, which only costs $300 per year. Before that, it used to cost &#8230; Actually, I think VIP used to charge $5,000 or $10,000 a year for this, maybe even a couple grand a month, actually. Now we can do it for $300 per year.</p>\n<p>Brian Krogsgard: Wow.</p>\n<p>Matt Mullenweg: And that&#8217;s just one of the features in Jetpack Business. That&#8217;s in addition to the real time backup and the activity log and all the other things, the security restores. It just shows that we&#8217;re really surfing the outer edge of Moore&#8217;s Law, and I think that the stuff that we&#8217;re going to be able to do over the next few years is going to be pretty amazing, and I&#8217;m excited about Automatic. We also just moved DNS Perf, we moved back into second place for fastest DNS service, so by the way, way ahead of Amazon, way ahead of Google, and second only to Cloudflare, which Automatic&#8217;s network is tiny but mighty. Cloudflare invests I think over 100 million dollars per year in capex, building out their data centers in their kind of points of presence. We&#8217;ve reached a number two performance ranking with a fraction of that investment, so very proud of that team, very proud of all the folks at Automatic that are really building this out. By the way, then that benefits all the users of Jetpack Photon, the CDN, just so much cool stuff happening.</p>\n<p>Brian Krogsgard: That&#8217;s awesome. I heard recently that you all have also been able to lower some of your prices for VIP as you&#8217;re deploying like VIP Go and some of that stuff with scalable Websites. Back when I had my hands in a few VIP sites I think the lowest pricing back then was maybe $3,000 to $4,000 a month, and now you can do it as low as $1,000 a month and you all provide a lot for that, so that&#8217;s impressive.</p>\n<p>Matt Mullenweg: That sounds about right, yeah. I&#8217;m not up on the latest there, but fundamentally my business philosophy is to get the best stuff in the hands of as many users for as low a price as possible, and we&#8217;re just relentless in kind of cutting the costs, bringing things down, trying to leverage the best and newest technology to do so.</p>\n<p>Brian Krogsgard: How are you attacking the very high end, so that a store that may grow up on WooCommerce doesn&#8217;t feel like they have to leave WooCommerce once it hits a certain scale? One of the things that I feel like people have been, I&#8217;ve been hearing from consultants especially, is that they get to a certain size and then they&#8217;re really struggling with WooCommerce, and then something like Shopify ends up being the answer. How is WooCommerce going to compete in that realm to be the platform for Macy&#8217;s or who knows what? Some big company with lots of orders and lots of stuff, so that you can keep them throughout the life cycle?</p>\n<p>Matt Mullenweg: Yeah, I think my take on that problem, because ultimately what we want to do is be more scalable in Shopify and also a better user experience, and right now I would say they&#8217;re ahead in both. There hasn&#8217;t been as good a feedback loop. The thing that made WordPress so scalable was there was a tight feedback loop between the host, the agencies building the biggest sites, WordPress.com itself being a big site, and the core development. So that meant that when we had bottlenecks, we were able to solve them often in core in ways that were ultra scalable in Webscale.</p>\n<p>Matt Mullenweg: WordPress.com is on its own one of the largest sites on the Internet, so that&#8217;s the same software that you can download and use, which is kind of wild. For WooCommerce, that loop isn&#8217;t as strong so one of the things I&#8217;ve been encouraging the team to try to do myself is get a tighter loop between the host and the people building the big sites and the WooCommerce core team, so that they can figure out versus having five different plugins that try to address the scalability in different and often subpar ways, really get that built into core, with the sort of Web scale, knowing everything we&#8217;ve known in 15 years of building WordPress, what&#8217;s going to make it so it can scale to thousands of orders per second, hundreds of millions of rows.</p>\n<p>Brian Krogsgard: Two more questions, real quick.</p>\n<p>Matt Mullenweg: We can do so, by the way. It&#8217;s a very tractable problem. We will solve that. Solving that is something that will happen within the next six to 18 months. Solving the user experience to catch up with Shopify is also improving the user experience, or BigCommerce rather, I think will take longer. That&#8217;s more of a five to 10 year goal.</p>\n<p>Brian Krogsgard: I personally think that gives both the WordPress ecosystem, the WooCommerce ecosystem and Automatic directly a massive value proposition, if that can be accomplished. I think WordPress now people, you never feel like you have to leave WordPress because you got too big.</p>\n<p>Matt Mullenweg: Yeah.</p>\n<p>Brian Krogsgard: And as that can be accomplished, and that was a massive accomplishment for WordPress. For a long time that wasn&#8217;t true, and now that, if that can be done on the e-commerce side of things, or commerce broadly not just necessarily WooCommerce, I think that will be fantastic for everybody involved.</p>\n<p>Matt Mullenweg: By the way, I just want to point that out, just to pause. Think how little, how many other examples of software you can think of that the consumer version also works when you run it at an industrial global scale?</p>\n<p>Brian Krogsgard: I have no idea. I&#8217;m not very-</p>\n<p>Matt Mullenweg: It&#8217;s not very common. I think it&#8217;s one of the things the WordPress community should really be proud of, because that is highly unusual. And as we&#8217;re one of the only ultra-successful consumer open source startups, projects, communities, whatever, I think pointing to that sort of scalability is a big thing as well.</p>\n<p>Brian Krogsgard: So, one question is Automatic has investors. We just saw Slack, Lyft and Uber all file for becoming public companies. When I think, what&#8217;s the option for Automatic, one of however many successful startups where you have investors, they know you&#8217;re a successful startup. They know that there&#8217;s opportunity for them to succeed in that. That&#8217;s long-term revenue stream, remaining a private company. It&#8217;s private equity. It&#8217;s going public, or it&#8217;s acquisition. Do you have any thoughts in terms of what makes you happiest as a company and as a business owner, and what do you think is best for the way Automatic interfaces with the broader WordPress community?</p>\n<p>Matt Mullenweg: It&#8217;s hard for me to imagine being a public company CEO, any harder than leading an open source project.</p>\n<p>Brian Krogsgard: I&#8217;ve thought about that a great deal. I think you actually fit the mold for what Wall Street might like in terms of the leader of a public company. I will say, that&#8217;s my bet. My best is one day Automatic would go public, and we figure out how that works in terms of all the private, public components and the open source side of things. But yeah, I&#8217;m curious-</p>\n<p>Matt Mullenweg: I think it&#8217;s actually a possibility. By the way, I could see other WordPress companies going public, probably WPEngine is the closest to the gates there.</p>\n<p>Brian Krogsgard: Well good, GoDaddy and EIG are public.</p>\n<p>Matt Mullenweg: They are, yeah, so there will be other open source WordPress either based or WordPress will be a part of their business public companies, likely before Automatic as well. I think that&#8217;s a great path for us. Automatic has investors. They are minority investors, so the sort of existential future of the company is in the hand of myself and the other people who own the majority of the shares of Automatic. I think there&#8217;s lots of options. The people you point to, Uber or Lyft, Slack, et cetera, to varying degrees have built some pretty impressive things. I admire some more than others, but also have reached a scale that&#8217;s kind of far beyond where companies generally go public.</p>\n<p>Brian Krogsgard: Yeah, they really have. It&#8217;s been-</p>\n<p>Matt Mullenweg: What that illustrates is that the private market is actually a lot more liquid and has a lot more capital available for when and how that needs the company or the ecosystem or whatever to grow.</p>\n<p>Brian Krogsgard: So I could surmise from that that you don&#8217;t feel like there&#8217;s a rush?</p>\n<p>Matt Mullenweg: I won&#8217;t even speak to my own personal things, but say just in the industry there&#8217;s less of a rush, so that is the plus and minus of so much capital moving from the public markets into the private markets. So people like Fidelity, T. Rowe Price et cetera that used to only do public companies now invest in private companies. That&#8217;s great for the companies, because by the way as a private company, you don&#8217;t have the kind of quarterly scrutiny that you do when you&#8217;re public, and I think it&#8217;s actually easier to out-innovate and out-flank public companies when you are private, which is one thing I personally like. But that said, it does keep more of that growth in the hands of only sophisticated investors.</p>\n<p>Brian Krogsgard: I completely agree.</p>\n<p>Matt Mullenweg: So there is a lot more of that upside that is no longer in the hands of what is commonly referred to as the retail investor. I would love for anyone who loves Automatic&#8217;s products to be able to own a share of the company, even if it&#8217;s just one share. That&#8217;s not really possible under the current sort of regulatory frameworks, and for good reasons, by the way. As we saw with the kind of ICO craze, there&#8217;s a reason all these protections for consumers and public market, public company standards exist.</p>\n<p>Matt Mullenweg: But in the meantime, at Automatic we will continue to hold ourselves to public company standards, but really build in an extremely long-term way. If there&#8217;s an idol there, I&#8217;d say it&#8217;s Amazon, and try to make the best possible user experience, best possible products. If we continue to do that, I think from a business point of view we will have an array of options available to us and any number of choices.</p>\n<p>Brian Krogsgard: And as a leader yourself of the WordPress community and Automatic, what&#8217;s one big thing that you learned this year that you hope to improve upon in 2019?</p>\n<p>Matt Mullenweg: Hmm, I know you&#8217;re probably thinking about like a big thing, but I&#8217;m actually going to say a small thing.</p>\n<p>Brian Krogsgard: It can be small.</p>\n<p>Matt Mullenweg: It&#8217;s really important, which is how much you can &#8230; What is the one thing everyone listening to this is doing right now?</p>\n<p>Brian Krogsgard: Focusing, I hope?</p>\n<p>Matt Mullenweg: Breathing.</p>\n<p>Brian Krogsgard: Oh, okay.</p>\n<p>Matt Mullenweg: And you probably weren&#8217;t thinking about it, but now you are thinking about it. You&#8217;re breathing right now.</p>\n<p>Brian Krogsgard: I am.</p>\n<p>Matt Mullenweg: And it is amazing how much you can influence your mindset, your state of mind, your mood, your everything, through breath. Just as an exercise, where everyone puts their hand on their belly and takes a big breath and pushes your hand out as you take it in, Brian, are you doing it?</p>\n<p>Brian Krogsgard: Oh, sorry. I do. I feel good.</p>\n<p>Matt Mullenweg: It has an immediate effect on you.</p>\n<p>Brian Krogsgard: It does. You know, actually that&#8217;s how we discipline our son often. A three-year-old is a very emotional being, so if they&#8217;re upset one of the first things that you can do with them is just tell them, &#8220;Let&#8217;s take a deep breath together.&#8221; So you take that deep breath and the response is also very immediate, the way they calm down and settle down and think more clearly because they took that breath, so that&#8217;s interesting.</p>\n<p>Matt Mullenweg: That&#8217;s all of us, and also by the way, this is not something new. This goes back thousands of years.</p>\n<p>Brian Krogsgard: You didn&#8217;t just invent this?</p>\n<p>Matt Mullenweg: No, no, you know there&#8217;s so many, there&#8217;s so much prior art here, but I&#8217;d encourage people to check it out. Also check out, when the videos go up, the Joanna Barsh talk, and Alexis Lloyd both had sort of almost like guided meditations and exercises. I think this is one of the next big areas for people who aren&#8217;t familiar with to discover. They&#8217;re actually really, really powerful, and it&#8217;s been huge for me. In an extraordinarily busy and what might otherwise be seen as extremely stressful year, it was actually one of my best years of my life.</p>\n<p>Brian Krogsgard: Awesome.</p>\n<p>Matt Mullenweg: I do have to watch a clock, and I do have to run now.</p>\n<p>Brian Krogsgard: That&#8217;s fine. I&#8217;m happy to hear that. Thank you for spending so much time with me. It was great talking to you, and we&#8217;ll catch everybody next time.</p>\n<p>Matt Mullenweg: Thank you. I&#8217;ll see you all, and thank you to all Post Status readers.</p>\n</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 12 Dec 2018 14:45:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: State of the Word 2018: WordPress Embraces the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86291\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/state-of-the-word-2018-wordpress-embraces-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13953:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/12/PIC_20181208_161427272.jpeg?ssl=1\"><img /></a>photo credit: WP Tavern</p>\n<p>WordCamp US kicked off in Nashville over the weekend, following the release of WordPress 5.0. In the first 48 hours, 5.0 had been downloaded more than 2.8 million times. It passed 3 million Saturday night.</p>\n<p>&#8220;There&#8217;s been a lot that&#8217;s been going on, so I&#8217;d like to allow WordPress the chance to re-introduce itself,&#8221; Matt Mullenweg said during the preamble of his <a href=\"https://www.youtube.com/watch?v=aWlfp-1Q19I\" rel=\"noopener\" target=\"_blank\">State of the Word</a> address. He invoked the four freedoms as the project&#8217;s constitution and called the community back to its roots. </p>\n<p>“It&#8217;s the reason we&#8217;re here,” Mullenweg said. “WordPress isn&#8217;t a physical thing; it&#8217;s not a set of code. It&#8217;s kind of an idea.  WordPress is backed by the full faith and credit of every person and company that depends on it.”  </p>\n<p>He reiterated the project’s mission to democratize publishing and recast his vision for advancing the open web.</p>\n<p>&#8220;Like I said a few years ago, we&#8217;re building a web operating system, an operating system for the open, independent web and a platform that others can truly build on,” Mullenweg said.</p>\n<p>WordPress’ 32.5% market share and its commercial ecosystem, which Mullenweg estimates at $10 billion/year,  give the project the resources to make a powerful impact on the future of the web. </p>\n<h3>Mullenweg Builds a Compelling Case for the Block Editor</h3>\n<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/12/wcus-sotw.jpg?ssl=1\"><img /></a>photo credit: <a href=\"https://twitter.com/WordCampUS/status/1071531659579789313\">WCUS Photography Team</a></p>\n<p>Mullenweg drove home the necessity of Gutenberg by showing a selection of videos where new users struggled to accomplish simple tasks in the old editor.  Their experiences were accompanied by painful commentary:</p>\n<ul>\n<li>&#8220;This feels like writing a blog back in 2005.”</li>\n<li>&#8220;This was very finnicky; this does not work.”</li>\n<li>&#8220;How would I add a caption? I have no clue.”</li>\n</ul>\n<p>Mullenweg described how he used to effortlessly switch back and forth between the visual and HTML editors prior to WordPress 5.0 but realized that not all users are able to do this.  </p>\n<p>”This has been our editor experience for over a decade now and many of us have learned to deal with it,” he said.</p>\n<p>He followed up with a video demonstrating how much easier these tasks are in the new block editor and identified blocks as the way forward for WordPress.</p>\n<p>Some attendees commented after the fact on how the user testing videos, paired up against an expert using Gutenberg, seemed unbalanced and they would have liked to see videos of new users attempting the same tasks in the new editor. The goal of that segment, however, seemed to be more aimed at communicating the need for Gutenberg and the possibilities it opens up once users have had the chance to grow into it.</p>\n<h3>Mullenweg Urges Attendees to &#8220;Learn Blocks Deeply&#8221;</h3>\n<p>Millions of early adopters have already embraced the block editor during phase 1 of the Gutenberg project, which closed out with 1.2 million active installs and 1.2 million posts written. There have already been 277 WordCamp talks on Gutenberg, 555 meetup events focused on the new editor, and more than 1,000 blog posts discussing it.</p>\n<p>Blocks are taking over the world of WordPress. Version 5.0 shipped with 70 native blocks and there are already more than 100 third-party blocks in existence and 1,000 configurations related to that. </p>\n<p>“Blocks are predictable, tactile, and can be simple like a text block, or as rich as an e-commerce interface,” Mullenweg said. He described them as the new DNA of WordPress, from which users can create anything they can imagine. </p>\n<p>Mullenweg showcased two sites built using the block editor, the <a href=\"https://theindigomill.com/\" rel=\"noopener\" target=\"_blank\">Indigo Mill</a> and <a href=\"https://www.luminasolar.com/\" rel=\"noopener\" target=\"_blank\">Lumina Solar</a>. These beautiful sites open the imagination to what Gutenberg is capable of bringing to websites.</p>\n<p>WordPress.org will be highlighting plugins and themes to push the block ecosystem forward. There are also more than 100 Gutenberg-ready themes available to users on the directory and <a href=\"https://wordpress.org/plugins/browse/blocks/\" rel=\"noopener\" target=\"_blank\">a new Gutenberg block tag that is currently live for plugins</a>. It will also be available for themes soon. </p>\n<p>Mullenweg highlighted tools like the create-guten-block toolkit, Block Lab, and Lazy Blocks that are making it easy for developers to create their own blocks. Block collections and libraries are also emerging. He said one of the priorities for 2019 is to build a WordPress.org directory for discovering blocks and a way to seamlessly install them.</p>\n<p>Building on the homework he gave to WordPress developers in 2015, to “<a href=\"https://wptavern.com/state-of-the-word-2015-javascript-and-api-driven-interfaces-are-the-future-of-wordpress\" rel=\"noopener\" target=\"_blank\">Learn JavaScript Deeply</a>,” Mullenweg urged the community to “Learn Blocks Deeply.”  Blocks provide a host of opportunities to improve the user experience beyond what Gutenberg’s creators could have imagined in the beginning.</p>\n<h3>Gutenberg Phase 2: Navigation Menu Block, Widget blocks, Theme Content Areas</h3>\n<p>Mullenweg announced the next phases for the Gutenberg project. Phase 2 has already begun and focuses on site customization, expanding the block interface to other aspects of content management.  This includes creating a navigation menu block. Reimagining menus is will be challenging, and Mullenweg said they may even get renamed during the process.</p>\n<p>Phase 2 goals also include porting all widgets over to blocks and registering theme content areas in Gutenberg. An early version of phase 2 will be in the Gutenberg plugin so anyone wanting to be part of testing can reactivate it.</p>\n<p>During the Q&#038;A time, one attendee asked a question about how this phase seems to include very little about making layout capabilities more robust. He asked if Mullenweg plans to let those the marketplace handle those layout decision or if core will define a layout language. Mullenweg responded that it may be more prudent to see what others in the ecosystem are doing and cherry pick and adopt the best solutions. He also remarked that it would be exciting if users could switch between different page builders in the future and not lose their content. </p>\n<h3>Gutenberg Phases 3 and 4: Collaboration and Core Support for Multilingual Sites</h3>\n<p>Mullenweg announced that Gutenberg phase 3, targeted for 2020, will focus on collaboration, multi-user editing, and workflows. Phase 4 (2020+) is aimed at developing an official way for WordPress to support multilingual sites. When asked what that will look like from a technical standpoint, given the many existing solutions already available, Mullenweg said he didn’t want to prescribe anything yet, as it’s still in the experimental stage.</p>\n<p>Other major announcements included a highly anticipated bump in the minimum PHP version required for using WordPress. By April 2019, PHP 5.6 will be the minimum PHP version for WordPress, and by December 2019, the requirement will be updated to PHP 7.</p>\n<p>WordPress releases are going to come faster in the future, as Gutenberg development has set a new pace for iteration. Mullenweg said he would like WordPress to get to the point where users are not thinking about what version they are on but instead choose a channel where they can easily run betas or the stable version.</p>\n<h3>Mullenweg Acknowledges Mistakes Made and Lessons Learned in the 5.0 Release Process</h3>\n<p>WordPress 5.0 was one of the longest and most controversial release cycles in the project’s history. Those outside the inner circle of decision-making endured a great deal of uncertainty, as dates were announced and then missed, with secondary dates thrown out in favor of pushing 5.0 out with just three days’ notice. </p>\n<p>“We were scared to announce a new release date after missing our previous one,” Mullenweg said, acknowledging the controversial release date. He said this seemed to create a lot of fear and uncertainty until they announced a new date. The dates seemed to come out of the blue and were stressful for the community. </p>\n<p>Mullenweg highlighted the lessons they learned in the process of releasing 5.0: </p>\n<ul>\n<li>Need the various teams across WordPress working together better</li>\n<li>Need to keep learning JavaScript, even more deeply</li>\n<li>Importance of triage and code freezes</li>\n<li>Always announce release dates</li>\n</ul>\n<p>Mullenweg noted that WordPress 5.0’s beta releases were tested 100 times more than other releases, which he said contributed to Gutenberg becoming more robust before landing in 5.0. However, these positives seemed to be overshadowed by several critical breakdowns in communication that many feel betrayed the community’s trust.</p>\n<p>He noted that people used the plugin review system as a way to vote on Gutenberg and that perhaps the community needs a different medium for expressing those kinds of things. Users did this because they felt it was one of the only feedback mechanisms where they had a voice. Negative reviews piled on in the early days of the plugin’s development but they continued steadily throughout the feature plugin’s journey into core. After 5.0 was released, negative <a href=\"https://wordpress.org/support/plugin/gutenberg/reviews/\" rel=\"noopener\" target=\"_blank\">reviews on the Gutenberg plugin</a> have continued to pour in, and its rating has fallen to 2.2/5 stars.</p>\n<h3>Growing Pains and a Call for Transparency</h3>\n<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/12/wcus2018.jpg?ssl=1\"><img /></a>photo credit: David Bisset for <a href=\"https://poststatus.com/\">Post Status</a></p>\n<p>Mullenweg said that Gutenberg development happened entirely in the public eye, surfacing many challenges associated with developing open source software in public. The code was public, but the most important decisions were made behind closed doors. This was compounded by the developer community voicing frustrations during core dev chats and on social media. </p>\n<p>During the Q&#038;A segment, several audience members called for more transparency in the release process, noting that most of the posts and announcements regarding 5.0 came from Automattic employees. Morten Rand-Hendriksen, who has become somewhat of a community firebrand at WordCamp Q&#038;A’s, received applause for his question regarding the use of the word “we” in connection to posts on the make blogs. He pressed Mullenweg for more insight into where these decisions are made. </p>\n<p>Mullenweg said the “we” he meant in regards to 5.0 release dates referred to a private channel where the release leads discussed it. He said with so many people showing up to the dev chats, the discussions became difficult.</p>\n<p>&#8220;I don&#8217;t just go in a cave and come up with these things,&#8221; Mullenweg said. “A lot of people were showing up [to dev chats] who had never contributed to WordPress before and were crowding out the discussion of the core team.” He also said the private conversations were “every bit as feisty as the public one,” except there weren’t any drive-by opinions. </p>\n<p>To those on the outside, these meetings appeared to be secret, as they were never referenced or summarized on the make blogs. This left the developer community wondering where these decisions were coming from and whether or not they had a voice.</p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">Gutenberg was developed in public, but too many decisions were made in silos and not clearly communicated. This can be improved for 5.1 and beyond <a href=\"https://twitter.com/hashtag/WCUS?src=hash&ref_src=twsrc%5Etfw\">#WCUS</a></p>\n<p>&mdash; K. Adam White (@kadamwhite) <a href=\"https://twitter.com/kadamwhite/status/1071539824358764544?ref_src=twsrc%5Etfw\">December 8, 2018</a></p></blockquote>\n<p></p>\n<p>During the Q&#038;A, Mulllenweg said he listened to vigorous discussion and diverse viewpoints from release leads coming from different companies, while gathering as much information as possible from reading reviews, blog posts, and comments from the community. He described this process as part of the art of trying to make sense of all the different things people are saying and balance that.</p>\n<p>Supporting a BDFL-led project requires a certain amount of trust that the leadership is listening. Over the past several weeks Mullenweg has made a strong effort to <a href=\"https://wptavern.com/mullenweg-ramps-up-communication-ahead-of-wordpress-5-0-release-rc2-now-available\" rel=\"noopener\" target=\"_blank\">keep the channels of communication open</a>.  </p>\n<p>The painful user testing videos Mullenweg shared demonstrated how desperately WordPress needed to grow out of its old editor. It isn’t often that core makes changes that affect nearly every corner of the WordPress ecosystem at the same time. This experience came with its fair share of growing pains. Despite communication missteps during the 5.0 release process, Mullenweg has successfully navigated the project through this rocky transition. Although WordCamp US attendees seemed road weary after 5.0, they were united by a shared desire to move forward and continue working together with the leadership that has kept WordPress on the course of growth and improvement for the past 15 years.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Dec 2018 16:23:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Matt: State of the Word 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48685\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ma.tt/2018/12/state-of-the-word-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1048:\"<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<p>Over the weekend I was in Nashville with over a thousand other WordPress enthusiasts. I met a ton of people, learned a lot, and was able to share the annual State of the Word address with the audience, which is a big summary of what WordPress has been up to and where it&#8217;s going. This year we covered user testing, Gutenberg, 5.0, the future phases of Gutenberg, all the latest and greatest blocks, new minimum PHP requirements, the adoption of 5.0, and some event and community updates. You can also <a href=\"https://www.slideshare.net/photomatt/wordpress-state-of-the-word-2018\">see just the slides</a>. The <a href=\"https://www.youtube.com/watch?v=v2aNNlC8TUE\">Q&amp;A is here in a separate video</a>.</p>\n\n\n\n<p>If you&#8217;d like a text summary and commentary on the speech, <a href=\"https://poststatus.com/state-of-the-word-2018/\">Post Status</a> and <a href=\"https://wptavern.com/state-of-the-word-2018-wordpress-embraces-the-block-editor\">WP Tavern</a> both have good write-ups.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 11 Dec 2018 05:00:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"Post Status: Matt Mullenweg’s State of The Word, 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://poststatus.com/?post_type=poststatus_notes&p=49929\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://poststatus.com/state-of-the-word-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8440:\"<p>Matt started by “reintroducing WordPress” and the four freedoms, stressing that “WordPress isn&#8217;t a physical thing or code, it&#8217;s an idea.” Additionally, a “robust commercial ecosystem” supports WordPress, and Matt noted that current estimates indicate WordPress generates about $10 Billion (USD) annually.</p>\n<p>After two years of development and just after WordPress 5.0 officially launched, it&#8217;s not surprising the focus of Matt&#8217;s talk was on Gutenberg. “We&#8217;ve gotten a lot of questions about why we are doing certain things&#8230; why we are working on Gutenberg. And it&#8217;s good to return to users to find that,” Matt acknowledged.</p>\n<h3>Enhancing editor usability</h3>\n<p>A video of new WordPress users testing the classic editor (WordPress 4.9) was shown projected on the big screens over the stage. These clips primarily showed people having difficulties with relatively simple tasks in the editor.</p>\n<p>Matt&#8217;s point was that we&#8217;ve become accustomed to the custom editor&#8217;s quirks, but blocks offer a better experience — from copying and pasting from Microsoft Word and Google Docs into WordPress to quickly creating a responsive website.</p>\n<h3>Community Gutenberg adoption</h3>\n<p>Matt continued with a summary of how Gutenberg has performed in Phase 1 of its release. Before the WordPress 5.0 release, 1.2 million active installs and 1.2 million posts were published, with about 39,000 posts written daily. Phase 1 had 8,684 commits and over 340 contributors. The &#8216;Gutenberg&#8217; tag is already available for plugins in the WordPress repo, and it will be “coming soon” for themes.</p>\n<p>Notably, over 100 Gutenberg themes are already present in the WordPress repo — including the new Twenty Nineteen theme. Matt highlighted two websites — <a href=\"http://theindigomill.com\">The Indigo Mill</a> and <a href=\"http://luminasolar.com\">Lumina Solar</a> — as examples where Gutenberg blocks have been used well to create effective layouts. Matt riffed on the &#8220;Learn JavaScript Deeply&#8221; mantra by repeating &#8220;Learn Blocks Deeply.&#8221; Blocks are the DNA of the new editor. Currently, 70 native blocks and over 100 third-party blocks exist for Gutenberg.</p>\n<h3>Community Gutenberg development</h3>\n<p>He highlighted some of the third party blocks in the wild:</p>\n<ul>\n<li><a href=\"https://yoast.com/yoast-seo-8-0-introducing-the-yoast-seo-gutenberg-sidebar-a-revamped-meta-box/\">Yoast SEO</a></li>\n<li><a href=\"https://github.com/kevinbazira/algori-360-image\">360 Image</a></li>\n<li><a href=\"https://www.ampproject.org/latest/blog/the-official-amp-plugin-for-wordpress/\">Google AMP w/ Gutenberg Integration</a></li>\n<li><a href=\"https://wordpress.org/plugins/dropit/\">Drop It</a></li>\n<li><a href=\"https://wordpress.org/plugins/ecwid-shopping-cart/\">Ecwid Ecommerce Shopping Cart</a></li>\n<li><a href=\"https://woocommerce.com/posts/making-it-easier-to-add-products-to-posts-and-pages-with-the-products-block-for-gutenberg/\">WooCommerce Products Block</a></li>\n<li><a href=\"https://www.bigcommerce.com/wordpress-ecommerce-plugin/\">BigCommerce</a></li>\n<li><a href=\"https://www.wpzoom.com/plugins/new-plugin-released-recipe-card-blocks-for-gutenberg/\">Recipe Card Blocks</a></li>\n<li><a href=\"https://wordpress.org/plugins/tarot/\">Tarot</a></li>\n<li><a href=\"https://twitter.com/dmsnell23/status/1063126946350096389\">Sketch Block</a></li>\n<li><a href=\"https://jetpack.com/support/jetpack-blocks/form-block/\">Jetpack Form Block</a></li>\n<li><a href=\"https://sortabrilliant.com/guidepost/\">Guidepost</a></li>\n<li><a href=\"https://sortabrilliant.com/ghostwriter/\">Ghost Writing</a></li>\n<li><a href=\"https://sortabrilliant.com/spoileralert/\">Spoiler Alert</a></li>\n<li><a href=\"https://wordpress.org/plugins/caxton/\">Caxton Shape Divider Block</a></li>\n</ul>\n<p>Matt mentioned several block libraries and frameworks that have appeared:</p>\n<ul>\n<li><a href=\"http://editorblockswp.com\">editorblockswp.com</a></li>\n<li><a href=\"http://gutenberghub.com\">gutenberghub.com</a></li>\n<li><a href=\"http://gutenbergcloud.org\">gutenbergcloud.org</a></li>\n<li><a href=\"https://getblocklab.com\">getblocklab.com</a></li>\n<li><a href=\"https://wordpress.org/plugins/lazy-blocks/\">Lazy Blocks</a></li>\n</ul>\n<h3>Mobile Apps</h3>\n<p>Matt gave the audience an update regarding the WordPress native mobile apps: In the past month, app users published 1.3M posts and uploaded 3.1M photos and videos. Gutenberg will be going into the mobile apps, with a beta release expected in February 2019; I heard February 22nd is the current target date for a beta release.</p>\n<h3>The Next Phases of Gutenberg</h3>\n<p>Matt highlighted the next phases of Gutenberg&#8217;s evolution, which included new information about Phases Three and Four:</p>\n<h4>Phase One</h4>\n<p>Fundamental blocks for writing and editing in the backend editor. These are complete now, although Matt later said that work on the editor would continue.</p>\n<h4>Phase Two</h4>\n<p>Customizing outside of the page/post content will be the next point of emphasis. It may include widgets, menus, and miscellaneous content. Matt notes that menus “will need a bit more experimentation”. &#8220;2019&#8221;.</p>\n<h4>Phase Three</h4>\n<p>Collaboration, multi-user editing in Gutenberg, and workflows. The target for this to phase to be complete is “2020+.”</p>\n<h4>Phase Four</h4>\n<p>&#8220;An official way&#8221; for WordPress to support multilingual sites. Also slated for “2020+.”</p>\n<h3>Other Announcements</h3>\n<p>There were several non-Gutenberg tidbits of note:</p>\n<h4>Auto updates on major versions of WordPress</h4>\n<p>On a list of items to work on in 2019, Matt said he wanted to make it a goal to add optional auto-updates for plugins, themes, and major versions of WordPress.</p>\n<h4>Updated minimum PHP versions</h4>\n<p><a href=\"https://make.wordpress.org/core/2018/12/08/updating-the-minimum-php-version/\">A proposal written</a> by Gary Pendergast makes a case for WordPress to start updating its minimum PHP versions. The proposed plan is to move to PHP 5.6 by April 2019 and to PHP 7.0 by &#8220;as early as&#8221; December 2019. Notably, security support for PHP 5.6 expires in a few days, and the &#8220;end of life&#8221; for PHP 7.0 <a href=\"http://php.net/supported-versions.php\">just passed</a>.</p>\n<p>After Matt mentioned this proposal, it received an enormous amount of applause — far more applause than most of the Gutenberg news that came earlier, and Matt noticed. It is definitely welcome news!</p>\n<h4>WordPress release adoption</h4>\n<p>During the life of the WordPress 4.9 branch, there were over 173 million downloads with 68.4% of all known WordPress installs running 4.9.</p>\n<p>Matt notes that the early adoption numbers for WordPress 5.0 were very similar to WordPress 4.7, which was also a December release back in 2016.</p>\n<h4>Lessons learned in 2018</h4>\n<p>Matt took time to summarize the lessons he learned in 2018, starting with the need for teams to improve how they work together: “There should be no reason for accessibility, testing, and other teams not to be working together since these features should be a feature of everything we develop from the very beginning.” No doubt this came as a response to the concerns about accessibility in Gutenberg that surfaced before WordPress 5.0 was released.</p>\n<h3>Community Update</h3>\n<p>Matt offered some community-related data as well:</p>\n<ul>\n<li><strong>WordCamps:</strong> In 2018 there were 145 WordCamps in 48 countries, with over 45,000 tickets sold. A total of 1,300 organizers (a 33% increase!), 2,651 speakers, and 1,175 sponsors made it all possible.</li>\n<li><strong>Meetups:</strong> This year saw 50% member growth in meetup attendance, with over 687 meetup groups and 5,400 meetup events.</li>\n</ul>\n<p>And with that, he began Q&amp;A.</p>\n<p>You can view the <a href=\"https://www.youtube.com/watch?v=r5b-N2RmxS8\">State of the Word on YouTube</a> in full, and it should become available on WordPress TV very soon.</p>\n<div id=\"attachment_49969\" class=\"wp-caption aligncenter\"><img class=\"wp-image-49969 size-large\" src=\"https://cdn.poststatus.com/wp-content/uploads/2018/12/wcus-2018-sotw-5542-752x439.jpg\" alt=\"\" width=\"752\" height=\"439\" /><p class=\"wp-caption-text\">Photos by <a href=\"https://wpsessions.com\">Brian Richards</a>, for Post Status.</p></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Dec 2018 15:45:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"David Bisset\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: AMP Plugin for WordPress Version 1.0 Introduces Gutenberg-Integrated AMP Validation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86248\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"https://wptavern.com/amp-plugin-for-wordpress-version-1-0-introduces-gutenberg-integrated-amp-validation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2620:\"<p><a href=\"https://amp-wp.org/amp-plugin-1-0-stable-release/\" rel=\"noopener\" target=\"_blank\">Version 1.0</a> of the official AMP plugin for WordPress was released on the eve of WordCamp US, after two years in development by contributors from Automattic, XWP, and Google. This first stable version has a massive <a href=\"https://wordpress.org/plugins/amp/#developers\" rel=\"noopener\" target=\"_blank\">changelog</a> with 30 people credited for their contributions. The plugin is now considered ready for production and is active on more than 300,000 sites.</p>\n<p>Version 1.0 interfaces with the new editor that landed in WordPress 5.0. It will display warnings for AMP-invalid markup on a per-block basis, so users don&#8217;t have to guess what content is generating an issue.</p>\n<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/12/notices-in-blocks-1024x736.png?ssl=1\"><img /></a></p>\n<p>This release also introduces a compatibility tool that offers detailed information on AMP validation errors. It functions like a debugging page where users can see which URLs are generating errors, along with the site component (plugin, theme, or core) where the markup originates.</p>\n<p>Version 1.0 includes granular controls for selecting which templates will be served as AMP. This allows for a more gradual adoption across a site. Users can also opt for Native mode to have the entire site served as AMP.</p>\n<p>The plugin has been updated to support four of WordPress&#8217; default themes, including Twenty Fifteen, Twenty Sixteen, Twenty Seventeen, and Twenty Nineteen. The documentation for <a href=\"https://github.com/xwp/wordpress-develop/pull/307\" rel=\"noopener\" target=\"_blank\">how AMP was added to these bundled themes</a> serves as an example for how theme developers can make their own themes AMP-compatible. </p>\n<p>WordPress users who opt to use AMP on their sites will have a more successful experience with this version, thanks to the improved UI for handling AMP validation errors and the new interface for limiting AMP-support to certain templates.</p>\n<p>The AMP for WordPress project is also sporting a new <a href=\"https://amp-wp.org/\" rel=\"noopener\" target=\"_blank\">website</a> that features a collection of AMP-ready plugins and themes and a showcase of sites using AMP. It also has extensive <a href=\"https://amp-wp.org/documentation/getting-started/\" rel=\"noopener\" target=\"_blank\">documentation</a> for implementors, site owners, and developers. The site provides a central place for news and resources related to the project and its expanding ecosystem of compatible extensions.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Dec 2018 06:51:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: WordPress 5.0 “Bebo” Released, Lays A Foundation for the Platform’s Future\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86229\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://wptavern.com/wordpress-5-0-bebo-released-lays-a-foundation-for-the-platforms-future\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9407:\"<p>In 2016 at WordCamp US in Philadelphia, PA, <a href=\"https://wptavern.com/state-of-the-word-2016-mullenweg-pushes-calypso-as-future-of-wordpress-interface-proposes-major-changes-to-release-cycle\">Matt Mullenweg announced</a> to the world that a new post and page editor would be coming to WordPress. &#8220;The editor does not represent the core of WordPress publishing,&#8221; Mullenweg said.</p>\n\n\n\n<p>His <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">vision of the editor</a> was geared towards a more block-based approach that unifies widgets, shortcodes, and other areas of WordPress. Today, that vision has become a reality with the <a href=\"https://wordpress.org/news/2018/12/bebo/\">release of WordPress 5.0</a> featuring <a href=\"https://matiasventura.com/post/gutenberg-or-the-ship-of-theseus/\">project Gutenberg</a>. <br /></p>\n\n\n\n<div class=\"wp-block-image\"><img />The New Editor in WordPress 5.0</div>\n\n\n\n<p>Instead of a large blank canvas, content is broken up into a series of individual blocks that are independent from the content as a whole. For example, you can edit the HTML of one block without it affecting other blocks. </p>\n\n\n\n<p>The editor comes with more than 16 blocks to add content. You can add more blocks by <a href=\"https://wptavern.com/gutenberg-block-library-provides-a-searchable-index-of-individual-blocks\">installing and activating plugins.</a><br /></p>\n\n\n\n<div class=\"wp-block-image\"><img />Some of the Blocks That Are Available in WordPress 5.0</div>\n\n\n\n<p>Each block typically has two areas where you can manipulate its content. The Toolbar, which displays when hovering over a block, and the Inspector located in the right-hand sidebar. The Inspector houses less-often used settings that require more screen space. <br /></p>\n\n\n\n<div class=\"wp-block-image\"><img /></div>\n\n\n\n<p>Between the top toolbar, block toolbar, inspector, block mover, and hidden elements that don&#8217;t appear unless hovered over, there are a lot of user interface buttons. I suggest spending time crafting a test post to get familiar with what each button does. </p>\n\n\n\n<p>To see the new editor in action, check out the following demo video. </p>\n\n\n\nA Short Demo of The New Editor in Action\n\n\n\n<p>If you&#8217;re not ready for the new editor or discover incompatibilities with themes or plugins, you can install the <a href=\"https://wordpress.org/plugins/classic-editor/\">Classic Editor</a> plugin. This plugin will disable the new editor and replace it with the one in WordPress 4.9.8 and below. The WordPress development team <a href=\"https://make.wordpress.org/core/2018/11/07/classic-editor-plugin-support-window/\">has committed</a> to supporting the plugin until December 31st, 2021. </p>\n\n\n\n<p>Those who use assistive technology and experience accessibility issues with the new editor are encouraged to install the Classic Editor plugin until the issues are fixed. <br /></p>\n\n\n\n<h2>Twenty Nineteen: A Fully Compatible Default Theme<br /></h2>\n\n\n\n<p>WordPress 5.0 comes with a new default theme called <a href=\"https://make.wordpress.org/core/2018/10/16/introducing-twenty-nineteen/\">Twenty Nineteen</a> that is fully compatible with the new editor. It includes front-end and back-end styles to provide a What You See Is What You Get experience. It also supports the Wide and Full image alignment options. <br /></p>\n\n\n\n<div class=\"wp-block-image\"><img />Twenty Nineteen Front-End on the Left, Back-End on the Right</div>\n\n\n\n<p>You can see the theme in action on <a href=\"https://ma.tt/\">Matt Mullenweg&#8217;s site</a>.</p>\n\n\n\n<h2>What Happens to Existing Content?<br /></h2>\n\n\n\n<p>Content not created in the new editor is placed into a Classic block. This block mimics the old editor and provides users a choice to migrate it into blocks. However, migrating content into blocks is not required. Most content shouldn&#8217;t be affected by updating to WordPress 5.0. </p>\n\n\n\n<h2>Where to Get Help Using the New Editor</h2>\n\n\n\n<p>For new users, the editor might be an intuitive experience but for many WordPress veterans, it introduces a steep learning curve. After all, the previous editor has existed for more than 10 years. </p>\n\n\n\n<p>At the moment, there is a Gutenberg handbook for <a href=\"https://wordpress.org/gutenberg/handbook/designers-developers/\">Developers</a> and <a href=\"https://wordpress.org/gutenberg/handbook/contributors/\">Contributors</a> but not for Users. Work <a href=\"https://github.com/WordPress/gutenberg/issues/11252\">is underway</a> by the Docs team and other volunteer contributors to put together an initial document to release in 2019. </p>\n\n\n\n<p>Until the official handbook is published, you&#8217;ll need to seek help and education elsewhere.</p>\n\n\n\n<h3>WordPress 5.0 Essential Training</h3>\n\n\n\n<p>Morten Rand-Hendriksen, an educator for LinkedIn Learning has published <a href=\"https://www.linkedin.com/learning/wordpress-5-essential-training/?trk=insiders_23476852_learning\">a course</a> that walks users through the new editor. It&#8217;s available to view for free for the next three weeks. </p>\n\n\n\n<h3>Gutenberg Times<br /></h3>\n\n\n\n<p>Birgit Pauli-Haack has been keeping tabs on Gutenberg&#8217;s development for more than a year. <a href=\"https://gutenbergtimes.com\">Gutenberg Times</a> contains relevant information about the editor for <a href=\"https://gutenbergtimes.com/category/for-users/\">users</a> and <a href=\"https://gutenbergtimes.com/category/for-developers/\">developers</a>. </p>\n\n\n\n<h3>WordPress Support Forums<br /></h3>\n\n\n\n<p>Volunteers are standing by ready to answer your questions. If you think you&#8217;ve discovered a bug, incompatibility, or are experiencing trouble with the new editor, please post it in the <a href=\"https://wordpress.org/support/forum/how-to-and-troubleshooting/\">support forums</a>. </p>\n\n\n\n<h3>WordPress 5.0 Field Guide</h3>\n\n\n\n<p>The <a href=\"https://make.wordpress.org/core/2018/12/06/wordpress-5-0-field-guide/\">WordPress 5.0 field guide</a> provides important links and information for developers and users related to this release. <br /></p>\n\n\n\n<h2>WordPress 5.0 Is the Beginning of A New Journey</h2>\n\n\n\n<p>While WordPress 5.0 introduces a new editor, it also lays the foundation for what&#8217;s to come. The first phase of project Gutenberg was the editor. The second phase is the Customizer with a focus on full-site layouts. The third and fourth phases will be shared and discussed by Mullenweg at this year&#8217;s WordCamp US.</p>\n\n\n\n<p>The new editor is part of a long process to reinvent WordPress. Matías Ventura, Co-lead of the Gutenberg project succinctly explains why the need for Gutenberg exists. <br /></p>\n\n\n\n<blockquote class=\"wp-block-quote\"><p>WordPress has always been about the user experience, and that needs to continue to evolve under newer demands. Gutenberg is an attempt at fundamentally addressing those needs, based on the idea of content blocks. It’s an attempt to improve how users interact with their content in a fundamentally visual way, while at the same time giving developers the tools to create more fulfilling experiences for the people they are helping.</p><p>How can such a vision happen without dismantling, rebuilding, fragmenting, or breaking the WordPress ship that for over a decade has been carrying the thoughts, joys, and livelihoods of millions of people and more than a quarter of the web?</p><p>The ship, like Theseus’, needs to continue sailing while we upgrade the materials that make it. It needs to adapt to welcome new people, those that find it too rough to climb on board, too slippery a surface, too unwelcoming a sight, while retaining its essence of liberty. This is not an easy challenge—not in the slightest. </p><p>Indeed, <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">we called it Gutenberg for a reason</a>, for both its challenges and opportunities, for what it can represent in terms of continuity and change. It is an ambitious project and it needs the whole WordPress community to succeed.</p><cite><a href=\"https://matiasventura.com/post/gutenberg-or-the-ship-of-theseus/\">Matías Ventura, Co-lead of the Gutenberg project.<br /></a></cite></blockquote>\n\n\n\n<p>As the new editor <a href=\"https://wordpress.org/download/counter/\">makes its way</a> across the world, it will be interesting to see what the reactions are from users who experience it for the first time. It will also be interesting to see what the <a href=\"https://twitter.com/photomatt/status/1069327043618320385\">developer community builds</a> that takes the editor to new heights. </p>\n\n\n\n<p>WordPress 5.0 is the <a href=\"https://www.linkedin.com/pulse/gutenberg-morten-rand-hendriksen\">beginning of a new journey</a> for the project. One that will have bumpy roads, new discoveries, and plenty of opportunities to learn. So saddle up and keep your hands and arms inside the vehicle until it makes a complete stop. <br /></p>\n\n\n\n<p>WordPress 5.0 is named after <a href=\"https://en.wikipedia.org/wiki/Bebo_Vald%C3%A9s\">Bebo Valdés</a> who was a Cuban pianist, bandleader, composer and arranger. The release was led by Matt Mullenweg with Allan Cole, Anthony Burchell, Gary Pendergast, Josepha Haden Chomphosy, Laurel Fulford, Omar Reiss, Daniel Bachhuber, Matías Ventura, Miguel Fonseca, Tammie Lister, Matthew Riley MacPherson as co-leads. At least 423 people contributed to the release. <br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Dec 2018 21:38:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"Dev Blog: WordPress 5.0 “Bebo”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6328\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/news/2018/12/bebo/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:42540:\"<h2>Say Hello to the New Editor</h2>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<p>We’ve made some big upgrades to the editor. Our new block-based editor is the first step toward an exciting new future with a streamlined editing experience across your site. You’ll have more flexibility with how content is displayed, whether you are building your first site, revamping your blog, or write code for a living.</p>\n\n\n\n<div class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Gutenberg.jpg?fit=2400%2C1200&ssl=1\" alt=\"\" class=\"wp-image-6331\" /></div>\n\n\n\n<h2>Building with Blocks</h2>\n\n\n\n<p>The new block-based editor won’t change the way any of your content looks to your visitors. What it will do is let you insert any type of multimedia in a snap and rearrange to your heart’s content. Each piece of content will be in its own block; a distinct wrapper for easy maneuvering. If you’re more of an HTML and CSS sort of person, then the blocks won’t stand in your way. WordPress is here to simplify the process, not the outcome.</p>\n\n\n\n\n\n\n\n<p>We have tons of blocks available by default, and more get added by the community every day. Here are a few of the blocks to help you get started:</p>\n\n\n\n<ul class=\"wp-block-gallery columns-4 is-cropped\"><li class=\"blocks-gallery-item\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Paragraph.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6340\" />Paragraph</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Heading.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6341\" />Heading</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Preformatted.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6342\" />Preformatted</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Quote.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6343\" />Quote</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Image.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6344\" />Image</li><li class=\"blocks-gallery-item\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Gallery.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6345\" />Gallery</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Cover-Image.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6346\" />Cover</li><li class=\"blocks-gallery-item\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Video.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6347\" />Video</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Audio.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6348\" />Audio</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Column.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6349\" />Columns</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-File.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6350\" />File</li><li class=\"blocks-gallery-item\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Code.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6351\" />Code</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-List.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6352\" />List</li><li class=\"blocks-gallery-item\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Button.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6353\" />Button</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-Embeds.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6354\" />Embeds</li><li class=\"blocks-gallery-item\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Block-Icon-More.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6355\" />More</li></ul>\n\n\n\n<h2>Freedom to Build, Freedom to Write</h2>\n\n\n\n<p>This new editing experience provides a more consistent treatment of design as well as content. If you’re building client sites, you can create reusable blocks. This lets your clients add new content anytime, while still maintaining a consistent look and feel.</p>\n\n\n\n\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>A Stunning New Default Theme</h2>\n\n\n\n<div class=\"wp-block-image\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen.jpg?fit=2400%2C1600&ssl=1\" alt=\"\" class=\"wp-image-6358\" /></div>\n\n\n\n<p>Introducing Twenty Nineteen, a new default theme that shows off the power of the new editor.</p>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/block-editor-1024x683.jpg?resize=632%2C422&ssl=1\" alt=\"\" class=\"wp-image-6359\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_9\">Designed for the block editor</h3>\n\n\n\n<p>Twenty Nineteen features custom styles for the blocks available by default in 5.0. It makes extensive use of editor styles throughout the theme. That way, what you create in your content editor is what you see on the front of your site.<br /></p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/typography-1.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6427\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_18\">Simple, type-driven layout</h3>\n\n\n\n<p>Featuring ample whitespace, and modern sans-serif headlines paired with classic serif body text, Twenty Nineteen is built to be beautiful on the go. It uses system fonts to increase loading speed. No more long waits on slow networks!</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/twenty-nineteen-versatile.gif?w=632&ssl=1\" alt=\"\" class=\"wp-image-6361\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_24\">Versatile design for all sites</h3>\n\n\n\n<p>Twenty Nineteen is designed to work for a wide variety of use cases. Whether you’re running a photo blog, launching a new business, or supporting a non-profit, Twenty Nineteen is flexible enough to fit your needs.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/themes/twentynineteen/\">Give Twenty Nineteen a try</a></div>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>Developer Happiness</h2>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Protect.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6362\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_34\">Protect</h3>\n\n\n\n<p>Blocks provide a comfortable way for users to change content directly, while also ensuring the content structure cannot be easily disturbed by accidental code edits. This allows the developer to control the output, building polished and semantic markup that is preserved through edits and not easily broken.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2018/12/Compose.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6363\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_39\">Compose</h3>\n\n\n\n<p>Take advantage of a wide collection of APIs and interface components to easily create blocks with intuitive controls for your clients. Utilizing these components not only speeds up development work but also provide a more consistent, usable, and accessible interface to all users.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Create.jpg?w=632&ssl=1\" alt=\"\" class=\"wp-image-6364\" /><div class=\"wp-block-media-text__content\">\n<h3 id=\"mce_45\">Create</h3>\n\n\n\n<p>The new block paradigm opens up a path of exploration and imagination when it comes to solving user needs. With the unified block insertion flow, it’s easier for your clients and customers to find and use blocks for all types of content. Developers can focus on executing their vision and providing rich editing experiences, rather than fussing with difficult APIs.</p>\n</div></div>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/gutenberg/handbook/\">Learn how to get started</a></div>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>Keep it Classic</h2>\n\n\n\n<div class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2018/12/Classic.jpg?fit=2400%2C1130&ssl=1\" alt=\"\" class=\"wp-image-6365\" /></div>\n\n\n\n<p>Prefer to stick with the familiar Classic Editor? No problem! Support for the Classic Editor plugin will remain in WordPress through 2021.</p>\n\n\n\n<p>The Classic Editor plugin restores the previous WordPress editor and the Edit Post screen. It lets you keep using plugins that extend it, add old-style meta boxes, or otherwise depend on the previous editor. To install, visit your plugins page and click the “Install Now” button next to “Classic Editor”. After the plugin finishes installing, click “Activate”. That’s it!</p>\n\n\n\n<p>Note to users of assistive technology: if you experience usability issues with the block editor, we recommend you continue to use the Classic Editor.</p>\n\n\n\n<div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link has-text-color\" href=\"https://wordpress.org/plugins/classic-editor/\">Check out the Classic Editor</a></div>\n\n\n\n<p>This release is named in homage to the pioneering Cuban jazz musician <a href=\"https://en.wikipedia.org/wiki/Bebo_Vald%C3%A9s\">Bebo Valdés</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>The Squad</h2>\n\n\n\n<p>This release was led by <a href=\"http://ma.tt/\">Matt Mullenweg</a>, along with co-leads <a href=\"https://www.allancole.com/\">Allan Cole</a>, <a href=\"http://antpb.com/\">Anthony Burchell</a>, <a href=\"https://pento.net/\">Gary Pendergast</a>, <a href=\"https://josepha.blog/\">Josepha Haden Chomphosy</a>, <a href=\"https://laurel.blog/\">Laurel Fulford</a>, <a href=\"https://yoast.com/about-us/team/omar-reiss/\">Omar Reiss</a>, <a href=\"https://danielbachhuber.com/\">Daniel Bachhuber</a>, <a href=\"https://matiasventura.com/\">Matías Ventura</a>, <a href=\"https://lamda.blog/\">Miguel Fonseca</a>, <a href=\"https://tam.blog/\">Tammie Lister</a>, <a href=\"https://tofumatt.com/\">Matthew Riley MacPherson</a>. They were ably assisted by the following fabulous folks. There were 423 contributors with props in this release. Pull up some Bebo Valdés on your music service of choice, and check out some of their profiles:</p>\n\n\n<a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abdulwahab610\">Abdul Wahab</a>, <a href=\"https://profiles.wordpress.org/abdullahramzan\">Abdullah Ramzan</a>, <a href=\"https://profiles.wordpress.org/abhijitrakas\">Abhijit Rakas</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/afraithe\">afraithe</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/ahmadawais\">ahmadawais</a>, <a href=\"https://profiles.wordpress.org/airathalitov\">Airat Halitov</a>, <a href=\"https://profiles.wordpress.org/ajitbohra\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/schlessera\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/albertomedina\">albertomedina</a>, <a href=\"https://profiles.wordpress.org/aldavigdis\">aldavigdis</a>, <a href=\"https://profiles.wordpress.org/alexsanford1\">Alex Sanford</a>, <a href=\"https://profiles.wordpress.org/xyfi\">Alexander Botteram</a>, <a href=\"https://profiles.wordpress.org/alexis\">alexis</a>, <a href=\"https://profiles.wordpress.org/alexislloyd\">Alexis Lloyd</a>, <a href=\"https://profiles.wordpress.org/arush\">Amanda Rush</a>, <a href=\"https://profiles.wordpress.org/amedina\">amedina</a>, <a href=\"https://profiles.wordpress.org/nosolosw\">Andr&#233;s</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/euthelup\">Andrei Lupu</a>, <a href=\"https://profiles.wordpress.org/andreiglingeanu\">andreiglingeanu</a>, <a href=\"https://profiles.wordpress.org/aduth\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/sumobi\">Andrew Munro</a>, <a href=\"https://profiles.wordpress.org/anevins\">Andrew Nevins</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/androb\">Andrew Roberts</a>, <a href=\"https://profiles.wordpress.org/andrewtaylor-1\">Andrew Taylor</a>, <a href=\"https://profiles.wordpress.org/andrewserong\">andrewserong</a>, <a href=\"https://profiles.wordpress.org/apeatling\">Andy Peatling</a>, <a href=\"https://profiles.wordpress.org/ameeker\">Angie Meeker</a>, <a href=\"https://profiles.wordpress.org/annaharrison\">Anna Harrison</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/arnaudban\">ArnaudBan</a>, <a href=\"https://profiles.wordpress.org/arshidkv12\">Arshid</a>, <a href=\"https://profiles.wordpress.org/aprakasa\">Arya Prakasa</a>, <a href=\"https://profiles.wordpress.org/artisticasad\">Asad</a>, <a href=\"https://profiles.wordpress.org/mrasharirfan\">Ashar Irfan</a>, <a href=\"https://profiles.wordpress.org/asvinballoo\">Asvin Balloo</a>, <a href=\"https://profiles.wordpress.org/atanasangelovdev\">Atanas Angelov</a>, <a href=\"https://profiles.wordpress.org/b-07\">Bappi</a>, <a href=\"https://profiles.wordpress.org/bcolumbia\">bcolumbia</a>, <a href=\"https://profiles.wordpress.org/belcherj\">belcherj</a>, <a href=\"https://profiles.wordpress.org/blowery\">Ben Lowery</a>, <a href=\"https://profiles.wordpress.org/caxco93\">Benjamin Eyzaguirre</a>, <a href=\"https://profiles.wordpress.org/benjamin_zekavica\">Benjamin Zekavica</a>, <a href=\"https://profiles.wordpress.org/benlk\">benlk</a>, <a href=\"https://profiles.wordpress.org/kau-boy\">Bernhard Kau</a>, <a href=\"https://profiles.wordpress.org/bernhard-reiter\">Bernhard Reiter</a>, <a href=\"https://profiles.wordpress.org/betsela\">betsela</a>, <a href=\"https://profiles.wordpress.org/bhargavmehta\">Bhargav Mehta</a>, <a href=\"https://profiles.wordpress.org/birgire\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bph\">Birgit Pauli-Haack</a>, <a href=\"https://profiles.wordpress.org/bobbingwide\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/boblinthorst\">boblinthorst</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bradyvercher\">Brady Vercher</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/bpayton\">Brandon Payton</a>, <a href=\"https://profiles.wordpress.org/brentswisher\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/technosiren\">Brianna Privett</a>, <a href=\"https://profiles.wordpress.org/briannaorg\">briannaorg</a>, <a href=\"https://profiles.wordpress.org/bronsonquick\">Bronson Quick</a>, <a href=\"https://profiles.wordpress.org/bandonrandon\">Brooke.</a>, <a href=\"https://profiles.wordpress.org/burhandodhy\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cantothemes\">CantoThemes</a>, <a href=\"https://profiles.wordpress.org/cathibosco\">cathibosco</a>, <a href=\"https://profiles.wordpress.org/chetan200891\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chetansatasiya\">chetansatasiya</a>, <a href=\"https://profiles.wordpress.org/ketuchetan\">chetansatasiya</a>, <a href=\"https://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisl27\">Chris Lloyd</a>, <a href=\"https://profiles.wordpress.org/crunnells\">Chris Runnells</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/chriskmnds\">chriskmnds</a>, <a href=\"https://profiles.wordpress.org/pixelverbieger\">Christian Sabo</a>, <a href=\"https://profiles.wordpress.org/christophherr\">Christoph Herr</a>, <a href=\"https://profiles.wordpress.org/claudiosanches\">Claudio Sanches</a>, <a href=\"https://profiles.wordpress.org/coderkevin\">coderkevin</a>, <a href=\"https://profiles.wordpress.org/copons\">Copons</a>, <a href=\"https://profiles.wordpress.org/courtney0burton\">courtney0burton</a>, <a href=\"https://profiles.wordpress.org/mitogh\">Crisoforo Gaspar Hernandez</a>, <a href=\"https://profiles.wordpress.org/littlebigthing\">Csaba (LittleBigThings)</a>, <a href=\"https://profiles.wordpress.org/csabotta\">csabotta</a>, <a href=\"https://profiles.wordpress.org/danieltj\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/talldanwp\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/danielhw\">danielhw</a>, <a href=\"https://profiles.wordpress.org/daniloercoli\">daniloercoli</a>, <a href=\"https://profiles.wordpress.org/dannycooper\">DannyCooper</a>, <a href=\"https://profiles.wordpress.org/nerrad\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/davemoran118\">davemoran118</a>, <a href=\"https://profiles.wordpress.org/dcavins\">David Cavins</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David Kennedy</a>, <a href=\"https://profiles.wordpress.org/dryanpress\">David Ryan</a>, <a href=\"https://profiles.wordpress.org/davidsword\">David Sword</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/davidherrera\">davidherrera</a>, <a href=\"https://profiles.wordpress.org/davisshaver\">Davis</a>, <a href=\"https://profiles.wordpress.org/dciso\">dciso</a>, <a href=\"https://profiles.wordpress.org/dmsnell\">Dennis Snell</a>, <a href=\"https://profiles.wordpress.org/dsmart\">Derek Smart</a>, <a href=\"https://profiles.wordpress.org/designsimply\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dlocc\">Devin Walker</a>, <a href=\"https://profiles.wordpress.org/deviodigital\">Devio Digital</a>, <a href=\"https://profiles.wordpress.org/dfangstrom\">dfangstrom</a>, <a href=\"https://profiles.wordpress.org/dhanendran\">Dhanendran</a>, <a href=\"https://profiles.wordpress.org/diegoliv\">Diego de Oliveira</a>, <a href=\"https://profiles.wordpress.org/diegoreymendez\">diegoreymendez</a>, <a href=\"https://profiles.wordpress.org/dingo_bastard\">dingo-d</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dency\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/dixitadusara\">Dixita Dusara Gohil</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/donnapep\">Donna Peplinskie</a>, <a href=\"https://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dsawardekar\">dsawardekar</a>, <a href=\"https://profiles.wordpress.org/dsifford\">dsifford</a>, <a href=\"https://profiles.wordpress.org/duanestorey\">Duane Storey</a>, <a href=\"https://profiles.wordpress.org/chopinbach\">Edwin Cromley</a>, <a href=\"https://profiles.wordpress.org/ehg\">ehg</a>, <a href=\"https://profiles.wordpress.org/electricfeet\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/epointal\">Elisabeth Pointal</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/elrae\">elrae</a>, <a href=\"https://profiles.wordpress.org/enodekciw\">enodekciw</a>, <a href=\"https://profiles.wordpress.org/ephoxjames\">ephoxjames</a>, <a href=\"https://profiles.wordpress.org/ephoxmogran\">ephoxmogran</a>, <a href=\"https://profiles.wordpress.org/sewmyheadon\">Eric Amundson</a>, <a href=\"https://profiles.wordpress.org/ericnmurphy\">ericnmurphy</a>, <a href=\"https://profiles.wordpress.org/etoledom\">etoledom</a>, <a href=\"https://profiles.wordpress.org/circlecube\">Evan Mullins</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy\">fabiankaegy</a>, <a href=\"https://profiles.wordpress.org/fabs_pim\">fabs_pim</a>, <a href=\"https://profiles.wordpress.org/faishal\">Faishal</a>, <a href=\"https://profiles.wordpress.org/flixos90\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/floriansimeth\">Florian Simeth</a>, <a href=\"https://profiles.wordpress.org/foobar4u\">foobar4u</a>, <a href=\"https://profiles.wordpress.org/foreverpinetree\">foreverpinetree</a>, <a href=\"https://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/fuyuko\">fuyuko</a>, <a href=\"https://profiles.wordpress.org/gma992\">Gabriel Maldonado</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/doomwaxer\">Gary Thayer</a>, <a href=\"https://profiles.wordpress.org/garyjones\">garyjones</a>, <a href=\"https://profiles.wordpress.org/soulseekah\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/babbardel\">George Olaru</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/georgeh\">georgeh</a>, <a href=\"https://profiles.wordpress.org/gnif\">gnif</a>, <a href=\"https://profiles.wordpress.org/goldsounds\">goldsounds</a>, <a href=\"https://profiles.wordpress.org/grappler\">Grappler</a>, <a href=\"https://profiles.wordpress.org/gziolo\">Grzegorz Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/bordoni\">Gustavo Bordoni</a>, <a href=\"https://profiles.wordpress.org/gwwar\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hardeepasrani\">Hardeep Asrani</a>, <a href=\"https://profiles.wordpress.org/hblackett\">hblackett</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandi</a>, <a href=\"https://profiles.wordpress.org/luehrsen\">Hendrik Luehrsen</a>, <a href=\"https://profiles.wordpress.org/herbmiller\">herbmiller</a>, <a href=\"https://profiles.wordpress.org/herregroen\">Herre Groen</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/hypest\">hypest</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianstewart\">ianstewart</a>, <a href=\"https://profiles.wordpress.org/ianbelanger\">ibelanger</a>, <a href=\"https://profiles.wordpress.org/icaleb\">iCaleb</a>, <a href=\"https://profiles.wordpress.org/idpokute\">idpokute</a>, <a href=\"https://profiles.wordpress.org/igorsch\">Igor</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/imonly_ik\">Imran Khalid</a>, <a href=\"https://profiles.wordpress.org/intronic\">intronic</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/ireneyoast\">Irene Strikkers</a>, <a href=\"https://profiles.wordpress.org/ismailelkorchi\">Ismail El Korchi</a>, <a href=\"https://profiles.wordpress.org/israelshmueli\">israelshmueli</a>, <a href=\"https://profiles.wordpress.org/jd55\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jakept\">Jacob Peattie</a>, <a href=\"https://profiles.wordpress.org/jagnew\">jagnew</a>, <a href=\"https://profiles.wordpress.org/jahvi\">jahvi</a>, <a href=\"https://profiles.wordpress.org/jnylen0\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/jamestryon\">jamestryon</a>, <a href=\"https://profiles.wordpress.org/jamiehalvorson\">jamiehalvorson</a>, <a href=\"https://profiles.wordpress.org/jdembowski\">Jan Dembowski</a>, <a href=\"https://profiles.wordpress.org/janalwin\">janalwin</a>, <a href=\"https://profiles.wordpress.org/jaswrks\">Jason Caldwell</a>, <a href=\"https://profiles.wordpress.org/octalmage\">Jason Stallings</a>, <a href=\"https://profiles.wordpress.org/yingling017\">Jason Yingling</a>, <a href=\"https://profiles.wordpress.org/vengisss\">Javier Villanueva</a>, <a href=\"https://profiles.wordpress.org/jhoffm34\">Jay Hoffmann</a>, <a href=\"https://profiles.wordpress.org/audrasjb\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jblz\">Jeff Bowen</a>, <a href=\"https://profiles.wordpress.org/jeffpaul\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">JJJ</a>, <a href=\"https://profiles.wordpress.org/sephsekla\">Joe Bailey-Roberts</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joemaller\">joemaller</a>, <a href=\"https://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/j-falk\">Johan Falk</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnny5\">John Godley</a>, <a href=\"https://profiles.wordpress.org/johndyer\">johndyer</a>, <a href=\"https://profiles.wordpress.org/johnpixle\">JohnPixle</a>, <a href=\"https://profiles.wordpress.org/johnwatkins0\">johnwatkins0</a>, <a href=\"https://profiles.wordpress.org/jomurgel\">jomurgel</a>, <a href=\"https://profiles.wordpress.org/jonsurrell\">Jon Surrell</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/koke\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/ieatwebsites\">Jose Fremaint</a>, <a href=\"https://profiles.wordpress.org/shelob9\">Josh Pollock</a>, <a href=\"https://profiles.wordpress.org/jvisick77\">Josh Visick</a>, <a href=\"https://profiles.wordpress.org/joshuawold\">Joshua Wold</a>, <a href=\"https://profiles.wordpress.org/joyously\">Joy</a>, <a href=\"https://profiles.wordpress.org/jrf\">jrf</a>, <a href=\"https://profiles.wordpress.org/jryancard\">jryancard</a>, <a href=\"https://profiles.wordpress.org/jsnajdr\">jsnajdr</a>, <a href=\"https://profiles.wordpress.org/julienmelissas\">JulienMelissas</a>, <a href=\"https://profiles.wordpress.org/kopepasah\">Justin Kopepasah</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"https://profiles.wordpress.org/kallehauge\">Kallehauge</a>, <a href=\"https://profiles.wordpress.org/kalpshit\">KalpShit Akabari</a>, <a href=\"https://profiles.wordpress.org/codebykat\">Kat Hagan</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kevinwhoffman\">Kevin Hoffman</a>, <a href=\"https://profiles.wordpress.org/khleomix\">khleomix</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/kluny\">kluny</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/krutidugade\">krutidugade</a>, <a href=\"https://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/notlaura\">Lara Schenck</a>, <a href=\"https://profiles.wordpress.org/leahkoerper\">leahkoerper</a>, <a href=\"https://profiles.wordpress.org/lloyd\">lloyd</a>, <a href=\"https://profiles.wordpress.org/loicblascos\">Lo&#239;c Blascos</a>, <a href=\"https://profiles.wordpress.org/lucasstark\">Lucas Stark</a>, <a href=\"https://profiles.wordpress.org/lucasrolff\">LucasRolff</a>, <a href=\"https://profiles.wordpress.org/luigipulcini\">luigipulcini</a>, <a href=\"https://profiles.wordpress.org/lukecavanagh\">Luke Cavanagh</a>, <a href=\"https://profiles.wordpress.org/lucaskowalski\">Luke Kowalski</a>, <a href=\"https://profiles.wordpress.org/lukepettway\">Luke Pettway</a>, <a href=\"https://profiles.wordpress.org/luminus\">Luminus</a>, <a href=\"https://profiles.wordpress.org/lynneux\">lynneux</a>, <a href=\"https://profiles.wordpress.org/macbookandrew\">macbookandrew</a>, <a href=\"https://profiles.wordpress.org/maedahbatool\">Maedah Batool</a>, <a href=\"https://profiles.wordpress.org/mahdiyazdani\">Mahdi Yazdani</a>, <a href=\"https://profiles.wordpress.org/mahmoudsaeed\">mahmoudsaeed</a>, <a href=\"https://profiles.wordpress.org/travel_girl\">Maja Benke</a>, <a href=\"https://profiles.wordpress.org/mkaz\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/marina_wp\">marina_wp</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mariusvw\">mariusvw</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/mapk\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/vindl\">Marko Andrijasevic</a>, <a href=\"https://profiles.wordpress.org/martinlugton\">martinlugton</a>, <a href=\"https://profiles.wordpress.org/m-e-h\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/mathiu\">mathiu</a>, <a href=\"https://profiles.wordpress.org/webdevmattcrom\">Matt Cromwell</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/mattgeri\">MattGeri</a>, <a href=\"https://profiles.wordpress.org/mboynes\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/maurobringolf\">maurobringolf</a>, <a href=\"https://profiles.wordpress.org/maximebj\">Maxime BERNARD-JACQUET</a>, <a href=\"https://profiles.wordpress.org/mayukojpn\">Mayo Moriyama</a>, <a href=\"https://profiles.wordpress.org/meetjey\">meetjey</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mendezcode\">mendezcode</a>, <a href=\"https://profiles.wordpress.org/woodent\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/wpscholar\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Michael Adams (mdawaffe)</a>, <a href=\"https://profiles.wordpress.org/michaelhull\">Michael Hull</a>, <a href=\"https://profiles.wordpress.org/mnelson4\">Michael Nelson</a>, <a href=\"https://profiles.wordpress.org/mizejewski\">Michele Mizejewski</a>, <a href=\"https://profiles.wordpress.org/jbpaul17\">Migrated to @jeffpaul</a>, <a href=\"https://profiles.wordpress.org/stubgo\">Miina Sikk</a>, <a href=\"https://profiles.wordpress.org/simison\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mihai2u\">Mike Crantea</a>, <a href=\"https://profiles.wordpress.org/mike-haydon-swo\">Mike Haydon</a>, <a href=\"https://profiles.wordpress.org/mikeschroder\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeselander\">Mike Selander</a>, <a href=\"https://profiles.wordpress.org/mikehaydon\">mikehaydon</a>, <a href=\"https://profiles.wordpress.org/mikeyarce\">Mikey Arce</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/milana_cap\">Milana Cap</a>, <a href=\"https://profiles.wordpress.org/gonzomir\">Milen Petrinski - Gonzo</a>, <a href=\"https://profiles.wordpress.org/milesdelliott\">milesdelliott</a>, <a href=\"https://profiles.wordpress.org/mimo84\">mimo84</a>, <a href=\"https://profiles.wordpress.org/0mirka00\">mirka</a>, <a href=\"https://profiles.wordpress.org/mmtr86\">mmtr86</a>, <a href=\"https://profiles.wordpress.org/boemedia\">Monique Dubbelman</a>, <a href=\"https://profiles.wordpress.org/mor10\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/mostafas1990\">Mostafa Soufi</a>, <a href=\"https://profiles.wordpress.org/motleydev\">motleydev</a>, <a href=\"https://profiles.wordpress.org/mpheasant\">mpheasant</a>, <a href=\"https://profiles.wordpress.org/mrmadhat\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/mrwweb\">mrwweb</a>, <a href=\"https://profiles.wordpress.org/msdesign21\">msdesign21</a>, <a href=\"https://profiles.wordpress.org/mtias\">mtias</a>, <a href=\"https://profiles.wordpress.org/desideveloper\">Muhammad Irfan</a>, <a href=\"https://profiles.wordpress.org/mukesh27\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/munirkamal\">munirkamal</a>, <a href=\"https://profiles.wordpress.org/mmaumio\">Muntasir Mahmud</a>, <a href=\"https://profiles.wordpress.org/mzorz\">mzorz</a>, <a href=\"https://profiles.wordpress.org/nagayama\">nagayama</a>, <a href=\"https://profiles.wordpress.org/nfmohit\">Nahid F. Mohit</a>, <a href=\"https://profiles.wordpress.org/nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/napy84\">napy84</a>, <a href=\"https://profiles.wordpress.org/nateconley\">nateconley</a>, <a href=\"https://profiles.wordpress.org/nativeinside\">Native Inside</a>, <a href=\"https://profiles.wordpress.org/greatislander\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/buzztone\">Neil Murray</a>, <a href=\"https://profiles.wordpress.org/nicbertino\">nic.bertino</a>, <a href=\"https://profiles.wordpress.org/notnownikki\">Nicola Heald</a>, <a href=\"https://profiles.wordpress.org/nielslange\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/nikschavan\">Nikhil Chavan</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/nitrajka\">nitrajka</a>, <a href=\"https://profiles.wordpress.org/njpanderson\">njpanderson</a>, <a href=\"https://profiles.wordpress.org/nshki\">nshki</a>, <a href=\"https://profiles.wordpress.org/hideokamoto\">Okamoto Hidetaka</a>, <a href=\"https://profiles.wordpress.org/oskosk\">oskosk</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya-1\">Paresh Radadiya</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pauldechov\">Paul Dechov</a>, <a href=\"https://profiles.wordpress.org/paulstonier\">Paul Stonier</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/pedromendonca\">Pedro Mendon&#231;a</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/pglewis\">pglewis</a>, <a href=\"https://profiles.wordpress.org/tyrannous\">Philipp Bammes</a>, <a href=\"https://profiles.wordpress.org/piersb\">piersb</a>, <a href=\"https://profiles.wordpress.org/wizzard_\">Pieter Daalder</a>, <a href=\"https://profiles.wordpress.org/pilou69\">pilou69</a>, <a href=\"https://profiles.wordpress.org/delawski\">Piotr Delawski</a>, <a href=\"https://profiles.wordpress.org/poena\">poena</a>, <a href=\"https://profiles.wordpress.org/postphotos\">postphotos</a>, <a href=\"https://profiles.wordpress.org/potbot\">potbot</a>, <a href=\"https://profiles.wordpress.org/prtksxna\">Prateek Saxena</a>, <a href=\"https://profiles.wordpress.org/pratikthink\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/presskopp\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/psealock\">psealock</a>, <a href=\"https://profiles.wordpress.org/ptasker\">ptasker</a>, <a href=\"https://profiles.wordpress.org/rachelmcr\">Rachel</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rahmohn\">Rahmohn</a>, <a href=\"https://profiles.wordpress.org/rahmon\">Rahmon</a>, <a href=\"https://profiles.wordpress.org/rahulsprajapati\">Rahul Prajapati</a>, <a href=\"https://profiles.wordpress.org/rakshans1\">rakshans1</a>, <a href=\"https://profiles.wordpress.org/ramonopoly\">ramonopoly</a>, <a href=\"https://profiles.wordpress.org/lamosty\">Rastislav Lamos</a>, <a href=\"https://profiles.wordpress.org/revgeorge\">revgeorge</a>, <a href=\"https://profiles.wordpress.org/youknowriad\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/richsalvucci\">richsalvucci</a>, <a href=\"https://profiles.wordpress.org/riddhiehta02\">Riddhi Mehta</a>, <a href=\"https://profiles.wordpress.org/rileybrook\">rileybrook</a>, <a href=\"https://profiles.wordpress.org/noisysocks\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/sanchothefat\">Robert O\'Rourke</a>, <a href=\"https://profiles.wordpress.org/robertsky\">robertsky</a>, <a href=\"https://profiles.wordpress.org/_dorsvenabili\">Rocio Valdivia</a>, <a href=\"https://profiles.wordpress.org/rohittm\">Rohit Motwani</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/ryo511\">ryo511</a>, <a href=\"https://profiles.wordpress.org/sagarprajapati\">Sagar Prajapati</a>, <a href=\"https://profiles.wordpress.org/samikeijonen\">Sami Keijonen</a>, <a href=\"https://profiles.wordpress.org/otto42\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/smyoon315\">Sang-Min Yoon</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/scottmweaver\">Scott Weaver</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sergioestevao\">SergioEstevao</a>, <a href=\"https://profiles.wordpress.org/azchughtai\">Shahjehan Ali</a>, <a href=\"https://profiles.wordpress.org/shaileesheth\">Shailee Sheth</a>, <a href=\"https://profiles.wordpress.org/sharaz\">Sharaz Shahid</a>, <a href=\"https://profiles.wordpress.org/giventofly76\">Shaun sc</a>, <a href=\"https://profiles.wordpress.org/shaunandrews\">shaunandrews</a>, <a href=\"https://profiles.wordpress.org/shooper\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/shenkj\">shenkj</a>, <a href=\"https://profiles.wordpress.org/sikander\">sikander</a>, <a href=\"https://profiles.wordpress.org/pross\">Simon Prosser</a>, <a href=\"https://profiles.wordpress.org/siriokun\">siriokun</a>, <a href=\"https://profiles.wordpress.org/sirjonathan\">sirjonathan</a>, <a href=\"https://profiles.wordpress.org/sirreal\">sirreal</a>, <a href=\"https://profiles.wordpress.org/sisanu\">Sisanu</a>, <a href=\"https://profiles.wordpress.org/skorasaurus\">skorasaurus</a>, <a href=\"https://profiles.wordpress.org/butimnoexpert\">Slushman</a>, <a href=\"https://profiles.wordpress.org/ssousa\">Sofia Sousa</a>, <a href=\"https://profiles.wordpress.org/somtijds\">SOMTIJDS</a>, <a href=\"https://profiles.wordpress.org/soean\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/spocke\">spocke</a>, <a href=\"https://profiles.wordpress.org/stagger-lee\">Stagger Lee</a>, <a href=\"https://profiles.wordpress.org/sstoqnov\">Stanimir Stoyanov</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevehenty\">Steve Henty</a>, <a href=\"https://profiles.wordpress.org/charlestonsw\">Store Locator Plus</a>, <a href=\"https://profiles.wordpress.org/strategio\">strategio</a>, <a href=\"https://profiles.wordpress.org/stuartfeldt\">stuartfeldt</a>, <a href=\"https://profiles.wordpress.org/tacrapo\">tacrapo</a>, <a href=\"https://profiles.wordpress.org/talldan\">talldan</a>, <a href=\"https://profiles.wordpress.org/tammie_l\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/themeroots\">ThemeRoots</a>, <a href=\"https://profiles.wordpress.org/tfrommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/hedgefield\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/timgardner\">timgardner</a>, <a href=\"https://profiles.wordpress.org/timmydcrawford\">Timmy Crawford</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tjnowell\">Tom J Nowell</a>, <a href=\"https://profiles.wordpress.org/tlxo\">Toni Laakso</a>, <a href=\"https://profiles.wordpress.org/skithund\">Toni Viemer&#246;</a>, <a href=\"https://profiles.wordpress.org/tobifjellner\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/toro_unit\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/mirucon\">Toshihiro Kanai</a>, <a href=\"https://profiles.wordpress.org/itowhid06\">Towhidul Islam</a>, <a href=\"https://profiles.wordpress.org/travislopes\">Travis Lopes</a>, <a href=\"https://profiles.wordpress.org/truongwp\">truongwp</a>, <a href=\"https://profiles.wordpress.org/tjfunke001\">Tunji Ayoola</a>, <a href=\"https://profiles.wordpress.org/twoelevenjay\">twoelevenjay</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/vishalkakadiya\">Vishal Kakadiya</a>, <a href=\"https://profiles.wordpress.org/vtrpldn\">Vitor Paladini</a>, <a href=\"https://profiles.wordpress.org/walterebert\">Walter Ebert</a>, <a href=\"https://profiles.wordpress.org/warmarks\">warmarks</a>, <a href=\"https://profiles.wordpress.org/webmandesign\">WebMan Design &#124; Oliver Juhas</a>, <a href=\"https://profiles.wordpress.org/websupporter\">websupporter</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton\">williampatton</a>, <a href=\"https://profiles.wordpress.org/willybahuaud\">Willy Bahuaud</a>, <a href=\"https://profiles.wordpress.org/yahil\">Yahil Madakiya</a>, <a href=\"https://profiles.wordpress.org/yingles\">yingles</a>, <a href=\"https://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/youthkee\">Yusuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/zebulan\">zebulan</a>, and <a href=\"https://profiles.wordpress.org/ziyaddin\">Ziyaddin Sadigov</a>.\n\n\n\n<p>Finally, thanks to all the community translators who worked on WordPress 5.0. Their efforts bring WordPress 5.0 fully translated to 37 languages at release time, with more on the way.</p>\n\n\n\n<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>\n\n\n\n<p>Thanks for choosing WordPress!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Dec 2018 19:28:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"Post Status: WordPress 5.0 marks a new era for the world’s most popular CMS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=49548\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"https://poststatus.com/wordpress-5-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5170:\"<p>WordPress 5.0, &#8220;<a href=\"https://wordpress.org/news/2018/12/bebo/\">Bebo</a>,&#8221; is a shift of the highest order for the platform. Block-based editing, under the name of &#8220;Gutenberg,&#8221; is an entirely new way to publish content. It adds a world of flexibility when writing, and it opens the gates for transforming much of the broader WordPress experience moving forward.</p>\n<p></p>\n<p>TinyMCE has been the core of the WordPress writing experience for, well, forever. Users will be able to continue using TinyMCE with the <a href=\"https://wordpress.org/plugins/classic-editor/\">Classic Editor</a> plugin, which will be especially useful for those web applications with significant amounts of structured content that will take time and reprogramming to fit the new editing experience.</p>\n<p>The need for a new editor has been a wide-held concern in the WordPress community for a long time. Gutenberg has been more than two years in the making, and it involved dozens of full-time or near full-time contributors at times. Automattic, the company behind WordPress.com and other popular WordPress products, has invested a great deal in Gutenberg&#8217;s development, as have many other companies and individuals — but the bulk of development and decision-making has been by Automattic employees.</p>\n<p>There have been critiques that the process for decision making has been too closed off and rushed toward the end of the development cycle for the purpose of delivery by WordCamp US despite ongoing concerns, particularly around accessibility.</p>\n<p>5.0 had to ship eventually, and the process has been a long one. It was a complete shift from the traditional development cycles, which <a href=\"https://poststatus.com/interview-matt-mullenweg-new-wordpress-release-cycle/\">I discussed with Matt Mullenweg</a> at WordCamp US two years ago.</p>\n<p>I have personally held the view that now is as good a time as any to release 5.0, though the exact timing is a burden on folks traveling to WCUS, particularly considering that it was just a few days notice; it is putting a kink in the plans of many.</p>\n<p>Timing aside, Gutenberg is, I believe, an important step and a big test for WordPress. It is imperative that the platform evolves to be both more powerful and easier to use — an enormously difficult dual challenge that I have advocated as an important feat to accomplish for several years now.</p>\n<p>WordPress is the easiest full-featured content management system to use. But it is more difficult than many alternative publishing platforms — particularly hosted ones. Drastic changes, like Gutenberg, are necessary to continue being a preferred platform for end users. Being easy to use and customize got WordPress to the dominant position it is in today, and I believe it is extremely important to continue in that trajectory to maintain that position.</p>\n<p>At the same time, as WordPress is being used in ever more advanced applications, developers need powerful, scalable solutions. WordPress has made great strides over the years to accommodate this use case, from various APIs to assist in new data structure creation, to the REST API. Gutenberg offers much promise to continue this trend, as it is quite extendable and also flexible for deployment on the web, in native apps, and on both front-ends and backends.</p>\n<p>I believe 5.0 is a huge step forward for the platform. The journey is not without its issues, and there is much work to do, but WordPress needed and continues to need big changes and advancements to maintain its position at the top of the content management food chain.</p>\n<p>People are using WordPress for all sorts of things, whether traditional publishing, eCommerce, application frameworks, and much more. I’m excited to see what Gutenberg brings to further these applications. Strictly as an editor, it’s far from perfect, but it’s an important step in the right direction.</p>\n<h2>Get familiar with WordPress 5.0</h2>\n<p>Here are some links to places to learn more about the new editing experience and WordPress 5.0.</p>\n<ul>\n<li><a href=\"https://wordpress.org/news/2018/12/bebo/\">WordPress 5.0 release post</a></li>\n<li><a href=\"https://wordpress.org/gutenberg/handbook/\">Gutenberg designer and developer handbook</a></li>\n<li><a href=\"https://wordpress.org/gutenberg/\">WordPress.org/Gutenberg</a> teaser, where you can use it live.</li>\n<li><a href=\"https://make.wordpress.org/core/2018/12/06/wordpress-5-0-field-guide/\">WordPress 5.0 Field Guide</a></li>\n<li>Gutenberg <a href=\"https://github.com/WordPress/gutenberg\">on GitHub</a> (This will be deprecated but offers a nice history.)</li>\n<li><a href=\"https://make.wordpress.org/core/2018/12/06/the-rest-api-in-wordpress-5-0/\">Changes to the REST API</a></li>\n<li><a href=\"https://make.wordpress.org/core/2018/12/06/media-5-0-guide/\">Media in 5.0</a></li>\n<li>The <a href=\"https://make.wordpress.org/core/2018/10/16/introducing-twenty-nineteen/\">Twenty Nineteen</a> default theme and Gutenberg support <a href=\"https://make.wordpress.org/core/2018/12/06/block-editor-support-in-existing-default-themes/\">in other default themes</a>.</li>\n</ul>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Dec 2018 17:31:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WPWeekly Episode 340 – Twas the Night Before 5.0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=86219&preview=true&preview_id=86219\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wptavern.com/wpweekly-episode-340-twas-the-night-before-5-0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1802:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by Matt Mullenweg, co-creator of the WordPress project. We discussed a number of topics that have been making the rounds across the community such as:</p>\n<ul>\n<li>The WordPress 5.0 release strategy and how it will evolve once it&#8217;s released.</li>\n<li>Whether or not Gutenberg is ready and what ready means.</li>\n<li>Having Automatticians in project leadership roles and what roles WordPress core contributors can or will have going forward.</li>\n<li>ClassicPress, Publicious, and other forks.</li>\n<li>Gutenberg and Accessibility.</li>\n<li>Communication, feedback mechanisms, and trying to make sure everybody can participate in the conversation.</li>\n</ul>\n<p>We also talked about the long-term vision of Gutenberg. Near the end of the interview, Matt described some of the innovative things he&#8217;s seen built with the new editor.</p>\n<p>To round out the show, we sent shoutouts to Alex Mills who <a href=\"https://alex.blog/2018/11/30/my-cancer-just-wont-give-up/\">recently discovered</a> that he will need to battle through leukemia again.</p>\n<h2>WPWeekly Meta:</h2>\n<p><strong>Next Episode:</strong> Thursday, December 13th 3:00 P.M. Eastern</p>\n<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>\n<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>\n<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>\n<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>\n<p><strong>Listen To Episode #340:</strong><br />\n</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Dec 2018 03:32:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"BuddyPress: BuddyPress 4.1.0 maintenance release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=282488\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://buddypress.org/2018/12/buddypress-4-1-0-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:332:\"<p>Immediately available is BuddyPress 4.1.0. This maintenance release fixes 3 bugs related to last week&#8217;s 4.0.0 release, and is a recommended upgrade for all BuddyPress installations.</p>\n<p>For complete details on the release, visit the <a href=\"https://codex.buddypress.org/releases/version-4-1-0/\">4.1.0 changelog</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2018 16:18:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Boone Gorges\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"Matt: Interview on Gutenberg and Future of WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48667\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://ma.tt/2018/12/interview-on-gutenberg-and-future-of-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:863:\"<p>Yesterday I was able to have a great conversation with Adam from WP Crafter, a popular Youtube channel with over five million views. Adam said it was his first interview but you can&#8217;t tell, we had an excellent conversation that covered Gutenberg, the 5.0 release, why WordPress has done well so far, and what&#8217;s coming in the future. If you&#8217;d like more context than text or tweets can give for what&#8217;s happening in WordPress today, check it out.</p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<p>Of course Friday and Saturday are <a href=\"https://2018.us.wordcamp.org\">WordCamp US</a>, which returns to Nashville this year. Everything will be live-streamed for free, including my State of the Word presentation on Saturday, you just need to <a href=\"https://2018.us.wordcamp.org/tickets/\">pick up a free streaming ticket</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2018 14:16:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: WordPress 5.0 Targeted for December 6, Prompting Widespread Outcry Ahead of WordCamp US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86065\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"https://wptavern.com/wordpress-5-0-targeted-for-december-6-prompting-widespread-outcry-ahead-of-wordcamp-us\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7290:\"<p>During last week&#8217;s core dev chat, Matt Mullenweg urged developers to consider WordPress 5.0 as &#8220;coming as soon as possible.&#8221; Nevertheless, his decision to set Thursday, December 6, for the <a href=\"https://make.wordpress.org/core/2018/12/04/new-5-0-target-date/\" rel=\"noopener\" target=\"_blank\">new release date</a> has taken many by surprise. </p>\n<p>Official feedback channels and social media erupted with largely negative feedback on the decision, as the new release date has 5.0 landing the day before WordCamp US begins. This is a travel day for many attending the conference. It also means both of the planned follow-up releases will be expected during the upcoming weeks when many have scheduled time off for major world holidays.</p>\n<p>Yoast CEO Joost de Valk, one of the most vocal critics of the 5.0 timelime, <a href=\"https://twitter.com/yoast/status/1069880401055895553\" rel=\"noopener\" target=\"_blank\">posted a public message of dissent</a> that resonated with many on Twitter:</p>\n<blockquote><p>We vehemently disagree with the decision to release WordPress 5.0 on December 6th, and think it&#8217;s irresponsible and disrespectful towards the community. </p>\n<p>However, we&#8217;re now going to try and support the community as well as possible and we hope to show everyone that Gutenberg is indeed a huge step forward.</p></blockquote>\n<p>Although Gutenberg as a project has strong support from many large companies in the WordPress ecosystem, much of the current uproar is rooted in a communication published in early October that indicated <a href=\"https://make.wordpress.org/core/2018/10/03/proposed-wordpress-5-0-scope-and-schedule/\" rel=\"noopener\" target=\"_blank\">5.0 would be pushed to January</a> if it missed the first set of planned release dates:</p>\n<blockquote><p>We know there is a chance that 5.0 will need additional time, so these dates can slip by up to 8 days if needed. If additional time beyond that is required, we will instead aim for the following dates:</p>\n<p>Secondary RC 1: January 8, 2019</p>\n<p>Secondary Release: January 22, 2019</p>\n<p>Should we need to switch to the secondary dates, this will be communicated as soon as we’re aware.</p></blockquote>\n<p>Companies made plans based on this schedule, but after those dates passed Mullenweg was unwilling to commit to honoring the previous communication. The plan from the outset may have been to &#8220;play it by ear&#8221; and incorporate new information as it became available, but the developer community had been counting on the published deadlines to be definitive.</p>\n<p>&#8220;This decision was made in disregard to earlier specific timelines and promises, and does not take the realities on the ground into account,&#8221; Morten Rand-Hendricksen <a href=\"https://twitter.com/mor10/status/1070013237205204992?s=19\" rel=\"noopener\" target=\"_blank\">said</a>. &#8220;I agree with @yoast it is both irresponsible and disrespectful.&#8221;</p>\n<p>Although reactions on Twitter run the gamut from unbridled optimism to full on outrage, many of those commenting on the schedule have fallen into resignation, convinced that community feedback never really mattered when it came to scheduling the release.</p>\n<p>Mullenweg&#8217;s rationale behind announcing the release date with three days notice is that Gutenberg and/or the Classic Editor are already active on more than 1.3 million sites. Users do not have to upgrade to WordPress 5.0 until they are ready. If they opt for the Classic Editor, the editing experience &#8220;will be indistinguishable from 4.9.8.&#8221; </p>\n<p>Users who are informed enough to make this choice will be well-prepared when they see that 5.0 update in their dashboards. However, one of the chief concerns is that millions of WordPress users will update without testing. Plugin developers are scrambling to ship compatibility updates and support staff will need to be on hand to help users navigate any incompatibilities or bugs in the new editing experience. Hundreds of WordPress professionals will be traveling to WordCamp US when 5.0 is expected to ship, which poses challenges for supporting users who experience problems with the update.</p>\n<p>&#8220;I do not think the attendees of WCUS are more important than much larger portion of the WordPress community who does not (and cannot) attend, and there are numerous ways to deal with 5.0 before or after the 6th if that particular day is inconvenient for someone, regardless of the reason,&#8221; Mullenweg <a href=\"https://make.wordpress.org/core/2018/12/04/new-5-0-target-date/#comment-34686\" rel=\"noopener\" target=\"_blank\">said</a> in response to comments regarding the date conflicting with travel plans.</p>\n<p>The release date <a href=\"https://make.wordpress.org/core/2018/12/04/new-5-0-target-date/\" rel=\"noopener\" target=\"_blank\">announcement</a> has well over 100 comments from frustrated contributors and developers expressing concerns, and Mullenweg has been responsive in the comments. He has recently <a href=\"https://wptavern.com/mullenweg-ramps-up-communication-ahead-of-wordpress-5-0-release-rc2-now-available\" rel=\"noopener\" target=\"_blank\">ramped up communication</a> ahead of the release, regularly attending core dev chats, adding dedicated office hours to connect with the community one-on-one, and answering some of the most pressing Gutenberg questions on his blog in a lengthy but inspiring <a href=\"https://ma.tt/2018/11/a-gutenberg-faq/\" rel=\"noopener\" target=\"_blank\">FAQ post</a>. </p>\n<p>Despite these communication efforts, contributors who are not employed by Automattic have said they feel this release has been plagued by a lack of transparency regarding decision-making. Many WordPress core committers, core contributors, and former release leads have <a href=\"https://wptavern.com/wordpress-5-0-rc-expected-on-u-s-thanksgiving-holiday-despite-last-minute-pushback-from-contributors\" rel=\"noopener\" target=\"_blank\">pushed back</a> on releasing before January to no avail. Their concerns and disappointments during the process hang like a dark cloud over what should be an exciting time for the future of WordPress.</p>\n<p>&#8220;No matter how bad the process around WordPress 5.0 might have been, finally setting a release date was the only right step following the RCs,&#8221; WordPress core developer Dominik Schilling <a href=\"https://twitter.com/ocean90/status/1069874387870978048\" rel=\"noopener\" target=\"_blank\">said</a>. &#8220;Let&#8217;s see if it&#8217;s also the beginning for doing it better to get back on releases which everyone will love.&#8221;</p>\n<p><a href=\"https://gemservers.com/\" rel=\"noopener\" target=\"_blank\">John Teague</a>, who runs an 11-person operation, managing 210 enterprise hosting clients, summarized how many are feeling ahead of WordPress 5.0 shipping out this week.</p>\n<p>&#8220;I so want to be supportive of this release,&#8221; Teague said. &#8220;But between the top down, heavily Automattic managed process, poor release communication, super short RC2, RC3, punting on accessibility, and now this two-day notice to 5.0 release &#8211; it reminds me of an old Air Force saying when instructors sent barely trained pilots up for their first solo:  </p>\n<p>&#8216;Send em up and let God grade em.\'&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2018 07:37:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"HeroPress: WordPress made me walk 700km to Berlin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2658\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"https://heropress.com/essays/wordpress-made-me-walk-700km-to-berlin/#utm_source=rss&utm_medium=rss&utm_campaign=wordpress-made-me-walk-700km-to-berlin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9479:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2018/12/120518-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: Nothing happens in your comfort zone. Go beyond and find the magic.\" /><p>Since the year 2000 I was employed at a big IT hardware/software/services firm. After about 9 years I was not feeling quite happy about how things went. Let’s say that the plans the company had with me did not really line up with the monthly reward. So, I quit and started my own company, <a href=\"https://nostromo.nl/\">nostromo.nl</a> in June 2009 (<a href=\"https://twitter.com/mbootsman/status/2090725144\">Tweetproof</a>). The goal was to serve customers by designing/developing and maintaining websites.</p>\n<h3>A new beginning</h3>\n<p>Now the challenge begins. Where do I start, who do I call? “Hello, do you need a new website? I just started my company and I can help you”. Why would I be the right person to help this company with their new website? The first thing I learned was to be sure of myself. I know what I can do and the customer needs help, probably because they are not so skillful in building websites.</p>\n<p>After a month I was talking with a potential customer, my first one (!), and I got the quotation signed. I was going to build my own CMS, and I soon realized (the hard way) that was not the way to go. I had to do a CMS comparison and WordPress won.</p>\n<h3>Here comes WordPress</h3>\n<p>The ease of use and the extensive documentation for developers convinced me. After having built numerous websites, and offering maintenance services to customers, I wanted  to know who the people were that built WordPress. Why? Well, because I was using free software and I was making money with it. That didn’t feel right, I wanted to give something back.</p>\n<p>Browsing support forums and IRC (that&#8217;s something like Slack, but without the GIFs) I quickly became aware of the WordPress community and felt I wanted to get to know these great people.</p>\n<h3>WordCamp &#8211; how it changed me</h3>\n<p>It was 2010 when I learned about a thing called WordCamp in The Netherlands. The entrance ticket was cheap and I could attend talks by inspiring people. On November 6th 2010, I was waiting in line at the registration desk. It was my turn, and someone from behind the desk said; “Hey, nostromo!”. It was <a href=\"https://twitter.com/remkusdevries\">Remkus de Vries</a>, he recognized me from my avatar on Twitter and those two words made me feel welcome immediately. This moment I remember very vividly and it marks the point where my enthusiasm for the WordPress community was sparked to life.</p>\n<h3>I volunteer &#8211; a lot</h3>\n<p>Giving back to the community got defined. Translating, helping out in the Dutch official WordPress support forum, organizing meetups/WordCamps (The Netherlands, the first WordCamp Europe, and WordCamp Rotterdam) and helping others join and be active in the WordPress community. These were some of the things I did, and yes, I had to push the brake on voluntary jobs sometimes, because I also needed to be productive and profitable in my business. Since that first WordCamp I have met amazing, inspiring and skillful people (in random order). I haven’t met new people, I met new friends.</p>\n<h3>Volunteering &#8211; taking it to the next level</h3>\n<p>It was June 4th 2018 when I got a weird idea. Yeah, that sometimes happens. Impulsive as I am, I tweeted it:</p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">I&#039;m thinking about walking to the next <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a>. Needs some planning of course, and funding / sponsoring. Will launch a separate website after this years edition.</p>\n<p>&mdash; <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f6b6-1f3fc-200d-2642-fe0f.png\" alt=\"🚶🏼‍♂️\" class=\"wp-smiley\" /> Marcel Bootsman (@mbootsman) <a href=\"https://twitter.com/mbootsman/status/1003666255994376192?ref_src=twsrc%5Etfw\">June 4, 2018</a></p></blockquote>\n<p></p>\n<p>Little did I know, there was a body part that had a big objection. While planning to go to Belgrade for WordCamp Europe 2018 this happened:</p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">Good morning. Going to see doctor later, I have a sore knee and walking is merely possible. Great timing, body&#8230; <a href=\"https://twitter.com/hashtag/WCEU?src=hash&ref_src=twsrc%5Etfw\">#WCEU</a></p>\n<p>&mdash; <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f6b6-1f3fc-200d-2642-fe0f.png\" alt=\"🚶🏼‍♂️\" class=\"wp-smiley\" /> Marcel Bootsman (@mbootsman) <a href=\"https://twitter.com/mbootsman/status/1006400794617352192?ref_src=twsrc%5Etfw\">June 12, 2018</a></p></blockquote>\n<p></p>\n<p>And yes, I had to cancel our trip (my wife was going to join) and ended up laying in bed for about a week with an inflamed knee. I received antibiotics from the doctor and gladly the pain and inflammation disappeared. That aside, at the end of WCEU 2018 it was announced that WCEU 2019 was going to be in Berlin. I was happy, since that’s really close (about 700 km) to where I live.</p>\n<p>Currently I am training, I’ve planned my route and I am looking for places to sleep in Germany. Please see this website <a href=\"http://walktowc.eu\">walktowc.eu</a> for more information. Since this hike is probably going to gain some attention in the community, I had another idea. Why not use this as a means to raise money, for a good cause. Walking 700 km in about 30 days is a challenge, and if I can get enough attention, raising money might work out. Now I just had to find a good cause to raise money for&#8230;</p>\n<h3>Raising funds for DonateWC</h3>\n<p>I have known <a href=\"https://twitter.com/motherofcode\">Ines van Essen</a> for a few years now and in September 2017 she started a thing called <a href=\"https://donatewc.org/\">DonateWC</a>. After a successful initial funding campaign they sent their first recipient to <a href=\"https://donatewc.org/sponsorship-recipients/were-sending-a-speaker-to-wordcamp-cape-town/\">WordCamp Capetown</a> in October 2017. Seeing this made me believe this is another sign of how friendly and supporting the WordPress community is, to make sure that people are able to attend WordCamps, while they do not have the financial means to do so. The community supports community members, and that’s the reason why I chose DonateWC as the cause I’m going to raise funds for. And as a side effect also raise awareness of the existence of DonateWC.</p>\n<h3>My message to you</h3>\n<p>Don’t feel obliged to do things you don’t like.</p>\n<p>Do things you like.</p>\n<p>Start volunteering.</p>\n<p>Build your network.</p>\n<p>Enjoy the community.</p>\n<p>Step (or walk) out of your comfort zone.</p>\n<blockquote class=\"twitter-tweet\">\n<p lang=\"en\" dir=\"ltr\">Nothing happens in your comfort zone. Go beyond and find the magic. <a href=\"https://t.co/Rm4zDtT5JL\">pic.twitter.com/Rm4zDtT5JL</a></p>\n<p>&mdash; <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f6b6-1f3fc-200d-2642-fe0f.png\" alt=\"🚶🏼‍♂️\" class=\"wp-smiley\" /> Marcel Bootsman (@mbootsman) <a href=\"https://twitter.com/mbootsman/status/971276691447386120?ref_src=twsrc%5Etfw\">March 7, 2018</a></p></blockquote>\n<p></p>\n<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: WordPress made me walk 700km to Berlin\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=WordPress%20made%20me%20walk%20700km%20to%20Berlin&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-made-me-walk-700km-to-berlin%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: WordPress made me walk 700km to Berlin\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-made-me-walk-700km-to-berlin%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-made-me-walk-700km-to-berlin%2F&title=WordPress+made+me+walk+700km+to+Berlin\" rel=\"nofollow\" target=\"_blank\" title=\"Share: WordPress made me walk 700km to Berlin\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/wordpress-made-me-walk-700km-to-berlin/&media=https://heropress.com/wp-content/uploads/2018/12/120518-150x150.jpg&description=WordPress made me walk 700km to Berlin\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: WordPress made me walk 700km to Berlin\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/wordpress-made-me-walk-700km-to-berlin/\" title=\"WordPress made me walk 700km to Berlin\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/wordpress-made-me-walk-700km-to-berlin/\">WordPress made me walk 700km to Berlin</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2018 07:00:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Marcel Bootsman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Dev Blog: WordPress 5.0 RC3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6322\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/2018/12/wordpress-5-0-rc3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2755:\"<p>The third release candidate for WordPress 5.0 is now available!</p>\n\n\n\n<p><strong>WordPress 5.0 will be released on </strong><a href=\"https://make.wordpress.org/core/2018/12/04/new-5-0-target-date/\"><strong>December 6, 2018</strong></a>. This is a big release and needs&nbsp;<em>your</em>&nbsp;help—if you haven’t tried 5.0 yet, now is the time!</p>\n\n\n\n<p>To test WordPress 5.0, you can use the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-RC3.zip\">download the release candidate here</a>&nbsp;(zip).</p>\n\n\n\n<p>For details about what to expect in WordPress 5.0, please see the&nbsp;<a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-release-candidate/\">first release candidate post</a>.</p>\n\n\n\n<p>This release candidate includes a fix for some scripts not loading on subdirectory installs (<a href=\"https://core.trac.wordpress.org/ticket/45469\">#45469</a>), and user locale settings not being loaded in the block editor (<a href=\"https://core.trac.wordpress.org/ticket/45465\">#45465</a>). Twenty Nineteen has also had a couple of minor tweaks.</p>\n\n\n\n<h2>Plugin and Theme Developers</h2>\n\n\n\n<p>Please test your plugins and themes against WordPress 5.0 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme to 5.0. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>&nbsp;so we can figure those out before the final release. An in-depth field guide to developer-focused changes is coming soon on the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>. In the meantime, you can review the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5.0+dev-notes/\">developer notes for 5.0</a>.</p>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p>If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<p><em>WordPress Five Point Oh<br />Is just a few days away!<br />Nearly party time!</em> <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Dec 2018 07:07:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: New Block Gallery Plugin Offers a Suite of Photo Gallery Blocks for Gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=85195\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://wptavern.com/new-block-gallery-plugin-offers-a-suite-of-photo-gallery-blocks-for-gutenberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3116:\"<p>The new Gutenberg editor has basic support for galleries with a few nice features, such as the ability to set the number of columns and automatically crop thumbnails for a more uniform appearance. If you need more control over your galleries, Rich Tabor&#8217;s <a href=\"https://wordpress.org/plugins/block-gallery/\" rel=\"noopener\" target=\"_blank\">Block Gallery</a> plugin is currently the best option made specifically for use with Gutenberg and WordPress 5.0+. It offers a suite of photo gallery blocks with minimal, tasteful styling that fits unobtrusively into virtually any site design. </p>\n<p>Block Gallery currently offers three different blocks, including masonry, fullscreen stacked, and a carousel slider. Each block has its own settings that offer more customization for the specific gallery type.</p>\n<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2018/10/Screen-Shot-2018-12-03-at-3.19.46-PM.png?ssl=1\"><img /></a></p>\n<p>The plugin also makes use of Gutenberg&#8217;s block transform utility to allow users to seamlessly transform galleries from one style to another with one click, as demonstrated in the video below.</p>\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>A demo of the new <a href=\"https://wordpress.org/plugins/block-gallery/\">Block Gallery WordPress Plugin</a>\n<p>&#8220;I built the Block Gallery plugin originally as a proving ground for exploring how my portfolio WordPress themes at ThemeBeans will interface with Gutenberg,&#8221; <a href=\"https://themebeans.com/\" rel=\"noopener\" target=\"_blank\">ThemeBeans</a> founder Rich Tabor said. &#8220;I do not particularly like the idea of disabling the block editor on portfolio custom post types, so I wanted to find a clever way for folks to use different sorts of galleries to showcase their art, illustrations, photos, etc. Block Gallery was born out of that exploration.&#8221;  </p>\n<p>Tabor said that although the core gallery block is much more robust than the classic editor’s gallery system, he wanted to give users more flexibility in how they display media. His favorite feature of the project is the ability to morph gallery blocks into different types.</p>\n<p>&#8220;That means every image, settings, display option, and color selection are each migrated instantly — if a user swaps out a selected gallery for a different type,&#8221; Tabor said. &#8220;For instance, folks can morph from a masonry gallery to a carousel slider in a single click, without having to re-upload/assign images or select any options. It’s all done behind the scenes, automagically.&#8221;</p>\n<p>Tabor&#8217;s Block Gallery plugin is a major leap forward for galleries in terms of usability. It offers a beautiful implementation of features that would have been difficult to imagine before the block editor. <a href=\"https://wordpress.org/plugins/block-gallery/\" rel=\"noopener\" target=\"_blank\">Block Gallery</a> currently has more than 400 active installs after a little more than month in the official directory. Watch for that number to jump as more people begin using the new editor when WordPress 5.0 is released. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Dec 2018 22:29:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Dev Blog: The Month in WordPress: November 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6318\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2018/12/the-month-in-wordpress-november-2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6607:\"<p>WordPress 5.0 is almost ready for release, including an all-new content editing experience. Volunteers all across the project are gearing up for the launch and making sure everything is ready. Read on to find out what&#8217;s been happening and how you can get involved.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>WordPress 5.0 Close to Launch</h2>\n\n\n\n<p>The release date for WordPress 5.0 has not yet been set, but the second release candidate (RC) <a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-rc2/\">is now available</a>. The final release date will be determined based on feedback and testing of this RC. The Core development team has been posting <a href=\"https://make.wordpress.org/core/2018/12/03/5-0-gutenberg-status-update-dec-3/\">daily updates</a> on the progress of their work on v5.0, with the number of open issues for this release decreasing every day.<br /></p>\n\n\n\n<p>The primary feature of this release is <a href=\"https://wordpress.org/gutenberg/\">the new editor</a> that will become the default WordPress experience going forward. A number of people have been seeking more direct feedback from the release leads about the progress of this release, which <a href=\"https://profiles.wordpress.org/matt/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>matt</a> has facilitated by hosting <a href=\"https://make.wordpress.org/core/2018/11/29/gutenberg-5-0-listening-office-hours/\">one-to-one discussions</a> with anyone in the community who wanted to talk with him about it. He has also published <a href=\"https://ma.tt/2018/11/a-gutenberg-faq/\">an extended FAQ</a> covering many of the questions people have been asking.<br /></p>\n\n\n\n<p>Alongside the development of the new editor, the Mobile team has been working hard to bring the WordPress mobile apps up to speed. They plan to make a beta version available <a href=\"https://make.wordpress.org/mobile/2018/11/15/gutenberg-in-the-apps-what-to-expect/\">in February 2019</a>.<br /></p>\n\n\n\n<p>Want to get involved in developing WordPress Core in 5.0 and beyond? Follow <a href=\"https://make.wordpress.org/core\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<h2>New WordPress Support Platform Goes Live</h2>\n\n\n\n<p>WordPress user documentation has long been hosted on the <a href=\"https://codex.wordpress.org/\">WordPress Codex</a>, but for the past couple of years an ambitious project has been underway to move that content to a freshly-built WordPress-based platform. This project, named “HelpHub,” is now live and <a href=\"https://wordpress.org/support/\">the official home of WordPress Support</a>.<br /></p>\n\n\n\n<p>There is still plenty of content that needs to be migrated from the Codex to HelpHub, but the initial move is done and the platform is ready to have all WordPress’ user documentation moved across. HelpHub will be the first place for support, encouraging users to find solutions for themselves before posting in the <a href=\"https://wordpress.org/support/forums/\">forums</a>.<br /></p>\n\n\n\n<p>Want to get involved in populating HelpHub with content, or with its future development? Follow <a href=\"https://make.wordpress.org/docs/\">the Documentation team blog</a> and join the #docs channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<h2>Spanish WordPress Community Pushes Translations Forward</h2>\n\n\n\n<p>The WordPress community in Spain has been hard at work making sure as much of the WordPress project as possible is available in Spanish. <a href=\"https://es.wordpress.org/2018/11/07/logros-equipo-traducciones-wordpress-espana/\">They have recently translated more of the project than ever</a> — including WordPress Core, WordPress.org, the mobile apps and the top 120 plugins in the Directory.<br /></p>\n\n\n\n<p>This achievement has largely been possible due to the fact that <a href=\"https://make.wordpress.org/polyglots/teams/?locale=es_ES\">the Spanish translation team</a> has over 2,500 individuals contributing to it, making it the largest translation team across the whole project. <br /></p>\n\n\n\n<p>Want to get involved in translating WordPress into your local language? You can <a href=\"https://translate.wordpress.org/\">jump straight into translations</a>, follow <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team blog</a> and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<h2>Further Reading:</h2>\n\n\n\n<ul><li>All volunteer teams have checked in with their <a href=\"https://wordpress.org/news/2018/11/quarterly-updates-q3-2018/\">latest quarterly updates</a>.</li><li>The WordPress Support Team <a href=\"https://make.wordpress.org/support/2018/11/new-volunteer-orientation-for-wp-support-contributors-dec-9/\">is hosting an orientation</a> for new Support volunteers on December 9.</li><li><a href=\"https://2018.us.wordcamp.org/tickets/\">Tickets are now available</a> to watch the WordCamp US livestream for free.</li><li>WordPress Core <a href=\"https://core.trac.wordpress.org/ticket/45287\">has switched to a WP-CLI command</a> for generating localization files.</li><li>WordPress Coding Standards v1.2.0 <a href=\"https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/releases/tag/1.2.0\">has been released</a> with some really useful improvements.</li><li>The first ever <a href=\"https://2019.nordic.wordcamp.org/\">WordCamp Nordic</a> is taking place on March 7-8, 2019 with ticket sales now open.</li><li>The WordCamp Incubator program is going very well this year — <a href=\"https://make.wordpress.org/community/2018/11/27/wordcamp-incubator-2018-update-thread-november-edition/\">you can see the latest updates here</a>.</li><li>The Mobile Team is looking for testers for the upcoming v11.3 release of the WordPress mobile apps on <a href=\"https://make.wordpress.org/mobile/2018/11/21/call-for-testing-wordpress-for-android-11-3/\">Android</a> and <a href=\"https://make.wordpress.org/mobile/2018/11/21/call-for-testing-wordpress-for-ios-11-3/\">iOS</a>.</li><li>The WordCamp Europe team is looking for local communities to <a href=\"https://2019.europe.wordcamp.org/2018/11/29/call-for-host-city/\">apply to be the host city</a> for the 2020 event.</li></ul>\n\n\n\n<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em><br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Dec 2018 17:43:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: WordCamp Europe Opens the Call for Host City 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86110\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wptavern.com/wordcamp-europe-opens-the-call-for-host-city-2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2379:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/11/wordcamp-eurpoe-2019.png?ssl=1\"><img /></a></p>\n<p>WordCamp Europe has opened the <a href=\"https://2019.europe.wordcamp.org/2018/11/29/call-for-host-city/\" rel=\"noopener\" target=\"_blank\">call for a host city for 2020</a>. Previous editions of the event have been held in Leiden, Sofia, Seville, Vienna, Paris, and Belgrade, and the next on deck is Berlin in 2019. Organizers are always working ahead for an event this size. In fact, the team plans together for the better part of a year before attendees arrive for the three-day event. The upcoming WCEU is currently being planned by a team of 66 organizers from 15 countries. </p>\n<p>Teams applying to host WordCamp Europe are required to have organized at least one or more successful WordCamps in a European city, with at least one recent one held in 2017 or 2018. The core organizing team will work with all applicants in the open to help them prepare the best applications possible, as detailed in the announcement:  </p>\n<blockquote><p>To guarantee total transparency during the process, all applicants receive the same help in the appropriate public channel of the WCEU Slack workspace. No question is considered or answered in a private message.</p></blockquote>\n<p>Three weekends in June 2020 are available to applicants as potential dates. Teams interested to apply are encouraged to begin filling out the <a href=\"https://docs.google.com/forms/d/e/1FAIpQLSfPd5InsSfaGXA1zRu_PJ435AGXXPlUYMuCqCBkEOKRNSrd7w/viewform\" rel=\"noopener\" target=\"_blank\">7-page survey</a> (which can be started and completed as information becomes available). It includes questions about the local community, previous WordCamps, possible venue(s), cost of living in the city, and other data that will be important to the selection committee. </p>\n<p>A preliminary online AMA session will be held December 13, 2018, to assist teams in answering questions about the application process. The deadline to apply to host the event is February 28, 2019. Applicants will receive a decision by March 15, 2019, and the final selection will be announced during the closing remarks in Berlin next June. Check out the call for host cities <a href=\"https://2019.europe.wordcamp.org/2018/11/29/call-for-host-city/\" rel=\"noopener\" target=\"_blank\">announcement</a> for more information.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Dec 2018 16:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Mullenweg Ramps Up Communication Ahead of WordPress 5.0 Release, RC2 Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://wptavern.com/mullenweg-ramps-up-communication-ahead-of-wordpress-5-0-release-rc2-now-available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5209:\"<p><a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-rc2/\" rel=\"noopener\" target=\"_blank\">WordPress 5.0 RC2</a> was released today with 15 notable updates, including improvements to block preview styling, browser-specific bug fixes, and other changes. RC2 was released simultaneously with <a href=\"https://make.wordpress.org/core/2018/11/30/whats-new-in-gutenberg-30th-november/\" rel=\"noopener\" target=\"_blank\">Gutenberg version 4.6</a>. </p>\n<p>The official release date for WordPress 5.0 has not yet been announced, because it depends on feedback from RC2 testing. Contributors&#8217; uneasiness with not having an official release date seemed to reach a critical tipping point during this week&#8217;s WordPress dev chat, as many participants pressured Matt Mullenweg, who is leading the release, to give more information on when they can expect 5.0. </p>\n<p>&#8220;It is very important that we have a release date to aim for,&#8221; ACF founder Elliot Condon said. &#8220;I’m finding the current &#8216;waiting game&#8217; quite stressful, and I suspect a few other developers will share the same feeling.&#8221;</p>\n<p>Tensions were high as contributors cited various reasons for wanting a date, including companies needing support staff on hand, upcoming holidays, documentation planning, and the importance of user trust.</p>\n<p>&#8220;We&#8217;re determining the release date based on the open issues,&#8221; Mullenweg said. &#8220;Please consider it as coming as soon as possible, when everything is resolved.&#8221;</p>\n<p>&#8220;I hope it&#8217;s clear we&#8217;re trying to get this out as soon as possible, but don&#8217;t yet have enough data to announce an official date. As mentioned last week we have done a number of December releases in the past, and may this time, but don&#8217;t have enough data to announce a new date yet.&#8221;</p>\n<p>Mullenweg also urged dev chat attendees to keep in mind that any site administrators can install the Classic Editor plugin to keep the current editing experience, regardless of the 5.0 release date. He said the date will be announced via a P2 post, not during a dev chat.</p>\n<p>&#8220;If you want to know what to plan on, please don&#8217;t hold anything back based on expected dates, please test or deploy the RCs, that&#8217;s what they&#8217;re for,&#8221; Mullenweg said. </p>\n<p>In the meantime, Mullenweg is spending the weekend taking questions from the community during <a href=\"https://make.wordpress.org/core/2018/11/29/gutenberg-5-0-listening-office-hours/\" rel=\"noopener\" target=\"_blank\">24 office hours slots</a>. He also published a lengthy post titled &#8220;<a href=\"https://ma.tt/2018/11/a-gutenberg-faq/\" rel=\"noopener\" target=\"_blank\">WordPress 5.0: A Gutenberg FAQ</a>,&#8221; which reaffirms WordPress&#8217; mission in the context of Gutenberg. It answers questions like &#8220;Why do we need Gutenberg at all?&#8221; and &#8220;Why blocks?&#8221;</p>\n<p>&#8220;I knew we would be taking a big leap,&#8221; Mullenweg said. &#8220;But it’s a leap we need to take, and I think the end result is going to open up many new opportunities for everyone in the ecosystem, and for those being introduced to WordPress for the first time. It brings us closer to our mission of democratizing publishing for everyone.&#8221;</p>\n<p>The stats Mullenweg cited about previously having 9 major WordPress releases in December (34% of all releases in the last decade) indicate that a December release may still be on the table. His post addresses the perceived urgency behind getting Gutenberg out the door and into the hands of users. In evaluating WordPress 5.0&#8217;s readiness, he said it&#8217;s important to differentiate between the code being ready and the community being ready.</p>\n<p>&#8220;In the recent debate over Gutenberg readiness, I think it’s important to understand the difference between Gutenberg being ready code-wise (it is now), and whether the entire community is ready for Gutenberg,&#8221; Mullenweg said.</p>\n<p>&#8220;It will take some time — we’ve had 15 years to polish and perfect core, after all — but the global WordPress community has some of the world’s most talented contributors and we can make it as good as we want to make it.&#8221;</p>\n<p>The post also offers a preview of where Gutenberg is going in the next site customization phase and how it will change the way users build their sites.</p>\n<p>&#8220;The Editor is just the start,&#8221; he said. &#8220;In upcoming phases blocks will become a fundamental part of entire site templates and designs. It’s currently a struggle to use the Customizer and figure out how to edit sections like menus, headers, and footers. With blocks, people will be able to edit and manipulate everything on their site without having to understand where WordPress hides everything behind the scenes.&#8221;</p>\n<p>Mullenweg said he plans to talk more about the next phases following site customization during the State of the Word address at WordCamp US. If you have questions about Gutenberg and where it&#8217;s headed, the comments are open on his <a href=\"https://ma.tt/2018/11/a-gutenberg-faq/\" rel=\"noopener\" target=\"_blank\">post</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 01 Dec 2018 03:15:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Let Us Know If You’re Hosting a WordCamp US Watch Party\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86150\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/let-us-know-if-youre-hosting-a-wordcamp-us-watch-party\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:505:\"<p>WordCamp US is next weekend and if you&#8217;re unable to attend, you can watch from home via the <a href=\"https://wptavern.com/wordcamp-us-2018-livestream-tickets-now-available\">free livestream</a>. However, some WordPress meetup groups host watch parties. These parties generally include food, beverages, and a large projection screen. </p>\n\n\n\n<p>If you&#8217;re hosting one of these parties, please let us know about it in the comments. Tell us the location and what attendees can expect. <br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 01 Dec 2018 01:11:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Dev Blog: WordPress 5.0 RC2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6287\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/2018/11/wordpress-5-0-rc2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3298:\"<p>The second release candidate for WordPress 5.0 is now available!</p>\n\n\n\n<p>This is an important milestone, as we near the release of WordPress 5.0. A final release date will be announced soon, based on feedback from this release candidate. Things are appearing very stable and we hope to announce a date soon. This is a big release and needs <em>your</em> help—if you haven’t tried 5.0 yet, now is the time! </p>\n\n\n\n<p>To test WordPress 5.0, you can use the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin or you can&nbsp;<a href=\"https://wordpress.org/wordpress-5.0-RC2.zip\">download the release candidate here</a>&nbsp;(zip).</p>\n\n\n\n<p>For details about what to expect in WordPress 5.0, please see the <a href=\"https://wordpress.org/news/2018/11/wordpress-5-0-release-candidate/\">previous release candidate post</a>.</p>\n\n\n\n<h2>Significant changes</h2>\n\n\n\n<ul><li>We stopped rendering&nbsp;<em>AdminNotices</em>&nbsp;compatibility component, as this previous attempt at backward compatibility was bringing in numerous incompatible banners and notices from plugins.</li><li>An update to the parser to better deal with malformed HTML that could cause a loop. We&#8217;re only aware of this in the wild being triggered once in the <a href=\"https://gutenstats.blog/\">over a million posts</a> made with Gutenberg, but it caused a loop so we wanted to fix for RC2.</li></ul>\n\n\n\n<h2>Cosmetic and minor changes in RC2</h2>\n\n\n\n<ul><li>Accessibility: Simplify sidebar tabs&nbsp;aria-labels.</li><li>Make the&nbsp;Image&nbsp;Link URL field readonly.</li><li>Internationalization: Merge&nbsp;similar text strings that differed only in capitalization.</li><li>CSS: Improve block preview&nbsp;styling.</li><li>CSS: Fix&nbsp;visual issues&nbsp;with&nbsp;Button&nbsp;block text wrap.</li><li>Fix&nbsp;getSelectedBlockClientId selector.</li><li>Fix&nbsp;Classic&nbsp;block&nbsp;not showing galleries on a grid.</li><li>Fix an issue where the block toolbar&nbsp;would cause an image to jump&nbsp;downwards when the&nbsp;<em>wide</em>&nbsp;or&nbsp;<em>full</em>&nbsp;alignments were activated.</li><li>Move editor specific styles&nbsp;from style.scss to editor.scss in&nbsp;Cover&nbsp;block.</li><li>Fix modals&nbsp;in Microsoft Edge browser.</li><li>Fix Microsoft IE11 focus loss&nbsp;after TinyMCE init.&nbsp;Add&nbsp;IE check.</li><li>Fix Microsoft IE11 input when mounting TinyMCE.</li><li>Change @package names&nbsp;to WordPress.</li></ul>\n\n\n\n<h2>How to Help</h2>\n\n\n\n<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;</p>\n\n\n\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</p>\n\n\n\n<hr class=\"wp-block-separator\" />\n\n\n\n<pre class=\"wp-block-verse\"><em>RC bittersweet.<br />We welcome in Gutenberg,<br />Vale Gutenbeard.</em></pre>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Nov 2018 23:16:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: Gutenberg Times to Host Live Q&amp;A with Gutenberg Leads on Friday, November 30\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=85908\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://wptavern.com/gutenberg-times-to-host-live-qa-with-gutenberg-leads-on-friday-november-30\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1224:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/11/creating-gutenberg-q-and-a.jpg?ssl=1\"><img /></a></p>\n<p>Birgit Pauli-Haack, curator of the <a href=\"https://gutenbergtimes.com/\" rel=\"noopener\" target=\"_blank\">Gutenberg Times</a> website, is hosting a Q&#038;A session with Gutenberg&#8217;s phase 1 design and development leads on Friday, November 30, at 2pm ET (19:00 UTC). Matias Ventura, Tammie Lister, and Joen Asmussen will join Pauli-Haack to discuss their journey &#8220;Creating Gutenberg&#8221; over the past two years.</p>\n<p>If you have any pressing questions about Gutenberg&#8217;s architecture, design, or the future of the project, this event is a good opportunity to speak to members of the team who have been building it full-time. The Q&#038;A is free to watch but attendees who want to participate with questions will need to <a href=\"https://zoom.us/webinar/register/6915430666443/WN_d_ejr1e0T0Se1YpyoU0Ojg\" rel=\"noopener\" target=\"_blank\">register</a>. There are 100 seats available. Pauli-Haack will also be live-streaming the session to the <a href=\"https://www.youtube.com/channel/UCSD3LG2kSHdr7llRSHaylxw\" rel=\"noopener\" target=\"_blank\">Gutenberg Times YouTube channel</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Nov 2018 00:48:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Matt: WordPress 5.0: A Gutenberg FAQ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=48628\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://ma.tt/2018/11/a-gutenberg-faq/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:18327:\"<p><em>Update: </em><a href=\"https://wordpress.org/news/2018/12/bebo/\"><em>On December 6th we released WordPress 5.0</em></a><em>. It was definitely the most controversial release in a while, but the usage and adoption metrics are looking similar to previous releases. I&#8217;m looking forward to continuing to iterate on the new block editor!</em></p>\n\n\n\n<p>We are nearing the release date for WordPress 5.0 and Gutenberg, one of the most important and exciting projects I’ve worked on in my <a href=\"https://ma.tt/2018/05/wordpress-at-15/\">15 years</a> with this community. <br /></p>\n\n\n\n<p>I knew we would be taking a big leap. But it’s a leap we need to take, and I think the end result is going to open up many new opportunities for everyone in the ecosystem, and for those being introduced to WordPress for the first time. It brings us closer to our mission of democratizing publishing for everyone.<br /></p>\n\n\n\n<p>I recently visited WordCamp Portland to talk about Gutenberg and WordPress 5.0, which will also include the new default theme <a href=\"https://make.wordpress.org/core/2018/10/16/introducing-twenty-nineteen/\">Twenty Nineteen</a>, which you’re seeing me test out on this very site. There were some great questions and testimonials about Gutenberg, so I’d urge you to watch the <a href=\"https://wordpress.tv/2018/11/08/matt-mullenweg-qa-at-wordcamp-portland-2018/\">full video</a> and <a href=\"https://wptavern.com/matt-mullenweg-addresses-controversies-surrounding-gutenberg-at-wordcamp-portland-qa\">read the WP Tavern recap</a>. I&#8217;ve also visited meetups, responded to review threads, kept an eye on support, and I&#8217;m in the middle of <a href=\"https://make.wordpress.org/core/2018/11/29/gutenberg-5-0-listening-office-hours/\">office hours with the core community</a>.<br /></p>\n\n\n\n<p>As we head toward the release date and <a href=\"https://2018.us.wordcamp.org/\">WordCamp US</a>, I&#8217;ve put many questions and answers into a Gutenberg FAQ below. For those who have other questions, I will be checking the comments here. <br /></p>\n\n\n\n<p>It’s an exciting time, and I’m thrilled to be working with y’all on this project. </p>\n\n\n\n<img />Not the ship of Theseus\n\n\n\n<h2>What is Gutenberg? </h2>\n\n\n\n<p>Gutenberg, for those who aren&#8217;t actively following along, is a brand new Editor for WordPress &#8212; contributors have been working on it since January 2017 and it&#8217;s one of the most significant changes to WordPress in years. It&#8217;s built on the idea of using &#8220;blocks&#8221; to write and design posts and pages. <br /></p>\n\n\n\n<p>This will serve as the foundation for future improvements to WordPress, including blocks as a way not just to design posts and pages, but also entire sites. <br /></p>\n\n\n\n<p>The overall goal is to simplify the first-time user experience of WordPress &#8212; for those who are writing, editing, publishing, and designing web pages. The editing experience is intended to give users a better visual representation of what their post or page will look like when they hit publish. As I wrote in <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">my post last year</a>, &#8220;Users will finally be able to build the sites they see in their imaginations.&#8221; <br /></p>\n\n\n\n<p>Matías Ventura, team lead for Gutenberg, <a href=\"https://matiasventura.com/post/gutenberg-or-the-ship-of-theseus/\">wrote an excellent post</a> about the vision for Gutenberg, saying, “It’s an attempt to improve how users interact with their content in a fundamentally visual way, while at the same time giving developers the tools to create more fulfilling experiences for the people they are helping.”</p>\n\n\n\n<h2>Why do we need Gutenberg at all? </h2>\n\n\n\n<p>For many of us already in the WordPress community, it can be easy to forget the learning curve that exists for people being introduced to WordPress for the first time. Customizing themes, adding shortcodes, editing widgets and menus &#8212; there’s an entire language that one must learn behind the scenes in order to make a site or a post look like you want it to look. <br /></p>\n\n\n\n<p>Over the past several years, JavaScript-based applications have created opportunities to simplify the user experience in consumer apps and software. Users’ expectations have changed, and the bar has been raised for simplicity. It is my deep belief that WordPress must evolve to improve and simplify its own user experience for first-time users. <br /></p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">What can you do in 137 lines in <a href=\"https://twitter.com/hashtag/Gutenberg?src=hash&ref_src=twsrc%5Etfw\">#Gutenberg</a>? <a href=\"https://t.co/zLINZGMXMe\">pic.twitter.com/zLINZGMXMe</a></p>&mdash; Dennis Snell (@dmsnell23) <a href=\"https://twitter.com/dmsnell23/status/1063126946350096389?ref_src=twsrc%5Etfw\">November 15, 2018</a></blockquote>\n</div>\n\n\n\n<h2>Why blocks? </h2>\n\n\n\n<p>The idea with blocks was to create a new common language across WordPress, a new way to connect users to plugins, and replace a number of older content types &#8212; things like shortcodes and widgets &#8212; that one had to be well-versed in the idiosyncrasies of WordPress to understand. <br /></p>\n\n\n\n<p>The block paradigm is not a new one &#8212; in fact many great plugins have already shown the promise of blocks with page design in WordPress. Elementor, one of the pioneers in this space, has now introduced <a href=\"https://elementor.com/blog/blocks-for-gutenberg/\">a new collection of Gutenberg blocks</a> to showcase what’s possible: <br /></p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n\n</div>\n\n\n\n<h2>Why change the Editor? </h2>\n\n\n\n<p>The Editor is where most of the action happens in WordPress’s daily use, and it was a place where we could polish and perfect the block experience in a contained environment. <br /></p>\n\n\n\n<p>Additionally, the classic Editor was built primarily for text &#8212; articles have become increasingly multimedia, with social media embeds, maps, contact forms, photo collages, videos, and GIFs. It was time for a design paradigm that allowed us to move past the messy patchwork of shortcodes and text. <br /></p>\n\n\n\n<p>The Editor is just the start. In upcoming phases blocks will become a fundamental part of entire site templates and designs. It’s currently a struggle to use the Customizer and figure out how to edit sections like menus, headers, and footers. With blocks, people will be able to edit and manipulate everything on their site without having to understand where WordPress hides everything behind the scenes. <br /></p>\n\n\n\n<h2>What does Automattic get out of this? </h2>\n\n\n\n<p>There have been posts recently asking questions about Automattic’s involvement in Gutenberg compared to other contributors and companies. There is no secret conspiracy here &#8212; as project lead I was able to enlist the help of dozens of my colleagues to contribute to this project, and I knew that a project of this size would require it. Automattic aims to have 5% of its people dedicated to WordPress community projects, which at its current size would be about 42 people full-time. The company is a bit behind that now (~35 full-time), and the company is growing a lot next year, so look for 10-15 additional people working on core and community projects.&nbsp;<br /></p>\n\n\n\n<p>In the end, Gutenberg is similar to many other open source projects &#8212; Automattic will benefit from it, but so will everyone else in the WordPress community (and even <a href=\"https://drupalgutenberg.org/\">the Drupal community</a>). It’s available for everyone under the GPL. If the goal was purely to benefit Automattic it would have been faster, easier, and created an advantage for Automattic to have Gutenberg just on WP.com. That wasn&#8217;t, and isn&#8217;t, the point.</p>\n\n\n\n<h2>Is Gutenberg ready? </h2>\n\n\n\n<p>Absolutely. Our original goal with Gutenberg was to get it on 100,000 sites to begin testing &#8212; it’s now already on <a href=\"https://gutenstats.blog/\">more than 1 million sites</a>, and it’s the fastest-growing plugin in WordPress history. There is a lot of user demand.<br /></p>\n\n\n\n<p>The goal was to both test Gutenberg on as many sites as possible before the 5.0 release, and also to encourage plugin developers to make sure their plugins and services will be ready. With everyone pitching in, we can make this the most <em>anti-climactic</em> release in WordPress history. &nbsp;<br /></p>\n\n\n\n<p>In the recent debate over Gutenberg readiness, I think it&#8217;s important to understand the difference between Gutenberg being ready code-wise (it is now), and whether the entire community is ready for Gutenberg.<br /></p>\n\n\n\n<p>It will take some time &#8212; we&#8217;ve had 15 years to polish and perfect core, after all &#8212; but the global WordPress community has some of the world&#8217;s most talented contributors and we can make it as good as we want to make it. <br /></p>\n\n\n\n<p>There is also a new opportunity to dramatically expand the WordPress contributor community to include more designers and JavaScript engineers. With JavaScript apps there are also new opportunities for designing documentation and support right on the page, so that help arrives right where you need it. <br /></p>\n\n\n\n<p>Someone described Gutenberg to me as “WordPress in 3D.” I like the sound of that. Blocks are like layers you can zoom in and out of. The question now is: What are we going to build with this new dimension? </p>\n\n\n\n<h2>Do I have to switch to Gutenberg when WordPress 5.0 is released? </h2>\n\n\n\n<p>Not at all. When it’s released, you get to choose what happens. You can install the <a href=\"https://wordpress.org/plugins/classic-editor/\">Classic Editor plugin</a> today and when 5.0 is released, nothing will change. We&#8217;ve commited to supporting and updating Classic Editor until 2022. If you’d like to <a href=\"https://wordpress.org/plugins/gutenberg/\">install Gutenberg early</a>, you can do that now too. The Classic Editor plugin has been available for 13 months now, and Gutenberg has been available for 18 months. Both have been heavily promoted since August 2018, and more than 1.3 million .org sites have opted-in already to either experience, so nothing will change for them when they update to 5.0.</p>\n\n\n\n<h2>How can I make sure I’m ready? </h2>\n\n\n\n<p>Before updating to 5.0, try out the <a href=\"https://wordpress.org/plugins/gutenberg/\">Gutenberg plugin</a> with your site to ensure it works with your existing plugins, and also to get comfortable with the new experience. Developers across the entire ecosystem are working hard to update their plugins, but your mileage and plugins may vary. And you can always use the Classic Editor to address any gaps.<br /></p>\n\n\n\n<p>As with every new thing, things might feel strange and new for a bit, but I’m confident once you start using it you’ll get comfy quickly and you won’t want to go back.</p>\n\n\n\n<p>The release candidate of 5.0 is stable and fine to develop against and test.</p>\n\n\n\n<h2>When will 5.0 be released?</h2>\n\n\n\n<p>We have had a stable RC1, which stands for first release candidate, and about to do our second one. There is only currently one known blocker and it&#8217;s cosmetic. The stability and open issues in the release candidates thus far makes me optimistic we can release soon, but as before the primary driver will be the stability and quality of the underlying software. We made the mistake prior of announcing dates when lots of code was still changing, and had to delay because of regressions and bugs. Now that things aren&#8217;t changing, we&#8217;re approaching a time we can commit to a date soon.</p>\n\n\n\n<h2>Is it terrible to do a release in December?</h2>\n\n\n\n<p>Some people think so, some don&#8217;t. There have been <a href=\"https://wordpress.org/about/roadmap/\">9 major WordPress releases</a> in previous Decembers. December releases actually comprise 34% of our major releases in the past decade.</p>\n\n\n\n<h2>Can I set it up so only certain users get to use Gutenberg? </h2>\n\n\n\n<p>Yes, and soon. We’re going to be doing another update to the Classic Editor before the 5.0 release to give it a bit more fine-grained user control &#8212; we’ve heard requests for options that allow certain users or certain roles and post types to have Gutenberg while others have Classic Editor. </p>\n\n\n\n<h2>What happens after 5.0? </h2>\n\n\n\n<p>We’ve been doing a release of Gutenberg every two weeks, and 5.0 isn’t going to stop that. We’ll do minor release to 5.0 (5.0.1, 5.0.2) fortnightly, with occasional breaks, so if there’s feedback that comes in, we can address it quickly. Many of the previous bugs in updates were from juggling between updates in the plugin and core, now that Gutenberg is in core it&#8217;s much easier and safer to incrementally update.</p>\n\n\n\n<h2>What about Gutenberg and accessibility? </h2>\n\n\n\n<p>We’ve had some important discussions about accessibility over the past few weeks and I am grateful for those who have helped raise these questions in the community. <br /></p>\n\n\n\n<p>Accessibility has been core to WordPress from the very beginning. It’s part of why we started – the adoption of web standards and accessibility.<br /></p>\n\n\n\n<p>But where I think we fell down was with project management &#8212; specifically, we had a team of volunteers that felt like they were disconnected from the rapid development that was happening with Gutenberg. We need to improve that. In the future I don’t know if it makes sense to have accessibility as a separate kind of process from the core development. It needs to be integrated at every single stage. <br /></p>\n\n\n\n<p>Still, we’ve accomplished a lot, as Matías <a href=\"https://make.wordpress.org/core/2018/10/18/regarding-accessibility-in-gutenberg/\">has written about</a>. There have been more than 200 closed issues related to accessibility since the very beginning. <br /></p>\n\n\n\n<p>We’re also taking the opportunity to fix some things that have had poor accessibility in WordPress from the beginning. <a href=\"https://codemirror.net/6/\">CodeMirror</a>, which is a code editor for templates, is not accessible, so we have some parts of WordPress that we really need to work on to make better. <br /></p>\n\n\n\n<p>Speaking of which, CodeMirror was seeking funding for their next version &#8212; Automattic has now <a href=\"https://codemirror.net/6/\">sponsored that funding</a> and in return it will be made available under the GPL, and that the next version of CodeMirror will be fully accessible. <br /></p>\n\n\n\n<div class=\"wp-block-embed__wrapper\">\n<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Great news ? Due to a substantial donation from <a href=\"https://twitter.com/automattic?ref_src=twsrc%5Etfw\">@automattic</a> our crowdfunding goal has been reached, and CodeMirror 6 is definitely happening!</p>&mdash; CodeMirror (@codemirror) <a href=\"https://twitter.com/codemirror/status/1054759532990218242?ref_src=twsrc%5Etfw\">October 23, 2018</a></blockquote>\n</div>\n\n\n\n<p>Finally, Automattic will be funding an accessibility study of WordPress, Gutenberg, and an evaluation of best practices across the web, to ensure WordPress is fully accessible and setting new standards for the web overall. </p>\n\n\n\n<h2>After WordPress 5.0, is the Gutenberg name going to stick around?</h2>\n\n\n\n<p>Sometimes code names can take on a life of their own. I think Gutenberg is still what we’ll call this project &#8212; it’s <a href=\"https://github.com/WordPress/gutenberg\">called that on GitHub</a>, and you’re also seeing it <a href=\"https://drupalgutenberg.org/\">adopted by other CMSes beyond WordPress</a> &#8212; but for those outside the community I can see it simply being known as “the new WordPress editor.” </p>\n\n\n\n<h2>With the adoption of React for Gutenberg, what do you see as the future for React and WordPress? </h2>\n\n\n\n<p>In 2015 I said <a href=\"https://wordpress.tv/2015/12/07/matt-mullenweg-state-of-the-word-2015/\">“Learn JavaScript deeply”</a> &#8212; then in 2016 we brought the <a href=\"https://developer.wordpress.org/rest-api/\">REST API</a> into Core. Gutenberg is the first major feature built entirely on the REST API, so if you are learning things today, learn JavaScript, and I can imagine a future wp-admin that’s 100% JavaScript talking to APIs. I’m excited to see that happen. <br /></p>\n\n\n\n<p>Now, switching to a pure JavaScript interface could break some backward compatibility, but a nice thing about Gutenberg is that it provides an avenue for all plugins to work through &#8212; it gives them a way to plug in to that. It can eliminate the need for what’s currently done in custom admin screens. &nbsp;<br /></p>\n\n\n\n<p>The other beautiful thing is that because Gutenberg essentially allows for translation into many different formats &#8212; it can publish to your web page, it can publish your RSS feed, AMP, it can publish blocks that can be translated into email for newsletters &#8212; there’s so much in the structured nature of Gutenberg and the semantic HTML that it creates and the grammar that’s used to parse it, can enable for other applications. <br /></p>\n\n\n\n<p>It becomes a little bit like a <em>lingua franca</em> that even crosses CMSes. There’s now these new cross-CMS Gutenberg blocks that will be possible. It’s not just WordPress anymore &#8212; it might be a JavaScript block that was written for Drupal that you install on your WordPress site. How would that have ever happened before? That’s why we took two years off &#8212; it’s why we’ve had everyone in the world working on this thing. It’s because we want it to be #WorthIt. <br /></p>\n\n\n\n<p>And WordPress 5.0 is just the starting line. We want to get it to that place where it’s not just better than what we have today, but a world-class, web-defining experience. It’s what we want to create and what everyone deserves. </p>\n\n\n\n<h2>Was this post published with Gutenberg?</h2>\n\n\n\n<p>Of course. <img src=\"https://s.w.org/images/core/emoji/11/72x72/1f604.png\" alt=\"😄\" class=\"wp-smiley\" /> No bugs, but I do see lots of areas we can continue to improve and I&#8217;m excited to get to work on future iterations.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Nov 2018 23:56:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: WPCampus Seeks to Raise $30K for Gutenberg Accessibility Audit\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=86032\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/wpcampus-seeks-to-raise-30k-for-gutenberg-accessibility-audit\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4364:\"<p>WPCampus is <a href=\"https://wpcampus.org/2018/11/fundraising-for-wpcampus-gutenberg-accessibility-audit/\" rel=\"noopener\" target=\"_blank\">seeking funding</a> to conduct an accessibility audit of WordPress&#8217; Gutenberg editor. The non-profit organization is dedicated to helping web professionals, educators, and others who work with WordPress in higher education. Educational institutions often have stricter legal obligations that require software to be WCAG 2.0 level AA compliant and many European institutions set the bar even higher at WCAG 2.1.</p>\n<p><a href=\"https://wptavern.com/wpcampus-is-pursuing-an-independent-accessibility-audit-of-gutenberg\" rel=\"noopener\" target=\"_blank\">WPCampus moved to spearhead an audit</a> after Automattic decided to forego Matt MacPherson&#8217;s <a href=\"https://wptavern.com/gutenberg-accessibility-audit-postponed-indefinitely\" rel=\"noopener\" target=\"_blank\">proposal</a> for Gutenberg to undergo an accessibility audit. Results of the audit will help WPCampus determine any potential legal risk for institutions upgrading to WordPress 5.0 and will also identify specific challenges that Gutenberg introduces for assistive technology users and others with accessibility needs.</p>\n<p>&#8220;A professional accessibility audit is a large expense for a small nonprofit like WPCampus,&#8221; WPCampus director Rachel Cherry said. &#8220;Accessibility is important to all of us in the WordPress community. We’re asking for your help to fund the audit and ensure this important research is completed.&#8221;</p>\n<p>WPCampus is still evaluating proposals from vendors and will announce its selection soon, along with an updated timeline for completing the audit. The organization has set its funding goal at $30,000, an amount that falls in the mid-range of the proposals the selection committee has received. If the campaign raises more than the amount required, WPCampus plans to designate the funds for other accessibility-related efforts, such as future audits and live captioning at conferences.</p>\n<p>Two days after launching the campaign, WPCampus has received $3,692 (12%) towards its funding goal. The organization plans to share the results of the audit and any supporting documents on its website.</p>\n<p>The comments published on the donations page demonstrate how strongly supporters feel about getting an audit and using that information to make Gutenberg a tool that anyone can use. The topic of accessibility is close to the heart for many donating to the campaign.</p>\n<p>&#8220;When I was navigating stores with three small children, stores which helped me with automatic doors, wide aisles, and shopping carts for a crowd often made the decision for me as to whether I could shop at all,&#8221; WordPress developer <a href=\"https://robincornett.com/\" rel=\"noopener\" target=\"_blank\">Robin Cornett</a> said. &#8220;As we create content and build tools for the internet, we should be doing all we can to ensure the best online experience we can for everyone.&#8221;</p>\n<p>WordPress co-founder <a href=\"https://mikelittle.org/\" rel=\"noopener\" target=\"_blank\">Mike Little</a> also donated to the campaign, with comments on how important accessibility is to fulfilling the project&#8217;s mission.</p>\n<p>&#8220;As the platform that democratizes publishing, we can&#8217;t allow new features in WordPress to take that away from users with accessibility needs,&#8221; Little said.</p>\n<p>&#8220;Accessibility matters to everyone — injured, encumbered, distracted, disabled, everyone,&#8221; WordPress consultant <a href=\"http://adrianroselli.com\" rel=\"noopener\" target=\"_blank\">Adrian Roselli</a> said. Accessibility in WordPress matters to my clients because some of their people require it in order to use the tool and therefore stay gainfully employed.&#8221;</p>\n<p>The audit proposed months ago has evolved to become a community effort funded by passionate supporters working in various capacities throughout the WordPress ecosystem. If WPCampus is successful in funding its campaign, this particular approach has the benefit of making it a more cooperative effort with more people invested in the process than if it were funded by a single company. WPCampus aims to release the audit report to the community by January 17, 2019 but the dates will depend on the arrangement with the vendor. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Nov 2018 22:03:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Drupal 8.7 to Introduce Layout Builder, Contributors Face Accessibility Challenges\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=85572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://wptavern.com/drupal-8-7-to-introduce-layout-builder-contributors-face-accessibility-challenges\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6649:\"<p>WordPress 5.0 will soon replace the editor with the new Gutenberg editor as part of a multi-phase project to improve the experience of authoring rich content. Phase 2 will shift focus to tackle site customization, bringing more complex layout and page builder capabilities to Gutenberg.</p>\n<p>As this phase kicks off soon, it&#8217;s valuable to see what other platforms are doing on this front. Drupal has traditionally appealed to a more technical audience, and probably wouldn&#8217;t count Squarespace, Wix, and Tumblr among their competitors, but the project is getting more friendly towards site builders and content editors. Drupal has brought improvements to its usability, media, and layout experiences over the past few years in support of users who have demanded a more modern, simplified admin UI. The project is currently testing a visual design tool for building layouts.</p>\n<p>Two weeks ago, Drupal founder and project lead Dries Buytaert <a href=\"https://dri.es/why-drupal-layout-builder-is-so-unique-and-powerful\" rel=\"noopener noreferrer\" target=\"_blank\">previewed the new Layout Builder</a>, an experimental feature that is stabilizing and expected to land in Drupal 8.7 in May 2019. Layout Builder offers layouts for templated content, customizations to templated layouts, and custom pages. These uses are especially important when building sites with large amounts of content that occasionally require template overrides and one-off landing pages.</p>\n<p>Buytaert described how Layout Builder approaches the creation of one-off dynamic pages, which he said is similar to the capabilities found in services such as Squarespace and projects like Gutenberg for WordPress and Drupal: </p>\n<blockquote><p>A content author can start with a blank page, design a layout, and start adding blocks. These blocks can contain videos, maps, text, a hero image, or custom-built widgets (e.g. a Drupal View showing a list of the ten most popular gift baskets). Blocks can expose configuration options to the content author. For instance, a hero block with an image and text may offer a setting to align the text left, right, or center. These settings can be configured directly from a sidebar.</p></blockquote>\n<p>Buytaert&#8217;s demo video shows the Layout Builder in action. Its capabilities are similar to many of WordPress&#8217; third-party page builders, such as <a href=\"https://elementor.com/theme-builder/\" rel=\"noopener noreferrer\" target=\"_blank\">Elementor</a> and <a href=\"https://www.wpbeaverbuilder.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Beaver Builder</a>.</p>\n<p></p>\n<h3>Layout Builder Poses Accessibility Challenges</h3>\n<p>Layout Builder is anchored on one of Drupal&#8217;s stronger features &#8211; the ability to create structured content, but it faces some of the same accessibility challenges that WordPress&#8217; Gutenberg editor has encountered. </p>\n<p>In his post introducing Layout Builder, Buytaert made some pointed remarks about Drupal&#8217;s commitment to accessibility:</p>\n<blockquote><p>Accessibility is one of Drupal&#8217;s core tenets, and building software that everyone can use is part of our core values and principles. A key part of bringing Layout Builder functionality to a &#8220;stable&#8221; state for production use will be ensuring that it passes our accessibility gate (Level AA conformance with WCAG and ATAG). This holds for both the authoring tool itself, as well as the markup that it generates. We take our commitment to accessibility seriously.</p></blockquote>\n<p>Some contributors are not as optimistic about Drupal being able to fulfill these bold claims in time to ship the feature in 8.7.0. Andrew Macpherson, one of the accessibility topic maintainers for Drupal 8 core, has <a href=\"https://www.drupal.org/project/drupal/issues/3007978#comment-12853731\" rel=\"noopener\" target=\"_blank\">proposed Layout Builder offer an alternative UI</a> that users can access without the visual preview UI.</p>\n<p>&#8220;Dries&#8217; blog post about layout builder yesterday says we&#8217;re on track to mark this as stable for D8.7.0,&#8221; Macpherson said. &#8220;I&#8217;m not at all optimistic about that, because as yet there is no feasible plan for how it can be made accessible.</p>\n<p>&#8220;A minimum viable product for Layout Builder accessibility would be at least one method which works, for each user task, for each input/output method. I don&#8217;t think we can say we have found a feasible approach. We&#8217;re in deeply experimental territory here &#8211; there isn&#8217;t a well-established, reliable pattern we can just copy to make the current layout builder accessible. Essentially, we&#8217;re making stuff up in a hurry, for a novel UI, with limited opportunity for design validation. There&#8217;s no guarantee that users are going to understand it, or find it easy to use. That&#8217;s why I&#8217;m not optimistic about it getting past the accessibility gate in time for D8.7.0.&#8221;</p>\n<p>Macpherson said that WCAG strongly advises against providing alternate versions but allows for them in instances where the main version cannot be made accessible.</p>\n<p>&#8220;I think we are effectively in this situation now, although we are still exploring ideas,&#8221; he said. </p>\n<p>Macpherson also recommended they continue striving to make the drag-and-drop, visual-preview layout builder UI accessible at the same time. He referenced emerging <a href=\"https://inclusivedesignprinciples.org/#offer-choice\" rel=\"noopener\" target=\"_blank\">principles of Inclusive Design</a> for application developers, which recommend &#8220;offering choice,&#8221; giving users different ways of completing tasks, especially those that may be complex or non-standard.</p>\n<p>&#8220;Eventually, I&#8217;d like to see BOTH layout builder UIs being accessible, and offer genuinely useful choices for everyone,&#8221; Macpherson said. &#8220;But let&#8217;s take the time to do it well, instead of hastily bolting on fixes for one type of interaction method at a time, in a rush to ship a single layout builder UI. &#8221;</p>\n<p>Macpherson&#8217;s proposal is still under consideration, but it provides an interesting perspective on similar challenges WordPress contributors are facing with Gutenberg. Modernizing UIs to make the site building experience more accessible for those who don&#8217;t know how to code has to be balanced with considerations for those who may not be able see very well or use a mouse. Drupal contributors are exploring providing an alternative accessible UI as a solution to empower more users to take advantage of the new Layout Builder.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Nov 2018 04:31:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: WPWeekly Episode 339 – Interview With Pippin Williamson, Founder of Sandhills Development, LLC\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=86062&preview=true&preview_id=86062\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"https://wptavern.com/wpweekly-episode-339-interview-with-pippin-williamson-founder-of-sandhills-development-llc\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1455:\"<p>In this episode, <a href=\"http://jjj.me\">John James Jacoby</a> and I are joined by <a href=\"http://pippin.com/\">Pippin Williamson</a>, founder of <a href=\"http://sandhillsdev.com/\">Sandhills Development</a>, LLC. Pippin describes what he&#8217;s learned going through the process of opening a brick and mortar business.</p>\n<p>He also describes the emotional process of firing employees, making business decisions as a team, and how he wants to create a life-long company where employees stick around for decades.</p>\n<p>Near the end of the episode, Pippin expresses his opinions on Gutenberg the product and Gutenberg the process. You might be surprised by what he has to say.</p>\n<h2>Stories Discussed:</h2>\n<p><a href=\"https://pippinsplugins.com/2017-in-review/\">2017 in review</a></p>\n<h2>WPWeekly Meta:</h2>\n<p><strong>Next Episode:</strong> Wednesday, December 5th 3:00 P.M. Eastern</p>\n<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>\n<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>\n<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>\n<p>Subscribe to <a href=\"https://play.google.com/music/listen?u=0#/ps/Ir3keivkvwwh24xy7qiymurwpbe\">WordPress Weekly via Google Play</a></p>\n<p><strong>Listen To Episode #339:</strong><br />\n</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Nov 2018 19:54:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: SyntaxHighlighter Evolved Plugin Adds Gutenberg Support\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=85968\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/syntaxhighlighter-evolved-plugin-adds-gutenberg-support\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4743:\"<p>WordPress 5.0 will ship with a code block in the new editor but it doesn&#8217;t include syntax highlighting. The code is currently wrapped in pre tags. During the earlier days of Gutenberg&#8217;s development, the HTML block had syntax highlighting but the team was not satisfied with its implementation and decided to pull it until they could <a href=\"https://github.com/WordPress/gutenberg/issues/10423\" rel=\"noopener\" target=\"_blank\">provide more consistent behavior across blocks</a>. </p>\n<p>For now, users will have to depend on a plugin to get syntax highlighting. <a href=\"https://wordpress.org/plugins/syntaxhighlighter/\" rel=\"noopener\" target=\"_blank\">SyntaxHighlighter Evolved</a> is one of the first plugins of its kind to add Gutenberg support via its own block. </p>\n<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2018/11/Screen-Shot-2018-11-28-at-10.08.36-AM.png?ssl=1\"><img /></a></p>\n<p>The plugin currently adds syntax highlighting to source code on the frontend only. Nevertheless, it&#8217;s a great use case for Gutenberg, as the plugin previously required you to remember how to structure the shortcode in a particular way in order to use it. </p>\n<p>Ian Dunn <a href=\"https://github.com/Viper007Bond/syntaxhighlighter/pull/78\" rel=\"noopener\" target=\"_blank\">contributed the Gutenberg support</a> for SyntaxHighlighter Evolved. In the PR for this feature, Dunn said he wanted to give existing users a way to continue using the plugin after WordPress 5.0 is released:</p>\n<blockquote><p>\nThe syntax highlighting only works on the front end, due to the nature of SyntaxHighlighter. Details are documented in the edit() function&#8217;s docblock.</p>\n<p>Because of that, this isn&#8217;t the ideal syntax highlighting block[1], but this provides a way for existing users to continue using the plugin without having to migrate old posts to a different plugin.</p>\n<p>Another limitation is that this PR only supports the language attribute of the shortcode, because I ran out of time/energy. This lays the groundwork, though, so the rest of them can easily be added in a future iteration.</p></blockquote>\n<p>SyntaxHighlighter Evolved is active on more than 40,000 installations and is also used on WordPress.com, so this update to the plugin should help those who rely on it to be able to use the new Gutenberg editor without having to switch back to the old editor when they need to add code to their content.</p>\n<p>There is still some debate about the best way to provide syntax highlighting in Gutenberg. Another implementation called <a href=\"https://github.com/mkaz/code-syntax-block\" rel=\"noopener\" target=\"_blank\">Code Syntax Block</a> by Marcus Kazmierczak, extends Gutenberg&#8217;s existing code block to offer syntax highlighting, instead of creating a new block for it. It also uses <a href=\"http://prismjs.com/\" rel=\"noopener\" target=\"_blank\">PrismJS syntax highlighter</a>.</p>\n<p><a href=\"https://github.com/cedaro/shiny-code\" rel=\"noopener\" target=\"_blank\">Shiny Code</a> is another approach that adds a new block for code and provides a preview inside the Gutenberg editor. </p>\n<p><a href=\"https://cloudup.com/cAjq1AKskL8\"><img src=\"https://i1.wp.com/cldup.com/2MLWW0oXx3.gif?resize=627%2C308&ssl=1\" alt=\"Shiny code\" width=\"627\" height=\"308\" /></a></p>\n<p>In the official plugin directory, the <a href=\"https://wordpress.org/plugins/enlighter/\" rel=\"noopener\" target=\"_blank\">Enlighter</a> plugin, which has 10,000 active installs, offers experimental support for Gutenberg that is being <a href=\"https://github.com/EnlighterJS/Plugin.Gutenberg\" rel=\"noopener\" target=\"_blank\">actively developed on GitHub</a>. <a href=\"https://wordpress.org/plugins/kebo-code/\" rel=\"noopener\" target=\"_blank\">Kebo Code</a>, a relatively new plugin with fewer than 10 installs, was created to offer syntax highlighting for Gutenberg and currently supports 121 languages and two themes. Users will have to switch to the frontend to see the code rendered with the theme selected. </p>\n<p>SyntaxHighlighter Evolved does not yet provide a way for highlighting existing code blocks or transforming a core code block to use the plugin&#8217;s syntax highlighting. Converting all existing code blocks might take some time for those who have been using it extensively. Alex Mills, the plugin&#8217;s author, said he is considering all of these issues and welcomes patches on the <a href=\"https://github.com/Viper007Bond/syntaxhighlighter\" rel=\"noopener\" target=\"_blank\">GitHub repository for the plugin</a>. Plugin authors may change their approaches over time, depending on where Gutenberg goes in the future, so users will want to evaluate available plugins periodically to see which ones suit their needs.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Nov 2018 17:10:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: WordCamp US 2018 Livestream Tickets Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=85848\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wptavern.com/wordcamp-us-2018-livestream-tickets-now-available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1360:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2016/11/nashville.jpg?ssl=1\"><img /></a>photo credit: Viv Lynch <a href=\"http://www.flickr.com/photos/68894626@N00/30070498810\">Westward</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nc-nd/2.0/\">(license)</a></p>\n<p>The countdown has started for <a href=\"https://2018.us.wordcamp.org\" rel=\"noopener\" target=\"_blank\">WordCamp US 2018</a> in Nashville. The event is just 10 days away. If you cannot attend, watching via the livestream is the next best option. Anyone can join the livestream for free, but viewers will need to <a href=\"https://2018.us.wordcamp.org/tickets/\" rel=\"noopener\" target=\"_blank\">sign up for a ticket</a> on the event website. </p>\n<p>This year&#8217;s <a href=\"https://2018.us.wordcamp.org/schedule/\" rel=\"noopener\" target=\"_blank\">schedule</a> includes sessions in two tracks: Banjo and Guitar. Matt Mullenweg&#8217;s annual <a href=\"https://2018.us.wordcamp.org/2018/11/27/state-of-the-word-2018/\" rel=\"noopener\" target=\"_blank\">State of the Word</a> address is scheduled for Saturday, December 8, at 4:00 p.m. CST. Livestream ticket holders can tune in to any of the sessions and may also want to participate in the conversations on Twitter using the <a href=\"https://twitter.com/hashtag/WCUS?src=hash\" rel=\"noopener\" target=\"_blank\">#WCUS hashtag</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Nov 2018 22:09:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"\n	\n	\n	\n	\n	\n	\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"BuddyPress: BuddyPress 4.0.0 “Pequod”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=282222\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://buddypress.org/2018/11/buddypress-4-0-0-pequod/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5882:\"<p>BuddyPress 4.0.0 &#8220;Pequod&#8221; is now available!</p>\n<h3>A focus on data privacy and control</h3>\n<p>BuddyPress boasts a proud history of letting community members and managers control their data, independent of third-party, commercial entities. In this spirit, as well as the spirit of recent regulations like the EU&#8217;s General Data Protection Regulation (GDPR), Expanding on some of the tools introduced by WordPress in version 4.9.8, BuddyPress 4.0 introduces a suite of tools allowing users and site admins to manage member data and privacy.</p>\n<div id=\"attachment_282223\" class=\"wp-caption alignnone\"><a href=\"https://buddypress.org/wp-content/uploads/1/2018/11/data-export.png\"><img class=\"size-full wp-image-282223\" src=\"https://buddypress.org/wp-content/uploads/1/2018/11/data-export.png\" alt=\"Screenshot of \" /></a><p class=\"wp-caption-text\">Giving your users greater control over their data</p></div>\n<p>The new &#8220;Export Data&#8221; Settings panel lets users request an export of all BuddyPress data they&#8217;ve created. BuddyPress integrates seamlessly with the data export functionality introduced in WordPress 4.9.8, and BP data is included in exports that are initiated either from the Export Data panel or via WP&#8217;s Tools &gt; Export Personal Data interface.</p>\n<p>BuddyPress 4.0 also integrates with WordPress 4.9.8&#8217;s Privacy Policy tools. When you create or update your Privacy Policy, BP will suggest text that&#8217;s specifically tailored to the kinds of social data generated on a BuddyPress site. And will prompt registering users to agree to the Privacy Policy, if your theme supports it.</p>\n<p>We&#8217;ve also done a complete review of BuddyPress&#8217;s cookie behavior, and dramatically reduced the number of cookies needed to browse a BP-powered site &#8211; especially for logged-out users. We&#8217;re confident that this change will help site owners comply with local privacy regulations.</p>\n<h3>Nouveau and other improvements</h3>\n<p>The BuddyPress team has been hard at work improving the Nouveau template pack introduced in BuddyPress 4.0. We&#8217;ve improved accessibility, extensibility, and responsiveness on mobile devices.</p>\n<p>BuddyPress 4.0 also contains a number of internal improvements that improve compatibility with various version of PHP, fix formatting and content issues when sending emails, and address some backward-compatibility concerns.</p>\n<h3>Mille grazie</h3>\n<p>As usual, this BuddyPress release is only possible thanks to the contributions of the community. Special thanks to the following folks who contributed code and testing to the release: <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha (xknown)</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta/\">Ankit K Gupta (ankit-k-gupta)</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone B Gorges (boonebgorges)</a>, <a href=\"https://profiles.wordpress.org/sbrajesh/\">Brajesh Singh (sbrajesh)</a>, <a href=\"https://profiles.wordpress.org/brianbws/\">Brian Cruikshank (brianbws)</a>, <a href=\"https://profiles.wordpress.org/needle/\">Christian Wach (needle)</a>, <a href=\"https://profiles.wordpress.org/cyberwani/\">Dinesh Kesarwani (cyberwani)</a>, <a href=\"https://profiles.wordpress.org/dipesh.kakadipa/\">dipeshkakadiya</a>, <a href=\"https://profiles.wordpress.org/drywallbmb/\">drywallbmb</a>, <a href=\"https://profiles.wordpress.org/dullowl/\">dullowl</a>, <a href=\"https://profiles.wordpress.org/eric01/\">Eric (eric01)</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder (garrett-eclipse)</a>, <a href=\"https://profiles.wordpress.org/harshall/\">Harshal Limaye (harshall)</a>, <a href=\"https://profiles.wordpress.org/hnla/\">Hugo (hnla)</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby (johnjamesjacoby)</a>, <a href=\"https://profiles.wordpress.org/marcella1981/\">Marcella (marcella1981)</a>, <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet (imath)</a>, <a href=\"https://profiles.wordpress.org/mercime/\">mercime</a>, <a href=\"https://profiles.wordpress.org/MorgunovVit/\">MorgunovVit</a>, <a href=\"https://profiles.wordpress.org/n0barcode/\">n0barcode</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya/\">paresh.radadiya (pareshradadiya)</a>, <a href=\"https://profiles.wordpress.org/DJPaul/\">Paul Gibbs (DJPaul)</a>, <a href=\"https://profiles.wordpress.org/pooja1210/\">Pooja N Muchandikar (pooja1210)</a>, <a href=\"https://profiles.wordpress.org/r-a-y/\">r-a-y</a>, <a href=\"https://profiles.wordpress.org/espellcaste/\">Renato Alves (espellcaste)</a>, <a href=\"https://profiles.wordpress.org/RT77/\">RT77</a>, <a href=\"https://profiles.wordpress.org/cyclic/\">Ryan Williams (cyclic)</a>, <a href=\"https://profiles.wordpress.org/elhardoum/\">Samuel Elh (elhardoum)</a>, <a href=\"https://profiles.wordpress.org/shubh14/\">shubh14</a>, <a href=\"https://profiles.wordpress.org/spdustin/\">spdustin</a>, <a href=\"https://profiles.wordpress.org/suvikki/\">suvikki</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar (netweb)</a>, <a href=\"https://profiles.wordpress.org/thejimmy/\">thejimmy</a>, <a href=\"https://profiles.wordpress.org/vapvarun/\">vapvarun</a>, <a href=\"https://profiles.wordpress.org/wbcomdesigns/\">Wbcom Designs (wbcomdesigns)</a>, <a href=\"https://profiles.wordpress.org/yahil/\">Yahil Madakiya (yahil)</a></p>\n<p>This version of BuddyPress is code-named &#8220;Pequod&#8221; after the famous <a href=\"https://pequodspizza.com/\">Pequod&#8217;s Pizza</a> in Chicago, where the crust really is caramelized, and the dish really is deep. Buon gusto!</p>\n<h3>Keep on truckin&#8217;</h3>\n<p>Questions or comments about the release? Visit the <a href=\"https://buddypress.org/support/\">buddypress.org support forums</a>, or open a ticket on <a href=\"https://buddypress.trac.wordpress.org\">our bugtracker</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 27 Nov 2018 19:57:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Boone Gorges\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sun, 06 Jan 2019 20:01:50 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Sun, 06 Jan 2019 19:45:29 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911040210\";}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(144, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1546848112', 'no'),
(145, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1546804912', 'no'),
(146, '_transient_timeout_dash_v2_faf8ccdcd452c9b620052a01eae24ffb', '1546848112', 'no'),
(147, '_transient_dash_v2_faf8ccdcd452c9b620052a01eae24ffb', '<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/12/wordpress-5-0-2-maintenance-release/\'>WordPress 5.0.2 Maintenance Release</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/beaver-builder-doubles-down-on-serving-power-users-in-response-to-gutenberg\'>WPTavern: Beaver Builder Doubles Down on Serving Power Users in Response to Gutenberg</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wp-storybook-a-handy-reference-for-wordpress-react-ui-components\'>WPTavern: WP Storybook: A Handy Reference for WordPress React UI Components</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/wordpress-com-launches-new-do-anything-marketing-campaign\'>WPTavern: WordPress.com Launches New “Do Anything” Marketing Campaign</a></li></ul></div>', 'no'),
(148, '_transient_timeout_plugin_slugs', '1546891434', 'no'),
(149, '_transient_plugin_slugs', 'a:5:{i:0;s:19:\"akismet/akismet.php\";i:1;s:53:\"child-theme-configurator/child-theme-configurator.php\";i:2;s:23:\"gutenberg/gutenberg.php\";i:3;s:9:\"hello.php\";i:4;s:37:\"tinymce-advanced/tinymce-advanced.php\";}', 'no'),
(150, 'recently_activated', 'a:0:{}', 'yes'),
(151, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1546815840', 'no'),
(152, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4537;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3202;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2605;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2463;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1897;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1707;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1693;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1462;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1419;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1418;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1416;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1347;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1288;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1275;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1128;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1084;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1069;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1044;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:966;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:911;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:840;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:827;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:814;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:751;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:720;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:709;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:704;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:701;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:692;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:681;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:674;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:671;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:653;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:648;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:635;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:629;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:622;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:611;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:611;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:607;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:575;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:560;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:554;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:551;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:550;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:542;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:528;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:521;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:521;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:519;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:515;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:506;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:500;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:491;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:490;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:486;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:468;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:468;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:461;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:454;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:451;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:449;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:447;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:429;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:429;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:423;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:419;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:417;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:412;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:398;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:393;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:391;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:382;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:376;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:375;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:374;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:373;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:373;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:360;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:357;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:356;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:353;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:348;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:346;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:343;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:340;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:339;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:335;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:322;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:318;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:315;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:315;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:314;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:310;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:309;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:305;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:304;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:304;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:303;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:303;}}', 'no'),
(153, 'current_theme', 'Catch Responsive', 'yes'),
(154, 'theme_mods_catch-responsive', 'a:5:{i:0;b:0;s:11:\"custom_logo\";i:0;s:12:\"logo_version\";s:3:\"2.8\";s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(155, 'theme_switched', '', 'yes'),
(156, 'widget_catchresponsive_social_icons', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(157, '_transient_timeout_catchresponsive_custom_css', '1546893877', 'no'),
(158, '_transient_catchresponsive_custom_css', '', 'no'),
(159, '_transient_timeout_catchresponsive_social_icons', '1546893877', 'no'),
(160, '_transient_catchresponsive_social_icons', '', 'no'),
(161, '_transient_timeout_catchresponsive_featured_slider', '1546892030', 'no'),
(162, '_transient_catchresponsive_featured_slider', '\n				<section id=\"feature-slider\">\n					<div class=\"wrapper\">\n						<div class=\"cycle-slideshow\"\n						    data-cycle-log=\"false\"\n						    data-cycle-pause-on-hover=\"true\"\n						    data-cycle-swipe=\"true\"\n						    data-cycle-auto-height=container\n						    data-cycle-fx=\"fadeout\"\n							data-cycle-speed=\"1000\"\n							data-cycle-timeout=\"4000\"\n							data-cycle-loader=\"true\"\n							data-cycle-slides=\"> article\"\n							>\n\n						    <!-- prev/next links -->\n						    <div class=\"cycle-prev\"></div>\n						    <div class=\"cycle-next\"></div>\n\n						    <!-- empty element for pager links -->\n	    					<div class=\"cycle-pager\"></div>\n								<article class=\"post hentry slides demo-image displayblock\">\n									<figure class=\"slider-image\">\n										<a title=\"Slider Image 1\" href=\"http://localhost/test_ui/wordpress-wptestas/\">\n											<img src=\"http://localhost/test_ui/wordpress-wptestas/wp-content/themes/catch-responsive/images/gallery/slider1-1200x514.jpg\" class=\"wp-post-image\" alt=\"Slider Image 1\" title=\"Slider Image 1\">\n										</a>\n									</figure>\n									<div class=\"entry-container\">\n										<header class=\"entry-header\">\n											<h2 class=\"entry-title\">\n												<a title=\"Slider Image 1\" href=\"#\"><span>Slider Image 1</span></a>\n											</h2>\n										</header>\n										<div class=\"entry-content\">\n											<p>Slider Image 1 Content</p>\n										</div>\n									</div>\n								</article><!-- .slides -->\n\n								<article class=\"post hentry slides demo-image displaynone\">\n									<figure class=\"Slider Image 2\">\n										<a title=\"Slider Image 2\" href=\"http://localhost/test_ui/wordpress-wptestas/\">\n											<img src=\"http://localhost/test_ui/wordpress-wptestas/wp-content/themes/catch-responsive/images/gallery/slider2-1200x514.jpg\" class=\"wp-post-image\" alt=\"Slider Image 2\" title=\"Slider Image 2\">\n										</a>\n									</figure>\n									<div class=\"entry-container\">\n										<header class=\"entry-header\">\n											<h2 class=\"entry-title\">\n												<a title=\"Slider Image 2\" href=\"#\"><span>Slider Image 2</span></a>\n											</h2>\n										</header>\n										<div class=\"entry-content\">\n											<p>Slider Image 2 Content</p>\n										</div>\n									</div>\n								</article><!-- .slides --> \n						</div><!-- .cycle-slideshow -->\n					</div><!-- .wrapper -->\n				</section><!-- #feature-slider -->', 'no'),
(163, '_transient_timeout_catchresponsive_featured_content', '1546893877', 'no'),
(164, '_transient_catchresponsive_featured_content', '\n				<section id=\"featured-content\" class=\"layout-three demo-featured-content\">\n					<div class=\"wrapper\"><div class=\"featured-heading-wrap\"><h2 id=\"featured-heading\" class=\"entry-title\">Featured Content</h2><p>Here you can showcase the x number of Featured Content. You can edit this Headline, Subheadline and Feaured Content from \"Appearance -&gt; Customize -&gt; Featured Content Options\".</p></div><!-- .featured-heading-wrap -->\n						<div class=\"featured-content-wrap\">\n		<article id=\"featured-post-1\" class=\"post hentry post-demo\">\n			<figure class=\"featured-content-image\">\n				<img alt=\"Central Park\" class=\"wp-post-image\" src=\"http://localhost/test_ui/wordpress-wptestas/wp-content/themes/catch-responsive/images/gallery/featured1-350x197.jpg\" />\n			</figure>\n			<div class=\"entry-container\">\n				<header class=\"entry-header\">\n					<h2 class=\"entry-title\">\n						Central Park\n					</h2>\n				</header>\n				<div class=\"entry-content\">\n					Central Park is is the most visited urban park in the United States as well as one of the most filmed locations in the world. It was opened in 1857 and is expanded in 843 acres of city-owned land.\n				</div>\n			</div><!-- .entry-container -->\n		</article>\n\n		<article id=\"featured-post-2\" class=\"post hentry post-demo\">\n			<figure class=\"featured-content-image\">\n				<img alt=\"Home Office\" class=\"wp-post-image\" src=\"http://localhost/test_ui/wordpress-wptestas/wp-content/themes/catch-responsive/images/gallery/featured2-350x197.jpg\" />\n			</figure>\n			<div class=\"entry-container\">\n				<header class=\"entry-header\">\n					<h2 class=\"entry-title\">\n						Home Office\n					</h2>\n				</header>\n				<div class=\"entry-content\">\n					It might be work, but it doesn\'t have to feel like it. All you need is a comfortable desk, nice laptop, home office furniture that keeps things organized, and the right lighting for the job.\n				</div>\n			</div><!-- .entry-container -->\n		</article>\n\n		<article id=\"featured-post-3\" class=\"post hentry post-demo\">\n			<figure class=\"featured-content-image\">\n				<img alt=\"Vespa Scooter\" class=\"wp-post-image\" src=\"http://localhost/test_ui/wordpress-wptestas/wp-content/themes/catch-responsive/images/gallery/featured3-350x197.jpg\" />\n			</figure>\n			<div class=\"entry-container\">\n				<header class=\"entry-header\">\n					<h2 class=\"entry-title\">\n						Vespa Scooter\n					</h2>\n				</header>\n				<div class=\"entry-content\">\n					The Vespa Scooter has evolved from a single model motor scooter manufactured in the year 1946 by Piaggio & Co. S.p.A. of Pontedera, Italy-to a full line of scooters, today owned by Piaggio.\n				</div>\n			</div><!-- .entry-container -->\n		</article>\n						</div><!-- .featured-content-wrap -->\n					</div><!-- .wrapper -->\n				</section><!-- #featured-content -->', 'no'),
(165, '_transient_all_the_cool_cats', '1', 'yes'),
(166, '_transient_timeout_catchresponsive_footer_content', '1546892031', 'no'),
(167, '_transient_catchresponsive_footer_content', '\n    	<div id=\"site-generator\">\n    		<div class=\"wrapper\">\n    			<div id=\"footer-content\" class=\"copyright\">Copyright &copy; 2019 <a href=\"http://localhost/test_ui/wordpress-wptestas/\">wptestas</a>. All Rights Reserved.  &#124; Catch Responsive&nbsp; &nbsp;<a target=\"_blank\" href=\"https://catchthemes.com/\">Catch Themes</a></div>\n			</div><!-- .wrapper -->\n		</div><!-- #site-generator -->', 'no'),
(168, '_transient_timeout_catchresponsive_scrollup', '1546892031', 'no'),
(169, '_transient_catchresponsive_scrollup', '<a href=\"#masthead\" id=\"scrollup\" class=\"genericon\"><span class=\"screen-reader-text\">Slinkti aukštyn</span></a>', 'no'),
(170, '_site_transient_timeout_available_translations', '1546816785', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(171, '_site_transient_available_translations', 'a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-01 06:22:57\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-08 00:58:53\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 08:43:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-05 11:37:23\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-10 08:54:40\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 21:28:23\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 17:08:36\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-14 19:51:46\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-07-06 08:46:24\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 13:19:31\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-25 12:30:09\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:47:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:48:22\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-27 15:33:27\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-10 07:51:56\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-13 03:45:44\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:14:01\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-13 03:45:55\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-13 05:42:05\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-09 14:53:42\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-10 17:20:09\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-15 15:46:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:20:18\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-15 16:32:57\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-13 05:08:30\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-04 08:05:41\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-05 07:24:22\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-08 18:24:55\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 16:02:42\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-02 09:10:15\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-09 10:32:06\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-06 18:14:24\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 10:29:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-01 11:16:36\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 10:30:44\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-02 06:28:35\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-22 02:28:45\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-28 17:12:13\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-13 21:42:46\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-11 00:57:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-29 08:41:27\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-18 11:11:49\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-05 19:28:41\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-10 17:50:37\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-21 07:25:37\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-05 14:41:09\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 09:30:48\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-07 01:11:27\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-08 20:59:54\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-09 15:27:18\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-31 08:30:58\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-01 13:20:12\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 20:59:54\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-10 13:43:09\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-02 17:08:41\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-07 21:08:54\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-01 10:24:13\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-03 09:18:37\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-10-11 06:46:15\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-06 02:26:39\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-12-10 23:11:47\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-11-19 20:31:12\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-09 00:56:52\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}', 'no'),
(172, '_site_transient_timeout_theme_roots', '1546808626', 'no'),
(173, '_site_transient_theme_roots', 'a:4:{s:16:\"catch-responsive\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(174, 'new_admin_email', 'pcr.kompiuteriai@gmail.com', 'yes'),
(177, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:3:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.2\";s:7:\"version\";s:5:\"5.0.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.2\";s:7:\"version\";s:5:\"5.0.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.9.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.9.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.9-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.9-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.9-partial-8.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.9-rollback-8.zip\";}s:7:\"current\";s:5:\"4.9.9\";s:7:\"version\";s:5:\"4.9.9\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:5:\"4.9.8\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1546806828;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(178, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1546806828;s:8:\"response\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.2\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:23:\"gutenberg/gutenberg.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:23:\"w.org/plugins/gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:6:\"plugin\";s:23:\"gutenberg/gutenberg.php\";s:11:\"new_version\";s:5:\"4.7.1\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/gutenberg/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/gutenberg.4.7.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/gutenberg/assets/icon-256x256.jpg?rev=1776042\";s:2:\"1x\";s:62:\"https://ps.w.org/gutenberg/assets/icon-128x128.jpg?rev=1776042\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/gutenberg/assets/banner-1544x500.jpg?rev=1718710\";s:2:\"1x\";s:64:\"https://ps.w.org/gutenberg/assets/banner-772x250.jpg?rev=1718710\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"tinymce-advanced/tinymce-advanced.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/tinymce-advanced\";s:4:\"slug\";s:16:\"tinymce-advanced\";s:6:\"plugin\";s:37:\"tinymce-advanced/tinymce-advanced.php\";s:11:\"new_version\";s:5:\"4.8.2\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/tinymce-advanced/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/tinymce-advanced.4.8.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-256x256.png?rev=971511\";s:2:\"1x\";s:68:\"https://ps.w.org/tinymce-advanced/assets/icon-128x128.png?rev=971511\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/tinymce-advanced/assets/banner-1544x500.png?rev=1998995\";s:2:\"1x\";s:71:\"https://ps.w.org/tinymce-advanced/assets/banner-772x250.png?rev=1998995\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.2\";s:12:\"requires_php\";s:3:\"5.2\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:2:{s:53:\"child-theme-configurator/child-theme-configurator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/child-theme-configurator\";s:4:\"slug\";s:24:\"child-theme-configurator\";s:6:\"plugin\";s:53:\"child-theme-configurator/child-theme-configurator.php\";s:11:\"new_version\";s:7:\"2.3.0.4\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/child-theme-configurator/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/child-theme-configurator.2.3.0.4.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:77:\"https://ps.w.org/child-theme-configurator/assets/icon-128x128.png?rev=1557885\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/child-theme-configurator/assets/banner-772x250.jpg?rev=1557885\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(179, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1546806830;s:7:\"checked\";a:4:{s:16:\"catch-responsive\";s:3:\"2.7\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:4:{s:16:\"catch-responsive\";a:4:{s:5:\"theme\";s:16:\"catch-responsive\";s:11:\"new_version\";s:5:\"2.7.1\";s:3:\"url\";s:46:\"https://wordpress.org/themes/catch-responsive/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/theme/catch-responsive.2.7.1.zip\";}s:13:\"twentyfifteen\";a:4:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.2\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.2.zip\";}s:15:\"twentyseventeen\";a:4:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.1.9.zip\";}s:13:\"twentysixteen\";a:4:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.1.7.zip\";}}s:12:\"translations\";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-01-06 18:01:23', '2019-01-06 20:01:23', 'Sveikiname pasirinkus WordPress. Tai pirmasis jūsų tinklalapio įrašas, galite jį redaguoti arba ištrinti.', 'Pirmasis tinklalapio įrašas!', '', 'publish', 'open', 'open', '', 'pirmasis-tinklarascio-irasas', '', '', '2019-01-06 18:01:23', '2019-01-06 20:01:23', '', 0, 'http://localhost/test_ui/wordpress-wptestas/?p=1', 0, 'post', '', 1),
(2, 1, '2019-01-06 18:01:23', '2019-01-06 20:01:23', 'Tai yra puslapio pavyzdys. Puslapis šiek tiek skiriasi nuo įrašo, nes išlieka vienoje vietoje ir daugelyje temų rodomas meniu juostoje. Dažniausiai pirmasis puslapis yra „Apie“, kuriame tinklaraščio autoriai gali prisistatyti savo skaitytojams. Šis puslapis gali atrodyti taip:\n\n<blockquote>Sveiki! Aš dirbu kurjeriu, o laisvu laiku bandau tapti aktoriumi, ir rašau šį tinklaraštį. Gyvenu Vilniuje, turiu šunį, vardu Reksas, ir mėgstu gerti sultis.</blockquote>\n\n…arba štai taip:\n\n<blockquote>UAB „Pavyzdinė įmonė“ buvo įkurta 1971-iais metais ir nuo to laiko gamina įvairaus tipo lazerius. „Pavyzdinė įmonė“ įsikūrusi Kaune, joje dirba apie 200 fizikos specialistų.</blockquote>\n\nKadangi esate naujas(-a) WordPress vartotojas(-a), apsilankykite savo <a href=\"http://localhost/test_ui/wordpress-wptestas/wp-admin/\">administravimo sąsajoje</a>, ištrinkite šį puslapį ir susikurkite naujų su savo turiniu. Mėgaukitės!', 'Puslapio pavyzdys', '', 'publish', 'closed', 'open', '', 'puslapio-pavyzdys', '', '', '2019-01-06 18:01:23', '2019-01-06 20:01:23', '', 0, 'http://localhost/test_ui/wordpress-wptestas/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-01-06 18:01:23', '2019-01-06 20:01:23', '<h2>Kas mes esame</h2><p>Mūsų tinklalapio adresas yra: http://localhost/test_ui/wordpress-wptestas</p><h2>Kokius asmeninius duomenis mes renkame ir kodėl tai darome</h2><h3>Komentarai</h3><p>Kai lankytojai rašo komentarus tinklalapyje, mes renkame duomenis, matomus komentaro paskelbimo formoje, o taip pat lankytojo IP adresą bei naršyklės vartotojo įrašą, kad apsisaugotume nuo brukalų.</p><p>Iš Jūsų el.pašto adreso gali būti sugeneruotas anonimizuotas duomenų įrašas (angl. hash)  ir pateiktas Gravatar paslaugos teikėjui, norint patikrinti, ar Jūs naudojatės šia paslauga. Gravatar privatumo politika pateikiama čia: https://automattic.com/privacy/. Patvirtinus Jūsų komentarą, Jūsų profilio nuotrauka yra matoma viešai šalia Jūsų komentaro.</p><h3>Failai</h3><p>Jei įkeliate nuotraukas į tinklalapį, turėtumėte vengti įkelti jas su išsaugotais vietovės duomenimis (EXIF GPS). Tinklalapio lankytojai gali parsisiųsti nuotraukas iš tinklalapio ir iš jų išgauti vietovės duomenis.</p><h3>Kontaktų formos</h3><h3>Slapukai (cookies)</h3><p>Kai Jūs rašote komentarą šiame tinklalapyje, Jūs galite pasirinkti, ar norite, kad Jūsų vardas, el.paštas ir tinklalapis būtų išsaugotas slapukuose. Taip daroma Jūsų patogumui, kad Jums nereikėtų šių duomenų suvedinėti iš naujo, kiekvieną kartą kai komentuojate. Šie slapukai saugomi vienerius metus.</p><p>Jei Jūs turite paskyrą ir prisijungiate mūsų tinklalapyje, mes sukuriame laikiną slapuką, kuriame įrašoma, ar Jūsų naršyklė priima slapukus. Šis slapukas nesaugo jokios asmeninės informacijos ir yra ištrinamas kai uždarote savo naršyklę.</p><p>Kai Jūs prisijungiate, mes taip pat sukuriame kelis slapukus, kuriuose saugoma Jūsų prisijungimo informacija ir Jūsų ekrano rodymo pasirinkimai. Prisijungimo slapukai galioja 2 dienas, o ekrano nustatymų - vienerius metus. Jei Jūs pažymite pasirinkimą &quot;Prisiminti mane&quot;, Jūsų prisijungimo slapukas galios 2 savaites. Kai atsijungiate iš savo paskyros, prisijungimo slapukai ištrinami.</p><p>Jei redaguojate ar paskelbiate įrašą, Jūsų naršyklėje išsaugomas papildomas slapukas. Šis slapukas nesaugo asmeninių duomenų, tačiau išsaugo įrašo, kurį ką tik redagavote ar paskelbėti, ID. Šis slapukas baigia galioti po 1 dienos.</p><h3>Iš kitų tinklalapių įkeltas turinys</h3><p>Šiame tinklalapyje gali būti iš kitų tinklalapio įkelto turinio (pavyzdžiui, video, paveikslėliai, tekstas ir pan.). Tokio įkelto turinio peržiūra ir veiksmai su juo šiame tinklalapyje prilygsta apsilankymui tuose tinklalapiuose, iš kurių turinys yra įkeltas.</p><p>Šie tinklalapiai gali rinkti duomenis apie Jus, naudoti slapukus (cookies), trečiųjų šalių sekimo paslaugas ir stebėti Jūsų veiksmus su įkeltu turiniu, įskaitant ir tuos atvejus, kai turite paskyrą ir esate prisijungęs prie minėtų tinklalapių.</p><h3>Statistika</h3><h2>Su kuo mes dalinamės Jūsų duomenimis</h2><h2>Kaip ilgai mes saugome Jūsų duomenis</h2><p>Jei parašote komentarą, jo tekstas ir metaduomenys yra saugomi neribotą laiką. Taip daroma todėl, kad galėtume atpažinti ir patvirtinti ateities komentarus automatiškai, vietoje administratoriaus patvirtinimo.</p><p>Kai užsiregistruojate mūsų tinklalapyje ir tampate vartotoju, mes saugome visus Jūsų asmeninius duomenis, kuriuos Jūs pateikiate savo paskyroje. Kiekvienas vartotojas gali matyti, redaguoti ir ištrinti savo asmeninius duomenis bet kuriuo metu (išskyrus vartotojo vardą). Tinklalapio administratoriai tai pat gali matyti ir redaguoti šiuos duomenis.</p><h2>Jūsų teisės</h2><p>Jei Jūs turite paskyrą šiame tinklalapyje, arba kada nors rašėte čia komentarą, galite reikalauti gauti duomenų eksporto failą su visais asmeniniais duomenimis, kuriuos mes turime apie Jus, įskaitant ir tuos, kuriuos pats mums pateikėte. Jūs taip pat galite reikalauti, kad mes ištrintume visus mūsų turimus Jūsų asmeninius duomenis. Šie abu reikalavimai negalioja duomenims, kuriuos mes privalome išsaugoti pagal įstatymą administraciniams, teisiniams ar saugumo tikslams.</p><h2>Kur mes siunčiame Jūsų duomenis</h2><p>Lankytojų komentarai gali būti tikrinami naudojant automatinę brukalų paieškos paslaugą.</p><h2>Kontaktinė informacija</h2><h2>Papildoma informacija</h2><h3>Kaip mes saugome Jūsų duomenis</h3><h3>Kokias duomenų apsaugos procedūras mes naudojame</h3><h3>Iš kokių trečiųjų šalių mes gauname duomenis</h3><h3>Kokius automatinius sprendimus ir/ar profiliavimą mes atliekame naudodami Jūsų duomenis</h3><h3>Reguliuojamų veiklos sričių informacija</h3>', 'Privatumo politika', '', 'draft', 'closed', 'open', '', 'privatumo-politika', '', '', '2019-01-06 18:01:23', '2019-01-06 20:01:23', '', 0, 'http://localhost/test_ui/wordpress-wptestas/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-01-06 18:01:44', '0000-00-00 00:00:00', '', 'Automatiškai išsaugotas juodraštis', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-06 18:01:44', '0000-00-00 00:00:00', '', 0, 'http://localhost/test_ui/wordpress-wptestas/?p=4', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Be kategorijos', 'be-kategorijos', 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'wptestas'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,plugin_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sukurta duomenų kopija lentelei `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'wptestas', '$P$BrKcdVTrzR5crKVAnv6BNxER0TODKP.', 'wptestas', 'pcr.kompiuteriai@gmail.com', '', '2019-01-06 20:01:21', '', 0, 'wptestas');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
