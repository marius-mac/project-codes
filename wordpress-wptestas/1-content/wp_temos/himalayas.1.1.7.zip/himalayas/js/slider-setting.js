jQuery(document).ready(function(){

	//********************* bx-slider call *********************//
	jQuery('.bxslider').bxSlider({
	    auto: true,
	    pager: false,
	    mode: 'fade',
	    speed: 900,
	    pause: 5000,
	    adaptiveHeight: true,
	    autoHover: true
	});

 });