<?php

return [
	// needs to be set in filemanager.config.js too
	'folder_path' => "filemanager/userfiles/"
];
